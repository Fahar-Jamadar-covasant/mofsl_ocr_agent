from contextvars import ContextVar, Token
from typing import Any, Optional

_request_ctx: ContextVar[Optional[Any]] = ContextVar("request_ctx", default=None)
_observability_client: ContextVar[Optional[Any]] = ContextVar("observability_client", default=None)


def get_request_context() -> Optional[Any]:
    return _request_ctx.get()


def set_request_context(value: Any) -> Token[Any]:
    return _request_ctx.set(value)


def reset_request_context(token: Token[Any]) -> None:
    _request_ctx.reset(token)


def get_observability_client() -> Optional[Any]:
    return _observability_client.get()


def set_observability_client(value: Any) -> Token[Any]:
    return _observability_client.set(value)


def reset_observability_client(token: Token[Any]) -> None:
    _observability_client.reset(token)
