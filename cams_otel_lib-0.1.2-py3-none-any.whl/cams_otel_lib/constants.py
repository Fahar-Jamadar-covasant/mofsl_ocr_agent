DEFAULT_OTEL_COLLECTOR_ENDPOINT = "http://localhost:4317"

OTEL_FQN_FORMAT = (
    "request_id:{request_id}_tenant_name:{tenant_name}_scope_name:{scope_name}"
    "_app_name:{app_name}_userid:{userid}_name:{name}"
)
