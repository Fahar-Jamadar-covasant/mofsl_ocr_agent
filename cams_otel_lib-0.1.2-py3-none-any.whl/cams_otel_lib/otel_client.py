import functools
import inspect
import logging
import os
import uuid

from opentelemetry import _logs, metrics, trace
from opentelemetry.exporter.otlp.proto.grpc._log_exporter import OTLPLogExporter
from opentelemetry.exporter.otlp.proto.grpc.metric_exporter import OTLPMetricExporter
from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter
from opentelemetry.instrumentation.logging import LoggingInstrumentor
from opentelemetry.metrics import get_meter
from opentelemetry.sdk._logs import LoggerProvider, LoggingHandler
from opentelemetry.sdk._logs.export import (
    BatchLogRecordProcessor,
    ConsoleLogRecordExporter,
    SimpleLogRecordProcessor,
)
from opentelemetry.sdk.metrics import MeterProvider
from opentelemetry.sdk.metrics.export import (
    ConsoleMetricExporter,
    PeriodicExportingMetricReader,
)
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.resources import logger as otel_logger
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import (
    BatchSpanProcessor,
    ConsoleSpanExporter,
    SimpleSpanProcessor,
)
from opentelemetry.sdk.trace.export import BatchSpanProcessor

from cams_otel_lib import constants
from cams_otel_lib.request_context_var import get_observability_client, get_request_context


def _get_otel_fqn(request_id, tenant_name, scope_name, app_name, userid, name):
    return constants.OTEL_FQN_FORMAT.format(
        request_id=request_id,
        tenant_name=tenant_name,
        scope_name=scope_name,
        app_name=app_name,
        userid=userid,
        name=name,
    )


def otel_logger_decorator(func):
    @functools.wraps(func)
    def wrapper(obj, message, *args, **kwargs):
        caller_frame = inspect.stack()[1]
        module = inspect.getmodule(caller_frame[0])
        module_name = module.__name__ if module else "unknown"
        filename = caller_frame.filename
        lineno = caller_frame.lineno
        func_name = caller_frame.function
        request_context = get_request_context()
        try:
            logs_attrs = {}
            if request_context and request_context.extra_logging_attributes:
                logs_attrs.update(request_context.extra_logging_attributes)
            loc = {
                "code_loc": {
                    "module": module_name,
                    "filename": filename,
                    "funcName": func_name,
                    "lineno": lineno,
                }
            }
            logs_attrs.update(loc)
            return func(obj, message, extra=logs_attrs, *args, **kwargs)
        except Exception as e:
            otel_logger.error(f"Error in otel_logger_decorator: {str(e)}")
            return func(obj, message, *args, **kwargs)

    return wrapper


def otel_trace(func):
    _span_name = func.__qualname__
    _is_async = inspect.iscoroutinefunction(func)

    def _apply_span_attributes(span):
        rc = get_request_context()
        if rc and rc.extra_logging_attributes:
            for attr, val in rc.extra_logging_attributes.items():
                span.set_attribute(attr, val)

    if _is_async:
        @functools.wraps(func)
        async def async_wrapper(*args, **kwargs):
            rc = get_request_context()
            oc = get_observability_client()
            if rc and oc:
                with oc._start_span(func_name=_span_name, tracer_name=rc.session_id) as span:
                    _apply_span_attributes(span)
                    try:
                        return_obj = await func(*args, **kwargs)
                        span.set_status(trace.status.Status(trace.status.StatusCode.OK))
                        return return_obj
                    except Exception as e:
                        span.set_status(trace.status.Status(trace.status.StatusCode.ERROR, str(e)))
                        raise
            else:
                return await func(*args, **kwargs)

        return async_wrapper
    else:
        @functools.wraps(func)
        def sync_wrapper(*args, **kwargs):
            rc = get_request_context()
            oc = get_observability_client()
            if rc and oc:
                with oc._start_span(func_name=_span_name, tracer_name=rc.session_id) as span:
                    _apply_span_attributes(span)
                    try:
                        return_obj = func(*args, **kwargs)
                        span.set_status(trace.status.Status(trace.status.StatusCode.OK))
                        return return_obj
                    except Exception as e:
                        span.set_status(trace.status.Status(trace.status.StatusCode.ERROR, str(e)))
                        raise
            else:
                return func(*args, **kwargs)

        return sync_wrapper


class Logger_Class:
    @otel_logger_decorator
    def info(self, msg, *args, **kwargs):
        otel_logger.info(msg, *args, **kwargs)

    @otel_logger_decorator
    def warning(self, msg, *args, **kwargs):
        otel_logger.warning(msg, *args, **kwargs)

    @otel_logger_decorator
    def error(self, msg, *args, **kwargs):
        otel_logger.error(msg, *args, **kwargs)

    @otel_logger_decorator
    def debug(self, msg, *args, **kwargs):
        otel_logger.debug(msg, *args, **kwargs)


Logger = Logger_Class()


class Otel_Client:
    current_otel_client = None

    def __init__(
        self,
        otel_config: dict = {
            "service_name": "cams",
            "environment": "dev",
            "otel_collector_endpoint": constants.DEFAULT_OTEL_COLLECTOR_ENDPOINT,
            "otel_export_interval": 60000,
            "agent_id": "N/A",
        },
    ):
        self.otel_config = otel_config
        self.service_name = otel_config["service_name"]
        self.resource = Resource.create(
            {
                "service.name": otel_config["service_name"],
                "environment": otel_config["environment"],
                "agent.id": otel_config.get("agent_id", "N/A"),
            }
        )

        if not otel_config["otel_enabled"]:
            return

        self.otel_logging_enabled = otel_config.get("otel_logging_enabled", False)
        self.otel_console_logging = otel_config.get("otel_console_logging", False)
        self.otel_console_logging_batched = otel_config.get("otel_console_logging_batched", False)
        self.otel_remote_logging = otel_config.get("otel_remote_logging", False)
        self.otel_remote_logging_batched = otel_config.get("otel_remote_logging_batched", False)
        if self.otel_logging_enabled:
            LoggingInstrumentor().instrument(set_logging_format=True)
            self.log_provider = LoggerProvider(resource=self.resource)
            if self.otel_console_logging:
                console_processor = (
                    BatchLogRecordProcessor(ConsoleLogRecordExporter())
                    if self.otel_console_logging_batched
                    else SimpleLogRecordProcessor(ConsoleLogRecordExporter())
                )
                self.log_provider.add_log_record_processor(console_processor)
            if self.otel_remote_logging:
                endpoint = otel_config["otel_collector_endpoint"]
                insecure = not otel_config["otel_collector_endpoint_is_secure"]
                remote_processor = (
                    BatchLogRecordProcessor(OTLPLogExporter(endpoint=endpoint, insecure=insecure))
                    if self.otel_remote_logging_batched
                    else SimpleLogRecordProcessor(OTLPLogExporter(endpoint=endpoint, insecure=insecure))
                )
                self.log_provider.add_log_record_processor(remote_processor)
            _logs.set_logger_provider(self.log_provider)
            handler = LoggingHandler(
                level=otel_config["otel_log_level"], logger_provider=self.log_provider
            )
            logging.getLogger().addHandler(handler)

        self.otel_tracing_enabled = otel_config.get("otel_tracing_enabled", False)
        self.otel_console_tracing = otel_config.get("otel_console_tracing", False)
        self.otel_console_tracing_batched = otel_config.get("otel_console_tracing_batched", False)
        self.otel_remote_tracing = otel_config.get("otel_remote_tracing", False)
        self.otel_remote_tracing_batched = otel_config.get("otel_remote_tracing_batched", False)
        if self.otel_tracing_enabled:
            self.trace_provider = TracerProvider(resource=self.resource)
            if self.otel_console_tracing:
                console_span_processor = (
                    BatchSpanProcessor(ConsoleSpanExporter())
                    if self.otel_console_tracing_batched
                    else SimpleSpanProcessor(ConsoleSpanExporter())
                )
                self.trace_provider.add_span_processor(console_span_processor)
            if self.otel_remote_tracing:
                endpoint = otel_config["otel_collector_endpoint"]
                insecure = not otel_config["otel_collector_endpoint_is_secure"]
                remote_span_processor = BatchSpanProcessor(
                    OTLPSpanExporter(endpoint=endpoint, insecure=insecure)
                )
                self.trace_provider.add_span_processor(remote_span_processor)
            trace.set_tracer_provider(self.trace_provider)

        self.otel_metrics_enabled = otel_config.get("otel_metrics_enabled", False)
        self.otel_console_metrics = otel_config.get("otel_console_metrics", False)
        self.otel_console_metrics_batched = otel_config.get("otel_console_metrics_batched", False)
        self.otel_remote_metrics = otel_config.get("otel_remote_metrics", False)
        self.otel_remote_metrics_batched = otel_config.get("otel_remote_metrics_batched", False)
        if self.otel_metrics_enabled:
            metric_readers = []
            interval = otel_config["otel_metrics_export_interval"]
            if self.otel_console_metrics:
                metric_readers.append(
                    PeriodicExportingMetricReader(
                        ConsoleMetricExporter(), export_interval_millis=interval
                    )
                )
            if self.otel_remote_metrics:
                endpoint = otel_config["otel_collector_endpoint"]
                insecure = not otel_config["otel_collector_endpoint_is_secure"]
                metric_readers.append(
                    PeriodicExportingMetricReader(
                        OTLPMetricExporter(endpoint=endpoint, insecure=insecure),
                        export_interval_millis=interval,
                    )
                )
            self.meter_provider = MeterProvider(resource=self.resource, metric_readers=metric_readers)
            metrics.set_meter_provider(self.meter_provider)

    def _get_tracer(self, name: str = "cams_tracer"):
        return trace.get_tracer(instrumenting_module_name=name)

    def _start_span(self, func_name: str, tracer_name: str = "cams_tracer"):
        tracer = self._get_tracer(name=tracer_name)
        return tracer.start_as_current_span(name=func_name)

    def create_meter(self, name: str = "cams_meter"):
        return get_meter(name)

    def finish_observability_client(self):
        if hasattr(self, "trace_provider"):
            self.trace_provider.shutdown()
        if hasattr(self, "log_provider"):
            self.log_provider.shutdown()
        if hasattr(self, "meter_provider"):
            self.meter_provider.shutdown()

    @classmethod
    def get_otel_config(cls, service_name: str, environment: str = "dev", agent_id: str = "N/A") -> dict:
        cls.otel_enabled = os.getenv("OTEL_ENABLED", "false").lower()
        cls.otel_config_uuid = os.getenv("OTEL_CONFIG_UUID") or uuid.uuid4().hex.lower()
        cls.otel_endpoint = os.getenv("OTEL_ENDPOINT", constants.DEFAULT_OTEL_COLLECTOR_ENDPOINT)
        cls.otel_endpoint_is_secure = os.getenv("OTEL_ENDPOINT_IS_SECURE", "false").lower()

        loglevel_mapping = logging.getLevelNamesMapping()
        otel_log_level = loglevel_mapping.get(
            os.getenv("OTEL_LOG_LEVEL", "INFO").upper(), logging.INFO
        )

        return {
            "otel_enabled": cls.otel_enabled == "true",
            "service_name": service_name,
            "environment": environment,
            "agent_id": agent_id,
            "otel_config_uuid": cls.otel_config_uuid,
            "otel_logging_enabled": os.getenv("OTEL_LOGGING_ENABLED", "false").lower() == "true",
            "otel_log_level": otel_log_level,
            "otel_console_logging": os.getenv("OTEL_CONSOLE_LOGGING", "false").lower() == "true",
            "otel_console_logging_batched": os.getenv("OTEL_CONSOLE_LOGGING_BATCHED", "false").lower() == "true",
            "otel_remote_logging": os.getenv("OTEL_REMOTE_LOGGING", "false").lower() == "true",
            "otel_remote_logging_batched": os.getenv("OTEL_REMOTE_LOGGING_BATCHED", "false").lower() == "true",
            "otel_tracing_enabled": os.getenv("OTEL_TRACING_ENABLED", "false").lower() == "true",
            "otel_console_tracing": os.getenv("OTEL_CONSOLE_TRACING", "false").lower() == "true",
            "otel_console_tracing_batched": os.getenv("OTEL_CONSOLE_TRACING_BATCHED", "false").lower() == "true",
            "otel_remote_tracing": os.getenv("OTEL_REMOTE_TRACING", "false").lower() == "true",
            "otel_remote_tracing_batched": os.getenv("OTEL_REMOTE_TRACING_BATCHED", "false").lower() == "true",
            "otel_metrics_enabled": os.getenv("OTEL_METRICS_ENABLED", "false").lower() == "true",
            "otel_console_metrics": os.getenv("OTEL_CONSOLE_METRICS", "false").lower() == "true",
            "otel_console_metrics_batched": os.getenv("OTEL_CONSOLE_METRICS_BATCHED", "false").lower() == "true",
            "otel_remote_metrics": os.getenv("OTEL_REMOTE_METRICS", "false").lower() == "true",
            "otel_remote_metrics_batched": os.getenv("OTEL_REMOTE_METRICS_BATCHED", "false").lower() == "true",
            "otel_metrics_export_interval": int(os.getenv("OTEL_METRICS_EXPORT_INTERVAL", "60000")),
            "otel_collector_endpoint": cls.otel_endpoint,
            "otel_collector_endpoint_is_secure": cls.otel_endpoint_is_secure == "true",
        }

    @classmethod
    def get_otel_client(cls, otel_config: dict = None) -> "Otel_Client":
        if otel_config is None:
            return cls.current_otel_client
        if (
            cls.current_otel_client is None
            or cls.current_otel_client.otel_config["otel_config_uuid"] != otel_config["otel_config_uuid"]
        ):
            if cls.current_otel_client:
                cls.current_otel_client.finish_observability_client()
            cls.current_otel_client = Otel_Client(otel_config=otel_config)
        return cls.current_otel_client

    @classmethod
    def initialize_otel_client(
        cls, service_name: str, environment: str = "dev", agent_id: str = "N/A"
    ) -> "Otel_Client":
        otel_config = cls.get_otel_config(
            service_name=service_name, environment=environment, agent_id=agent_id
        )
        return cls.get_otel_client(otel_config=otel_config)

    @classmethod
    def get_current_otel_client(cls) -> "Otel_Client":
        return cls.current_otel_client
