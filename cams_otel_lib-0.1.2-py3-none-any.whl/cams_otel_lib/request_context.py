from uuid import uuid4


class RequestContext:
    """Holds per-request information used for structured logging and distributed tracing.

    Attributes whose value is absent or sentinel ('N/A', '') are auto-generated.
    All attributes are also mirrored into ``extra_logging_attributes`` so they
    can be attached to every log record and span without extra bookkeeping.
    """

    def __init__(
        self,
        request_id: str,
        tenant_name: str,
        scope_name: str,
        app_name: str,
        userid: str,
        session_id: str = "N/A",
        agent_id: str = "N/A",
        service_name: str = "cams",
    ):
        self.request_id = request_id if request_id not in (None, "", "N/A") else uuid4().hex.lower()
        self.tenant_name = tenant_name
        self.scope_name = scope_name
        self.app_name = app_name
        self.userid = userid
        self.session_id = session_id
        self.service_name = service_name
        self.agent_id = agent_id if agent_id not in (None, "", "N/A") else uuid4().hex.lower()

        self.observability_client = None
        self.extra_logging_attributes = {
            "request_id": self.request_id,
            "tenant_name": self.tenant_name,
            "scope_name": self.scope_name,
            "app_name": self.app_name,
            "userid": self.userid,
            "session_id": self.session_id,
            "agent_id": self.agent_id,
        }
