import logging
import os
import time
from turtle import tracer
import uuid

from request_context import RequestContext
import functools
import asyncio

from request_context_var import get_request_context, set_request_context, set_observability_client, reset_observability_client, reset_request_context
from otel_client import Otel_Client, otel_trace, Logger as logger

class Observability:
    @otel_trace
    def my_function4(self) -> str:
        logger.info("In my_function4")
        raise Exception("Error in my_function4")
        #return "Hello from my_function4" 
        #return uuid.uuid4().hex.lower()

    @otel_trace
    async def my_function3(self):
        #oc = Otel_Client.get_otel_client()
        #with oc._start_span(func_name=self.my_function3.__name__) as span:
        logger.info("In my_function3")
        try:
            res = self.my_function4()
            logger.info(f"Result from my_function4: {res}")
        except Exception as e:
            logger.error(f"Error in my_function3: {str(e)}")

    @otel_trace
    async def my_function2(self):
        #oc = Otel_Client.get_otel_client()
        #with oc._start_span(func_name=self.my_function2.__name__) as span:
        logger.info("In my_function2")
        await self.my_function3()

    @otel_trace
    async def my_function1(self):
        #oc = Otel_Client.get_otel_client()
        #with oc._start_span(func_name=self.my_function1.__name__) as span:
        logger.info("In my_function1")
        await self.my_function2()
    
    def tracer_invoke(self):
        asyncio.run(self.my_function1())

@otel_trace
def start_observability(iter: int = 0):
    observability = Observability()

    otel_client_token = None
    request_context_token = None
    try:
        otel_client = Otel_Client.initialize_otel_client(service_name="cams", environment="dev", agent_id="agent1")
        otel_client_token = set_observability_client(otel_client)
        rc = RequestContext(request_id="12345", tenant_name="tenant1", scope_name="scope1", app_name="app1", userid="user1", agent_id="agent1", session_id=uuid.uuid4().hex.lower(), service_name="cams")
        request_context_token = set_request_context(rc)

        #observability.log("info", "Application started, tracing and logging initialized.")
        logger.warning("Application started, tracing and logging initialized.")
                
        # Increment metric  
        cams_meter = otel_client.create_meter(name="cams_meter")
        #cams_request_counter = cams_meter.create_counter(name="request_count", description="Counts the number of requests", unit="1")
        #for _ in range(100):
            #cams_request_counter.add(1)

        cams_cpu_gauge = cams_meter.create_gauge(name="cpu_usage", description="CPU usage gauge", unit="%")
        cams_cpu_gauge.set(75.5)

        # Simulate work
        #time.sleep(1)
        observability.tracer_invoke()
        
        reset_request_context(request_context_token)
        reset_observability_client(otel_client_token)
        #otel_client.finish_observability_client()
        logger.warning("Application finished, tracing and logging finished.")
    except Exception as e:
        logger.error("Error in start_observability: {}".format(str(e)))

def start_metering():
    observability = Observability()

    otel_client_token = None
    request_context_token1 = None
    request_context_token2 = None
    request_context_token3 = None
    request_context_token4 = None

    try:
        otel_client = Otel_Client.initialize_otel_client(service_name="cams", environment="dev", agent_id="agent1")
        otel_client_token = set_observability_client(otel_client)
        
        # Token Counter metric  
        token_counter_metrics = otel_client.create_meter(name="token_counter_metrics")

        rc1 = RequestContext(request_id=uuid.uuid4().hex.lower(), tenant_name="tenant1", scope_name="scope1", app_name="app1", userid="user1", agent_id="agent1", session_id=uuid.uuid4().hex.lower(), service_name="cams")
        request_context_token1 = set_request_context(rc1)

        rc2 = RequestContext(request_id=uuid.uuid4().hex.lower(), tenant_name="tenant1", scope_name="scope2", app_name="app2", userid="user2", agent_id="agent1", session_id=uuid.uuid4().hex.lower(), service_name="cams")
        request_context_token = set_request_context(rc2)

        rc3 = RequestContext(request_id=uuid.uuid4().hex.lower(), tenant_name="tenant1", scope_name="scope2", app_name="app1", userid="user2", agent_id="agent1", session_id=uuid.uuid4().hex.lower(), service_name="cams")
        request_context_token3 = set_request_context(rc3)

        rc4 = RequestContext(request_id=uuid.uuid4().hex.lower(), tenant_name="tenant2", scope_name="scope1", app_name="app1", userid="user2", agent_id="agent1S", session_id=uuid.uuid4().hex.lower(), service_name="cams")
        request_context_token4 = set_request_context(rc4)

        #logger.info("Metering started.")
        token_counter = token_counter_metrics.create_counter(name="LLM_Token_Counter", description="LLM Token Usage", unit="1")
        token_counter.add(236, attributes=rc1.extra_logging_attributes)
        token_counter.add(4245, attributes=rc2.extra_logging_attributes)
        token_counter.add(1234, attributes=rc3.extra_logging_attributes)
        token_counter.add(5678, attributes=rc4.extra_logging_attributes)
        token_counter.add(236, attributes=rc1.extra_logging_attributes)
        token_counter.add(4245, attributes=rc2.extra_logging_attributes)
        token_counter.add(1234, attributes=rc3.extra_logging_attributes)
        token_counter.add(5678, attributes=rc4.extra_logging_attributes)

        # Simulate work
        #time.sleep(1)
        observability.tracer_invoke()
        
        #reset_request_context(request_context_token1)
        #reset_request_context(request_context_token2)
        #reset_request_context(request_context_token3)
        #reset_request_context(request_context_token4)
        #reset_observability_client(otel_client_token)
        #otel_client.finish_observability_client()
        logger.warning("Application finished, tracing and logging finished.")
    except Exception as e:
        logger.error("Error in start_observability: {}".format(str(e)))

try:
    rid = uuid.uuid4().hex.lower()
    print(type(rid))
    iter = 0
    while True:
        start_metering()
        start_observability(iter=iter)
        iter += 1
        time.sleep(1)
except KeyboardInterrupt:
    print("Shutting down...")

