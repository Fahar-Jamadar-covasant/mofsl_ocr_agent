import re
import heapq
from typing import Dict, List, Optional, Set
from platform_sdk.common.cams_constants import RBAC_RESOURCE_PATH_SEPARATOR, RANDOM_STRING_ALLOWED_CHARS
from . import rbac_policy_cache
from collections import defaultdict
from . import default_enums
import hmac
import hashlib
import secrets

async def rbac_policy_get_user_role_ids(db, user_id: int, tenant_id: int):
    pool = db._need_pool()
    async with pool.acquire() as conn:
        user_roles = await conn.fetch("""
            SELECT DISTINCT r.id
            FROM roles r
            JOIN group_roles gr ON gr.role_id = r.id
            JOIN user_groups ug ON ug.group_id = gr.group_id
            WHERE ug.user_id = $1 AND ug.tenant_id = $2
              AND r.is_active = TRUE
        """, user_id, tenant_id)
        return {r['id'] for r in user_roles}


async def rbac_policy_get_scoped_user_role_ids(db, user_id: int, tenant_id: int, scope_id: int):
    """
    Get role IDs for a user limited to a specific scope.
    Includes:
    - Roles from groups that the user belongs to AND carry the scope_id
    - Roles from groups that the user belongs to but have NO scope assignments (global groups)
    Excludes:
    - Roles from groups that carry other scopes (not scope_id)
    """
    pool = db._need_pool()
    async with pool.acquire() as conn:
        user_roles = await conn.fetch("""
            WITH user_group_ids AS (
                SELECT group_id FROM user_groups WHERE user_id = $1 AND tenant_id = $2
            ),
            scoped_group_ids AS (
                SELECT group_id FROM group_scopes WHERE scope_id = $3
            ),
            global_group_ids AS (
                SELECT ugi.group_id FROM user_group_ids ugi
                WHERE NOT EXISTS (SELECT 1 FROM group_scopes gs WHERE gs.group_id = ugi.group_id)
            )
            SELECT DISTINCT gr.role_id
            FROM group_roles gr
            JOIN roles r ON r.id = gr.role_id AND r.is_active = TRUE AND r.tenant_id = $2
            WHERE gr.group_id IN (
                SELECT group_id FROM user_group_ids
                INTERSECT
                SELECT group_id FROM scoped_group_ids
            )
            UNION
            SELECT DISTINCT gr.role_id
            FROM group_roles gr
            JOIN roles r ON r.id = gr.role_id AND r.is_active = TRUE AND r.tenant_id = $2
            WHERE gr.group_id IN (SELECT group_id FROM global_group_ids)
        """, user_id, tenant_id, scope_id)
        return {r['role_id'] for r in user_roles}

"""
A function to check if the user given role clashes with CAMS SDK default roles
So that these names will be avoided by the user.
"""
def is_default_role(value: str):
    try:
        default_enums.CAMS_ROLE(value)
        return True
    except ValueError:
        return False

"""
A function to check if the user given action clashes with CAMS SDK default actions
So that these names will be avoided by the user.
"""
def is_default_action(value: str):
    try:
        default_enums.CAMS_ACTIONS(value)
        return True
    except ValueError:
        return False

"""
Function to resolve the best RBAC policy for the given resource.
Resources are path based
for example /tenants/tid/apps/appid/settings
rbac policy can be /tenants/.+/apps/appid/settings
which generalises on all the tenant ids

If no policy is found, it returns None
"""
def _get_pattern_specificity(pattern: str):
    segments = [segment for segment in pattern.split(RBAC_RESOURCE_PATH_SEPARATOR) if segment]
    return -len(segments), -len(pattern)


def _get_match_heap_entry(is_exact_match: bool, pattern: str, record_index: int, record_payload):
    if is_exact_match:
        return (0, -1, -1, record_index, record_payload)
    else:
        segment_score, length_score = _get_pattern_specificity(pattern)
        return (1, segment_score, length_score, record_index, record_payload)


async def rbac_policy_get_group_match_score(db, resource_group_id: int, resource_path: str):
    pool = db._need_pool()
    async with pool.acquire() as conn:
        resources = await conn.fetch("""
            SELECT name, pattern, is_pattern
            FROM resources
            WHERE resource_group_id = $1
        """, resource_group_id)

        best_match_heap = []

        for index, resource in enumerate(resources):
            if not resource['is_pattern']:
                if resource_path == resource['name']:
                    heapq.heappush(
                        best_match_heap,
                        _get_match_heap_entry(True, resource['name'], index, dict(resource)),
                    )
            else:
                if re.match(resource['pattern'], resource_path):
                    heapq.heappush(
                        best_match_heap,
                        _get_match_heap_entry(False, resource['pattern'], index, dict(resource)),
                    )

        if best_match_heap:
            best_entry = heapq.heappop(best_match_heap)
            return best_entry[4]

        return None


async def rbac_policy_get_best_match(db, rbac_policy_records: list, resource: str):
    best_policy_heap = []

    for index, rbac_policy_record in enumerate(rbac_policy_records):
        heap_entry = None

        if rbac_policy_record['resource_id'] and not rbac_policy_record['resource_group_id']:
            resource_name = rbac_policy_record['resource_name']
            is_pattern = rbac_policy_record['is_pattern']
            pattern = rbac_policy_record['resource_pattern'] if is_pattern else resource_name

            if not is_pattern and resource == resource_name:
                heap_entry = _get_match_heap_entry(True, resource_name, index, rbac_policy_record)
            elif is_pattern and re.match(pattern, resource):
                heap_entry = _get_match_heap_entry(False, pattern, index, rbac_policy_record)
        elif rbac_policy_record['resource_group_id'] and not rbac_policy_record['resource_id']:
            matched_group_resource = await rbac_policy_get_group_match_score(
                db=db,
                resource_group_id=rbac_policy_record['resource_group_id'],
                resource_path=resource,
            )
            if matched_group_resource is not None:
                matched_pattern = (
                    matched_group_resource['pattern']
                    if matched_group_resource['is_pattern']
                    else matched_group_resource['name']
                )
                heap_entry = _get_match_heap_entry(
                    not matched_group_resource['is_pattern'],
                    matched_pattern,
                    index,
                    rbac_policy_record,
                )

        if heap_entry is not None:
            heapq.heappush(best_policy_heap, heap_entry)

    if not best_policy_heap:
        return None

    return heapq.heappop(best_policy_heap)[4]

"""
A function to fetch records applicable to the given tenant, scope with the given action
"""
async def rbac_policy_get_policy_records(db, tenant_id: int, action: str, role_ids: set):
    """
    Fetch RBAC policy records from database for given tenant and action.

    Args:
        db: AuthDatabase instance
        tenant_id: Tenant ID
        action: Action name (e.g., 'read', 'create', 'update', 'delete')
        role_ids: Set of role IDs to match

    Returns:
        List of policy records with resource info
    """
    pool = db._need_pool()
    async with pool.acquire() as conn:
        action_row = await conn.fetchrow("SELECT id FROM actions WHERE name = $1", action)
        if not action_row:
            return []

        if not role_ids:
            return []

        action_id = action_row['id']

        rbac_policy_records = await conn.fetch("""
            SELECT
                p.id,
                p.role_id,
                p.resource_id,
                p.resource_group_id,
                p.is_allowed,
                p.metadata,
                r.name as resource_name,
                r.pattern as resource_pattern,
                r.is_pattern,
                rg.name as resource_group_name
            FROM rbac_policies p
            LEFT JOIN resources r ON r.id = p.resource_id
            LEFT JOIN resource_groups rg ON rg.id = p.resource_group_id
            WHERE p.tenant_id = $1
              AND p.action_id = $2
              AND p.role_id = ANY($3::int[])
        """, tenant_id, action_id, list(role_ids))

        return [dict(record) for record in rbac_policy_records]

"""
A function that computes the RBAC policy and tells if the given resource can be accessed with the roles given
"""
async def rbac_policy_is_action_allowed(db, tenant_id: int, role_ids: set, resource_name: str, action: str):
    allowed, _, _ = await rbac_policy_evaluate_user_access(
        db=db,
        user_id=None,
        tenant_id=tenant_id,
        resource_name=resource_name,
        action=action,
        role_ids=role_ids,
    )
    return allowed


async def rbac_policy_evaluate_user_access(
    db,
    user_id: Optional[int],
    tenant_id: int,
    resource_name: str,
    action: str,
    role_ids: Optional[Set[int]] = None,
    preloaded_policy_records: Optional[List[Dict]] = None,
    preloaded_policy_records_map: Optional[Dict[int, List[Dict]]] = None,
):
    if role_ids is None:
        if user_id is None:
            return False, "User ID or role IDs required", None
        role_ids = await rbac_policy_get_user_role_ids(db=db, user_id=user_id, tenant_id=tenant_id)
    if not role_ids:
        return False, "User has no roles", None

    if preloaded_policy_records is None:
        rbac_policy_records = await rbac_policy_get_policy_records(
            db=db,
            tenant_id=tenant_id,
            action=action,
            role_ids=role_ids,
        )
    else:
        rbac_policy_records = preloaded_policy_records
    if not rbac_policy_records:
        return False, "No policies found for user's roles", None

    if preloaded_policy_records_map is None:
        rbac_policy_records_map = defaultdict(list)
        for rbac_policy_record in rbac_policy_records:
            rbac_policy_records_map[rbac_policy_record['role_id']].append(rbac_policy_record)
    else:
        rbac_policy_records_map = preloaded_policy_records_map

    deny_policy = None

    for role_id in role_ids:
        cache_result = rbac_policy_cache.rbac_get_policy_result(
            tenant_id=tenant_id,
            role_id=role_id,
            resource_name=resource_name,
            action=action,
        )
        if cache_result is True:
            return True, f"Allowed (cached) by role {role_id}", None
        if cache_result is False:
            continue

        if role_id not in rbac_policy_records_map:
            continue

        best_for_role = await rbac_policy_get_best_match(
            db=db,
            rbac_policy_records=rbac_policy_records_map[role_id],
            resource=resource_name,
        )

        if best_for_role is None:
            continue

        rbac_policy_cache.rbac_put_policy_result(
            tenant_id=tenant_id,
            role_id=role_id,
            resource_name=resource_name,
            action=action,
            result=best_for_role['is_allowed'],
        )

        if best_for_role['is_allowed']:
            return True, f"Allowed by policy {best_for_role['id']} (role {role_id})", dict(best_for_role)

        if deny_policy is None:
            deny_policy = best_for_role

    if deny_policy:
        return False, f"Denied by policy {deny_policy['id']}", dict(deny_policy)

    return False, "No matching policy found for resource", None


"""
Utility function to generate HMAC-SHA256 hash of a message with a secret key.
This can be used for signing or verifying messages in RBAC claims result or other scenarios.
Args:
    message: The input message to be hashed.
    secret_key: The secret key used for hashing.
    Returns: hmac digest as a hexadecimal string.
"""
def generate_hmac_sha256(message: str, secret_key: str) -> str:
    key_bytes = secret_key.encode('utf-8')
    message_bytes = message.encode('utf-8')
    hmac_obj = hmac.new(key_bytes, message_bytes, hashlib.sha256)
    return hmac_obj.hexdigest()

"""
    Generates a cryptographically secure random string with a random length.
    The string consists of uppercase letters, lowercase letters, and digits.
    Args:
        min_len: Minimum length of the generated string (default: 128)
        max_len: Maximum length of the generated string (default: 256)
"""
def generate_secure_random_string(min_len: int = 128, max_len: int = 256) -> str:
    length = min_len + secrets.randbelow(max_len - min_len + 1)
    return ''.join(secrets.choice(RANDOM_STRING_ALLOWED_CHARS) for _ in range(length))

"""
Validates a checksum for a given value using HMAC-SHA256 with a secret key.
Args:
    value: The input value whose checksum needs to be validated.
    checksum: The expected checksum to compare against.
    secret_key: The secret key used for generating the HMAC-SHA256 hash.
"""
def validate_cheksum(value: str, checksum: str, secret_key: str) -> bool:
    expected_checksum = generate_hmac_sha256(value, secret_key)
    return hmac.compare_digest(expected_checksum, checksum)
