"""
Standalone mode default seeding logic.

Bootstraps a new standalone installation with:
- Tenant and app records
- Password provider for password-based authentication
- Default roles and groups
- Role-group mappings (group_roles)
- Super-admin user
- RSA key pair for JWT signing
- Generic N-level entity hierarchy (scope_entity_levels + scope_entities)
- RBAC actions, resource groups, resources, and policies
"""

import logging
from typing import TYPE_CHECKING

SYSTEM_ACTOR_ID = -1

if TYPE_CHECKING:
    import asyncpg

logger = logging.getLogger(__name__)


async def seed_standalone_defaults(
    pool: "asyncpg.Pool",
    tenant_name: str,
    tenant_description: str,
    app_name: str,
    app_description: str,
    admin_email: str,
    admin_password_hash: str,
    admin_first_name: str,
    admin_last_name: str,
    admin_display_name: str,
    roles: list,
    groups: list,
    role_group_mappings: dict,
    tenant_domain: str = None,
    tenant_details: dict = None,
    rbac_config: dict = None,
    providers: list = None,
    entity_hierarchy: dict = None,
    group_scope_mappings: dict = None,
) -> dict:
    """
    Seed default data for standalone mode with fully configurable roles, groups, mappings, and scopes.

    Parameters
    ----------
    entity_hierarchy : dict, optional
        Generic N-level entity hierarchy defined via scope_entity_levels and scope_entities.
        Example:
        {
            "levels": [{"name": "organization", "depth": 0}, {"name": "team", "depth": 1}],
            "entities": [{"name": ..., "level_name": ..., "parent_uuid": ...}]
        }
    rbac_config : dict, optional
        {
            "actions": [{"name": ..., "description": ...}],
            "resource_groups": [{"name": ..., "display_name": ..., "description": ...}],
            "resources": [{"name": ..., "resource_group": ..., "is_pattern": ..., "pattern": ...}],
            "policies": [{"role": ..., "resource_group": ..., "action": ..., "is_allowed": ...}]
        }
        Note: no scope dimension in policies.
    scopes : list, optional
        [{"name": ..., "entity_name": ..., "description": ...}]
    group_scope_mappings : dict, optional
        {"group_name": ["scope_name_1", "scope_name_2", ...]}
    """
    if not roles:
        raise ValueError("roles is required.")
    if not groups:
        raise ValueError("groups is required.")
    if not role_group_mappings:
        raise ValueError("role_group_mappings is required.")

    default_groups = [g for g in groups if g.get('is_default', False)]
    if len(default_groups) == 0:
        raise ValueError("Exactly one group must have 'is_default: true'")
    if len(default_groups) > 1:
        raise ValueError(f"Only one group can be default. Found {len(default_groups)}: {[g['name'] for g in default_groups]}")

    import json

    async with pool.acquire() as conn:
        # ── 1. Tenant ──────────────────────────────────────────────
        tenant = await conn.fetchrow("""
            INSERT INTO tenants (tenant_name, tenant_description, domain, details, created_by, updated_by)
            VALUES ($1, $2, $3, $4, $5, $5)
            ON CONFLICT (tenant_name) DO UPDATE
            SET tenant_description = EXCLUDED.tenant_description,
                domain = EXCLUDED.domain,
                details = EXCLUDED.details,
                updated_by = EXCLUDED.updated_by
            RETURNING id
        """, tenant_name, tenant_description, tenant_domain,
             json.dumps(tenant_details) if tenant_details else None,
             SYSTEM_ACTOR_ID)
        tenant_id = tenant['id']
        logger.info(f"Tenant '{tenant_name}' ready (id={tenant_id})")

        # ── 2. App ─────────────────────────────────────────────────
        app = await conn.fetchrow("""
            INSERT INTO apps (tenant_id, app_name, created_by, updated_by)
            VALUES ($1, $2, $3, $3)
            ON CONFLICT (tenant_id, app_name) DO UPDATE
            SET app_name = EXCLUDED.app_name,
                updated_by = EXCLUDED.updated_by
            RETURNING id
        """, tenant_id, app_name, SYSTEM_ACTOR_ID)
        app_id = app['id']
        logger.info(f"App '{app_name}' ready (id={app_id})")

        # ── 3. Password provider ───────────────────────────────────
        password_provider = await conn.fetchrow("""
            INSERT INTO providers (
                tenant_id, provider_name, issuer_url,
                idp_config, config, is_active, created_by, updated_by
            )
            VALUES ($1, 'password', 'internal://password', '{}', '{"provider_type": "password"}', TRUE, $2, $2)
            ON CONFLICT (tenant_id, provider_name) DO UPDATE
            SET is_active = TRUE,
                updated_by = EXCLUDED.updated_by
            RETURNING id
        """, tenant_id, SYSTEM_ACTOR_ID)
        password_provider_id = password_provider['id']
        logger.info(f"Password provider ready (id={password_provider_id})")

        # ── 4. Link app → password provider ───────────────────────
        await conn.execute("""
            INSERT INTO app_providers (app_id, provider_id, tenant_id, is_active, created_by, updated_by)
            VALUES ($1, $2, $3, TRUE, $4, $4)
            ON CONFLICT (app_id, provider_id) DO UPDATE
            SET is_active = TRUE,
                updated_by = EXCLUDED.updated_by
        """, app_id, password_provider_id, tenant_id, SYSTEM_ACTOR_ID)

        # ── 4.5 OAuth providers ─────────────────────────────────────
        providers_created = 0
        if providers:
            for provider_config in providers:
                provider_name = provider_config['provider_name']
                issuer_url = provider_config['issuer_url']
                client_id = provider_config['client_id']
                client_secret = provider_config['client_secret']
                redirect_uri = provider_config['redirect_uri']

                idp_config = {
                    "client_id": client_id,
                    "client_secret": client_secret,
                    "redirect_uris": [redirect_uri],
                }
                try:
                    import httpx
                    discovery_url = f"{issuer_url.rstrip('/')}/.well-known/openid-configuration"
                    async with httpx.AsyncClient() as client:
                        response = await client.get(discovery_url)
                        if response.status_code == 200:
                            discovery = response.json()
                            idp_config.update({
                                "authorize_url": discovery.get("authorization_endpoint"),
                                "token_url": discovery.get("token_endpoint"),
                                "userinfo_url": discovery.get("userinfo_endpoint"),
                                "revoke_url": discovery.get("revocation_endpoint"),
                                "allowed_scopes": discovery.get("scopes_supported", ["openid", "profile", "email"]),
                            })
                            logger.info(f"OIDC discovery successful for '{provider_name}'")
                        else:
                            logger.warning(f"OIDC discovery failed for '{provider_name}', using minimal config")
                except Exception as e:
                    logger.warning(f"OIDC discovery error for '{provider_name}': {e}, using minimal config")

                oauth_provider = await conn.fetchrow("""
                    INSERT INTO providers (
                        tenant_id, provider_name, issuer_url,
                        idp_config, config, is_active, created_by, updated_by
                    )
                    VALUES ($1, $2, $3, $4, '{}', TRUE, $5, $5)
                    ON CONFLICT (tenant_id, provider_name) DO UPDATE
                    SET idp_config = EXCLUDED.idp_config,
                        issuer_url = EXCLUDED.issuer_url,
                        is_active = TRUE,
                        updated_by = EXCLUDED.updated_by
                    RETURNING id
                """, tenant_id, provider_name, issuer_url,
                    json.dumps(idp_config), SYSTEM_ACTOR_ID)
                oauth_provider_id = oauth_provider['id']
                await conn.execute("""
                    INSERT INTO app_providers (app_id, provider_id, tenant_id, is_active, created_by, updated_by)
                    VALUES ($1, $2, $3, TRUE, $4, $4)
                    ON CONFLICT (app_id, provider_id) DO UPDATE
                    SET is_active = TRUE,
                        updated_by = EXCLUDED.updated_by
                """, app_id, oauth_provider_id, tenant_id, SYSTEM_ACTOR_ID)
                logger.info(f"OAuth provider '{provider_name}' ready (id={oauth_provider_id})")
                providers_created += 1

        # ── 5. Roles ───────────────────────────────────────────────
        role_ids = {}
        for role_config in roles:
            role_name = role_config['name']
            role_desc = role_config.get('description', '')
            role = await conn.fetchrow("""
                INSERT INTO roles (tenant_id, name, description, is_active, created_by, updated_by)
                VALUES ($1, $2, $3, TRUE, $4, $4)
                ON CONFLICT (tenant_id, name) DO UPDATE
                SET description = EXCLUDED.description,
                    updated_by = EXCLUDED.updated_by
                RETURNING id
            """, tenant_id, role_name, role_desc, SYSTEM_ACTOR_ID)
            role_ids[role_name] = role['id']
        logger.info(f"Created {len(role_ids)} roles")

        # ── 6. Groups ──────────────────────────────────────────────
        group_ids = {}
        default_group_name = None
        for group_config in groups:
            group_name = group_config['name']
            group_desc = group_config.get('description', '')
            parent_group = group_config.get('parent_group')
            parent_group_id = group_ids.get(parent_group) if parent_group else None
            is_default = group_config.get('is_default', False)

            group = await conn.fetchrow("""
                INSERT INTO u_groups (tenant_id, name, description, parent_group_id, is_default, is_active, created_by, updated_by)
                VALUES ($1, $2, $3, $4, $5, TRUE, $6, $6)
                ON CONFLICT (tenant_id, name) DO UPDATE
                SET description = EXCLUDED.description,
                    parent_group_id = EXCLUDED.parent_group_id,
                    is_default = EXCLUDED.is_default,
                    updated_by = EXCLUDED.updated_by
                RETURNING id
            """, tenant_id, group_name, group_desc, parent_group_id, is_default, SYSTEM_ACTOR_ID)
            group_ids[group_name] = group['id']
            if is_default:
                default_group_name = group_name

        logger.info(f"Created {len(group_ids)} groups (default: '{default_group_name}')")

        # ── 7. Role-group mappings → group_roles ───────────────────
        mappings_created = 0
        for group_name, role_name in role_group_mappings.items():
            if group_name in group_ids and role_name in role_ids:
                await conn.execute("""
                    INSERT INTO group_roles (group_id, role_id, assigned_by)
                    VALUES ($1, $2, $3)
                    ON CONFLICT (group_id, role_id) DO NOTHING
                """, group_ids[group_name], role_ids[role_name], SYSTEM_ACTOR_ID)
                mappings_created += 1
            else:
                logger.warning(f"Skipping mapping '{group_name}' -> '{role_name}': not found")
        logger.info(f"Created {mappings_created} role-group mappings")

        # ── 8. Super-admin user ────────────────────────────────────
        user = await conn.fetchrow(
            "SELECT id FROM users WHERE tenant_id = $1 AND email = $2",
            tenant_id, admin_email
        )
        if user:
            user_id = user['id']
            logger.info(f"Super-admin already exists: {admin_email} (id={user_id})")
        else:
            user = await conn.fetchrow("""
                INSERT INTO users (
                    tenant_id, email, password_hash,
                    first_name, last_name, display_name, is_active, created_by, updated_by
                )
                VALUES ($1, $2, $3, $4, $5, $6, TRUE, $7, $7)
                RETURNING id
            """, tenant_id, admin_email, admin_password_hash,
                admin_first_name, admin_last_name, admin_display_name, SYSTEM_ACTOR_ID)
            user_id = user['id']
            logger.info(f"Created super-admin: {admin_email} (id={user_id})")

        # Assign super-admin to the first group
        admin_group_name = list(group_ids.keys())[0]
        admin_group_id = group_ids[admin_group_name]
        await conn.execute("""
            INSERT INTO user_groups (tenant_id, user_id, group_id, assigned_by)
            VALUES ($1, $2, $3, $4)
            ON CONFLICT (user_id, group_id) DO NOTHING
        """, tenant_id, user_id, admin_group_id, SYSTEM_ACTOR_ID)

        # ── 9. RSA key pair ─────────────────────────────────────────
        key_exists = await conn.fetchval(
            "SELECT EXISTS(SELECT 1 FROM tenant_keys WHERE tenant_id = $1)", tenant_id
        )
        if not key_exists:
            from cryptography.hazmat.primitives.asymmetric import rsa
            from cryptography.hazmat.primitives import serialization

            private_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
            private_pem = private_key.private_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PrivateFormat.PKCS8,
                encryption_algorithm=serialization.NoEncryption(),
            ).decode()
            public_pem = private_key.public_key().public_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PublicFormat.SubjectPublicKeyInfo,
            ).decode()
            await conn.execute("""
                INSERT INTO tenant_keys (tenant_id, public_key_pem, private_key_pem, created_by, updated_by)
                VALUES ($1, $2, $3, $4, $4)
            """, tenant_id, public_pem, private_pem, SYSTEM_ACTOR_ID)
            logger.info(f"Generated RSA keys for tenant: {tenant_name}")

        # ── 10. Business entity hierarchy (GENERIC N-LEVEL) ─────────
        level_ids = {}   # name -> id
        entity_ids = {}  # name -> id
        scope_ids = {}   # entity_name -> scope_id (auto-created alongside entities)

        # 10.1 Seed scope_entity_levels from config
        for level_config in (entity_hierarchy or {}).get('levels', []):
            level_name = level_config['name']
            level_depth = level_config['depth']
            level_desc = level_config.get('description', '')

            level_row = await conn.fetchrow("""
                INSERT INTO scope_entity_levels (tenant_id, name, depth, description, is_active)
                VALUES ($1, $2, $3, $4, TRUE)
                ON CONFLICT (tenant_id, name) DO UPDATE
                SET depth = EXCLUDED.depth, description = EXCLUDED.description
                RETURNING id
            """, tenant_id, level_name, level_depth, level_desc)
            level_ids[level_name] = level_row['id']
        logger.info(f"Seeded {len(level_ids)} scope entity levels")

        # 10.2 Seed scope_entities in depth order (parents before children)
        entities_by_level = {}
        for entity_config in (entity_hierarchy or {}).get('entities', []):
            level_name = entity_config['level']
            if level_name not in entities_by_level:
                entities_by_level[level_name] = []
            entities_by_level[level_name].append(entity_config)

        # Sort by depth (parents first)
        sorted_entities = []
        for level_name in sorted(entities_by_level.keys(), key=lambda ln: level_ids.get(ln, 0)):
            sorted_entities.extend(entities_by_level[level_name])

        for entity_config in sorted_entities:
            entity_name = entity_config['name']
            level_name = entity_config['level']
            parent_name = entity_config.get('parent')
            entity_desc = entity_config.get('description', '')
            entity_meta = entity_config.get('metadata', {})

            level_id = level_ids.get(level_name)
            if not level_id:
                logger.warning(f"Skipping entity '{entity_name}': level '{level_name}' not found")
                continue

            parent_id = None
            if parent_name:
                parent_id = entity_ids.get(parent_name)
                if not parent_id:
                    logger.warning(f"Skipping entity '{entity_name}': parent '{parent_name}' not found")
                    continue

            entity_row = await conn.fetchrow("""
                INSERT INTO scope_entities
                    (tenant_id, level_id, parent_id, name, description, metadata, is_active, created_by, updated_by)
                VALUES ($1, $2, $3, $4, $5, $6, TRUE, $7, $7)
                ON CONFLICT (COALESCE(parent_id, -1), name) DO UPDATE
                SET description = EXCLUDED.description,
                    metadata = EXCLUDED.metadata,
                    is_active = TRUE
                RETURNING id
            """, tenant_id, level_id, parent_id, entity_name, entity_desc,
                json.dumps(entity_meta), SYSTEM_ACTOR_ID)
            entity_ids[entity_name] = entity_row['id']

            # Auto-create scope with same name (mirrors entity_router API behaviour)
            scope_row = await conn.fetchrow("""
                INSERT INTO scopes (tenant_id, name, entity_id, description, is_active, created_by, updated_by)
                VALUES ($1, $2, $3, $4, TRUE, $5, $5)
                ON CONFLICT (tenant_id, name) DO UPDATE
                SET entity_id = EXCLUDED.entity_id,
                    description = EXCLUDED.description,
                    updated_by = EXCLUDED.updated_by
                RETURNING id
            """, tenant_id, entity_name, entity_row['id'], entity_desc, SYSTEM_ACTOR_ID)
            scope_ids[entity_name] = scope_row['id']

        logger.info(f"Seeded {len(entity_ids)} scope entities with auto-created scopes")

        # ── 11. RBAC configuration ──────────────────────────────────
        rbac_summary = {}
        if rbac_config:
            # 13.1 Actions
            action_ids = {}
            for action_config in rbac_config.get('actions', []):
                action_name = action_config if isinstance(action_config, str) else action_config['name']
                action_desc = '' if isinstance(action_config, str) else action_config.get('description', '')
                action = await conn.fetchrow("""
                    INSERT INTO actions (name, description)
                    VALUES ($1, $2)
                    ON CONFLICT (name) DO UPDATE
                    SET description = EXCLUDED.description
                    RETURNING id
                """, action_name, action_desc)
                action_ids[action_name] = action['id']
            logger.info(f"Seeded {len(action_ids)} actions")

            # 13.2 Resource groups
            resource_group_ids = {}
            for rg_config in rbac_config.get('resource_groups', []):
                rg_name = rg_config['name']
                rg_display = rg_config.get('display_name', rg_name)
                rg_desc = rg_config.get('description', '')
                rg = await conn.fetchrow("""
                    INSERT INTO resource_groups (
                        app_id, name, display_name, description, is_active, created_by, updated_by
                    )
                    VALUES ($1, $2, $3, $4, TRUE, $5, $5)
                    ON CONFLICT (app_id, name) DO UPDATE
                    SET display_name = EXCLUDED.display_name,
                        description = EXCLUDED.description,
                        updated_by = EXCLUDED.updated_by
                    RETURNING id
                """, app_id, rg_name, rg_display, rg_desc, SYSTEM_ACTOR_ID)
                resource_group_ids[rg_name] = rg['id']
            logger.info(f"Seeded {len(resource_group_ids)} resource groups")

            # 13.3 Resources
            resource_ids = {}
            for res_config in rbac_config.get('resources', []):
                res_name = res_config['name']
                res_display = res_config.get('display_name', res_name)
                res_desc = res_config.get('description', '')
                res_pattern = res_config.get('pattern')
                res_is_pattern = res_config.get('is_pattern', False)
                res_group_name = res_config.get('resource_group')
                res_group_id = resource_group_ids.get(res_group_name) if res_group_name else None

                res = await conn.fetchrow("""
                    INSERT INTO resources (
                        app_id, name, display_name, description,
                        pattern, is_pattern, resource_group_id, is_active, created_by, updated_by
                    )
                    VALUES ($1, $2, $3, $4, $5, $6, $7, TRUE, $8, $8)
                    ON CONFLICT (app_id, name) DO UPDATE
                    SET display_name = EXCLUDED.display_name,
                        description = EXCLUDED.description,
                        pattern = EXCLUDED.pattern,
                        is_pattern = EXCLUDED.is_pattern,
                        resource_group_id = EXCLUDED.resource_group_id,
                        updated_by = EXCLUDED.updated_by
                    RETURNING id
                """, app_id, res_name, res_display, res_desc,
                     res_pattern, res_is_pattern, res_group_id, SYSTEM_ACTOR_ID)
                resource_ids[res_name] = res['id']
            logger.info(f"Seeded {len(resource_ids)} resources")

            # 13.4 Policies (no scope_id — pure role capabilities)
            policy_count = 0
            for policy_config in rbac_config.get('policies', []):
                role_name = policy_config['role']
                action_name = policy_config['action']
                is_allowed = policy_config.get('is_allowed', True)

                role_id = role_ids.get(role_name)
                action_id = action_ids.get(action_name)

                resource_name = policy_config.get('resource')
                resource_group_name = policy_config.get('resource_group')
                resource_id = resource_ids.get(resource_name) if resource_name else None
                resource_group_id = resource_group_ids.get(resource_group_name) if resource_group_name else None

                if not role_id or not action_id:
                    logger.warning(f"Skipping policy: role='{role_name}' or action='{action_name}' not found")
                    continue
                if not resource_id and not resource_group_id:
                    logger.warning("Skipping policy: must specify 'resource' or 'resource_group'")
                    continue

                if resource_id is not None:
                    await conn.execute("""
                        INSERT INTO rbac_policies (
                            tenant_id, role_id, resource_id, resource_group_id,
                            action_id, is_allowed, created_by
                        )
                        VALUES ($1, $2, $3, NULL, $4, $5, $6)
                        ON CONFLICT DO NOTHING
                    """, tenant_id, role_id, resource_id, action_id, is_allowed, SYSTEM_ACTOR_ID)
                else:
                    await conn.execute("""
                        INSERT INTO rbac_policies (
                            tenant_id, role_id, resource_id, resource_group_id,
                            action_id, is_allowed, created_by
                        )
                        VALUES ($1, $2, NULL, $3, $4, $5, $6)
                        ON CONFLICT DO NOTHING
                    """, tenant_id, role_id, resource_group_id, action_id, is_allowed, SYSTEM_ACTOR_ID)
                policy_count += 1
            logger.info(f"Seeded {policy_count} RBAC policies")

            rbac_summary = {
                'actions': len(action_ids),
                'resource_groups': len(resource_group_ids),
                'resources': len(resource_ids),
                'policies': policy_count,
            }

        # ── 12. Group-scope assignments ────────────────────────────
        gs_count = 0
        if group_scope_mappings:
            for group_name, scope_names in group_scope_mappings.items():
                group_id = group_ids.get(group_name)
                if not group_id:
                    logger.warning(f"Skipping group-scope mapping: group '{group_name}' not found")
                    continue

                for scope_name in scope_names:
                    scope_id = scope_ids.get(scope_name)
                    if not scope_id:
                        logger.warning(f"Skipping group-scope: scope '{scope_name}' not found")
                        continue

                    await conn.execute("""
                        INSERT INTO group_scopes (tenant_id, group_id, scope_id, assigned_by)
                        VALUES ($1, $2, $3, $4)
                        ON CONFLICT (group_id, scope_id) DO NOTHING
                    """, tenant_id, group_id, scope_id, SYSTEM_ACTOR_ID)
                    gs_count += 1
            logger.info(f"Seeded {gs_count} group-scope assignments")

        return {
            'tenant_id': tenant_id,
            'tenant_name': tenant_name,
            'app_id': app_id,
            'app_name': app_name,
            'user_id': user_id,
            'admin_email': admin_email,
            'roles_created': len(role_ids),
            'groups_created': len(group_ids),
            'providers_created': providers_created,
            'entity_levels_created': len(level_ids),
            'entities_created': len(entity_ids),
            'scopes_created': len(scope_ids),
            'group_scope_assignments': gs_count,
            'rbac': rbac_summary,
        }
