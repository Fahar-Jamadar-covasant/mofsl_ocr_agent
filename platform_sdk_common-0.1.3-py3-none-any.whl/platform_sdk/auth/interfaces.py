"""
OAuth 2.1 interfaces, configuration, data models, and abstract contracts.

Supports both STANDALONE (direct IDP) and PLATFORM (centralised service) modes.
Unified schema (v2) across both modes:
    tenants              – SERIAL PK id. tenant_name UNIQUE. No IDP fields.
    tenant_properties    – Key/value metadata for tenants. UNIQUE(tenant_id, property_key).
    providers            – SERIAL PK id. Tenant-scoped. Credentials + endpoints in idp_config JSONB.
                           UNIQUE(tenant_id, provider_name).
    apps                 – SERIAL PK id. Tenant-scoped. app_name only. UNIQUE(tenant_id, app_name).
    app_providers        – Pure mapping (app_id INT FK, provider_id INT FK). No credentials.
    sessions             – PK id (TEXT). tokens JSONB {idp, platform}. user_attributes JSONB. issued_at.
    oauth_states         – app_id / provider_id are INTEGER FKs.
    tenant_keys          – RSA key pairs per tenant for JWT signing.
    users                – User records with optional password_hash for email/password login.
    user_identities      – Links users to external IDP identities.
    u_groups, roles      – User groups and roles for authorization.

API contract: all external endpoints accept names (tenant_name, app_name, provider_name).
Database joins use integer SERIAL PKs internally.

All created_by / updated_by fields are Optional[int] (user ID).
"""

from abc import ABC, abstractmethod
from enum import Enum
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple, Union

from pydantic import BaseModel, Field, field_validator, model_validator
from platform_sdk.common import BaseConfig, SDKException


# ──────────────────────────────────────────────
# Exceptions
# ──────────────────────────────────────────────

class OAuthError(SDKException):
    """Base OAuth operation error."""

    def __init__(
        self,
        message: str,
        provider: Optional[str] = None,
        error_code: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None,
    ):
        super().__init__(message, details=details or {})
        self.provider = provider
        self.error_code = error_code


class OAuthConfigurationError(SDKException):
    """Raised when OAuth configuration is invalid."""
    pass


class OAuthTokenExpiredError(OAuthError):
    """Raised when a wrapper JWT or inner OAuth token has expired."""
    pass


class InitializationError(SDKException):
    """Raised when standalone initialization fails."""
    pass


# ──────────────────────────────────────────────
# Enums
# ──────────────────────────────────────────────

class OAuthMode(str, Enum):
    """
    STANDALONE – app talks directly to the IDP.
    PLATFORM   – app talks to the centralised Platform OAuth service.
    """
    STANDALONE = "STANDALONE"
    PLATFORM = "PLATFORM"


class JWTAlgorithm(str, Enum):
    """
    HS256 – symmetric key, same secret signs and verifies (STANDALONE).
    RS256 – asymmetric key, private key signs, public key verifies (PLATFORM).
    """
    HS256 = "HS256"
    RS256 = "RS256"


# ──────────────────────────────────────────────
# Configuration
# ──────────────────────────────────────────────

class OAuthConfig(BaseConfig):
    """
    Unified configuration for both STANDALONE and PLATFORM modes.

    STANDALONE:
        - All provider config comes from database
        - Use explicit endpoints: /login/{tenant}/{app}/{provider}
        - Only JWT settings required

    PLATFORM:
        - Requires platform_oauth_url
        - JWT settings for platform service
        - platform_api_key is optional (not validated by platform service)
    """

    # ── mode ──
    mode: OAuthMode = Field(
        OAuthMode.STANDALONE, description="STANDALONE or PLATFORM"
    )

    # ── standalone defaults (STANDALONE only) ──
    default_tenant_name: Optional[str] = Field(
        None, description="Default tenant name for STANDALONE mode"
    )
    default_app_name: Optional[str] = Field(
        None, description="Default app name for STANDALONE mode"
    )
    default_provider_name: Optional[str] = Field(
        None, description="Default provider name for STANDALONE mode"
    )

    # ── platform fields (PLATFORM only) ──
    platform_oauth_url: Optional[str] = Field(
        None, description="Base URL of Platform OAuth service (PLATFORM)",
    )
    platform_api_key: Optional[str] = Field(
        None, description="Optional API key for Platform service (not currently validated)",
    )

    # ── JWT wrapper settings ──
    jwt_algorithm: JWTAlgorithm = Field(
        default=JWTAlgorithm.HS256,
        description="HS256 for STANDALONE, RS256 for PLATFORM",
    )
    jwt_signing_key: Optional[str] = Field(
        None,
        description="HS256: shared secret. RS256: PEM private key (platform service only).",
    )
    jwt_public_key: Optional[str] = Field(
        None,
        description="RS256: PEM public key for verification (app clients).",
    )
    jwt_jwks_uri: Optional[str] = Field(
        None,
        description="RS256: JWKS endpoint to fetch public keys.",
    )
    jwt_issuer: str = Field(..., description="'iss' claim in wrapper JWT")
    jwt_audience: str = Field(..., description="'aud' claim in wrapper JWT")
    jwt_expiry_seconds: int = Field(default=3600, description="Wrapper JWT lifetime (seconds)")

    # ── database (PLATFORM) ──
    database_url: Optional[str] = Field(
        None,
        description="Postgres DSN for tenant/provider/session storage (PLATFORM). "
                    "e.g. postgresql://user:pass@host:5432/dbname",
    )

    @model_validator(mode="after")
    def _check_mode_fields(self) -> "OAuthConfig":
        if self.mode == OAuthMode.STANDALONE:
            if not self.jwt_signing_key:
                raise ValueError("STANDALONE mode requires jwt_signing_key (HS256 secret)")
            # client_id, client_secret, issuer_url, provider_name are all DB-driven.
            # They are resolved per-request from app_providers + providers tables.

        elif self.mode == OAuthMode.PLATFORM:
            # Platform service doesn't need platform_oauth_url or platform_api_key
            # Those are for client apps that consume the platform service
            # Platform service IS the OAuth provider
            if not self.jwt_jwks_uri:
                raise ValueError("PLATFORM mode requires jwt_jwks_uri for JWT verification")
        return self


# ──────────────────────────────────────────────
# Data Models – JWT / OAuth
# ──────────────────────────────────────────────

class OAuthResult(BaseConfig):
    """Returned to the caller after login / refresh."""
    jwt_token: str = Field(..., description="Signed wrapper JWT (short-lived, ~30 min)")
    refresh_token: Optional[str] = Field(None, description="Platform-generated opaque refresh token (24h)")
    session_id: str = Field(..., description="Session ID for tracking")
    user_id: str
    email: Optional[str] = None
    name: Optional[str] = None
    roles: List[str] = Field(default_factory=list)
    groups: List[str] = Field(default_factory=list)
    provider: str
    tenant_id: Optional[int] = None
    expires_at: Optional[float] = None


class OAuthState(BaseConfig):
    """Tracks OAuth state across redirects (CSRF + PKCE)."""
    state: str = Field(..., description="Random CSRF state string")
    tenant_id: Optional[int] = Field(None, description="Resolved tenant integer ID")
    app_id: Optional[int] = Field(None, description="Resolved app integer ID")
    provider_id: Optional[int] = Field(None, description="Resolved provider integer ID")
    tenant_name: Optional[str] = Field(None, description="Business name (for PLATFORM POST body)")
    app_name: Optional[str] = Field(None, description="Business name (for PLATFORM POST body)")
    provider_name: Optional[str] = Field(None, description="Business name (for PLATFORM POST body)")
    redirect_uri: Optional[str] = None
    code_verifier: Optional[str] = None
    created_at: float
    expires_at: float
    created_by: Optional[int] = None
    frontend_callback_url: Optional[str] = Field(None, description="Frontend callback URL for token redirect")


# ──────────────────────────────────────────────
# Data Models – Provider (IDP configuration)
# ──────────────────────────────────────────────

class ProviderConfig(BaseConfig):
    """
    Identity Provider configuration. Tenant-scoped (one row per tenant+provider pair).

    idp_config JSONB holds all IDP-credential and endpoint details:
        client_id, client_secret, redirect_uris, allowed_scopes,
        authorize_url, token_url, userinfo_url, revoke_url.
    config JSONB holds non-credential discovery metadata:
        jwks_url, scopes_supported, default_scopes, provider_type.
    """
    id: Optional[int] = Field(None, description="SERIAL PK – auto-generated")
    uuid: Optional[str] = Field(None, description="UUID for internal tracking")
    tenant_id: int = Field(..., description="FK to tenants.id")
    provider_name: str = Field(..., description="Slug e.g. 'google', 'azure-ad'. UNIQUE per tenant.")
    issuer_url: str = Field(..., description="OIDC issuer URL, used for auto-discovery")
    idp_config: Dict[str, Any] = Field(
        default_factory=dict,
        description="JSONB – credentials + endpoints: client_id, client_secret, "
                    "redirect_uris, allowed_scopes, authorize_url, token_url, "
                    "userinfo_url, revoke_url.",
    )
    config: Dict[str, Any] = Field(
        default_factory=dict,
        description="JSONB – non-credential metadata: jwks_url, scopes_supported, "
                    "default_scopes, provider_type.",
    )
    is_active: bool = Field(default=True)
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    created_by: Optional[int] = None
    updated_by: Optional[int] = None
    
    @field_validator('uuid', mode='before')
    @classmethod
    def convert_uuid_to_str(cls, v):
        """Convert UUID object to string if needed."""
        if v is not None and not isinstance(v, str):
            return str(v)
        return v


# ──────────────────────────────────────────────
# Data Models – Tenant (clean – no IDP fields)
# ──────────────────────────────────────────────

class TenantConfig(BaseConfig):
    """
    Tenant (customer organisation). Clean – no IDP fields.
    Identified externally by tenant_name (UNIQUE). tenant_id is the SERIAL integer PK.
    """
    tenant_id: Optional[int] = Field(None, description="SERIAL PK (column 'id' in DB)")
    uuid: Optional[str] = Field(None, description="UUID for internal tracking")
    tenant_name: str = Field(..., description="Unique tenant name e.g. 'acme'")
    tenant_description: Optional[str] = Field(None, description="Description of the tenant")
    domain: Optional[str] = Field(None, description="Primary domain e.g. 'acme.com'")
    is_active: bool = Field(default=True)
    details: Optional[Dict[str, Any]] = Field(default=None, description="Extra metadata (JSONB)")
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    created_by: Optional[int] = None
    updated_by: Optional[int] = None
    
    @field_validator('uuid', mode='before')
    @classmethod
    def convert_uuid_to_str(cls, v):
        """Convert UUID object to string if needed."""
        if v is not None and not isinstance(v, str):
            return str(v)
        return v


class TenantProperty(BaseConfig):
    """
    Tenant property – key/value metadata for a tenant.
    Provides structured, searchable, and individually auditable properties.
    UNIQUE(tenant_id, property_key).
    """
    id: Optional[int] = Field(None, description="SERIAL PK")
    tenant_id: int = Field(..., description="FK to tenants.id")
    property_key: str = Field(..., description="Property key (e.g., 'max_user_count')")
    property_value: str = Field(..., description="Property value")
    is_active: bool = Field(default=True)
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    created_by: Optional[int] = None
    updated_by: Optional[int] = None


# ──────────────────────────────────────────────
# Data Models – App-Provider Junction
# ──────────────────────────────────────────────

class AppProviderConfig(BaseConfig):
    """
    Pure mapping: which app uses which provider.
    Credentials are stored in providers.idp_config (tenant-scoped).
    UNIQUE(app_id, provider_id).
    tenant_id is denormalised for fast admin queries.
    """
    id: Optional[int] = Field(None, description="SERIAL PK")
    app_id: int = Field(..., description="FK to apps.id (integer)")
    tenant_id: int = Field(..., description="FK to tenants.id (denormalised)")
    provider_id: int = Field(..., description="FK to providers.id (integer)")
    is_active: bool = Field(default=True)
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    created_by: Optional[int] = None
    updated_by: Optional[int] = None


# ──────────────────────────────────────────────
# Data Models – App (per-tenant applications)
# ──────────────────────────────────────────────

class AppConfig(BaseConfig):
    """
    Application registered under a tenant.
    Identified externally by app_name (UNIQUE per tenant). id is the SERIAL integer PK.
    redirect_uris and allowed_scopes are stored in providers.idp_config.
    """
    id: Optional[int] = Field(None, description="SERIAL PK")
    uuid: Optional[str] = Field(None, description="UUID for internal tracking")
    tenant_id: int = Field(..., description="FK to tenants.id")
    app_name: str = Field(..., description="App name e.g. 'etlopt'. UNIQUE per tenant.")
    is_active: bool = Field(default=True)
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    created_by: Optional[int] = None
    updated_by: Optional[int] = None
    
    @field_validator('uuid', mode='before')
    @classmethod
    def convert_uuid_to_str(cls, v):
        """Convert UUID object to string if needed."""
        if v is not None and not isinstance(v, str):
            return str(v)
        return v


# ──────────────────────────────────────────────
# Data Models – Session
# ──────────────────────────────────────────────

class SessionRecord(BaseConfig):
    """
    Tracks a user login session.

    tokens JSONB structure:
        {"idp": {access_token, refresh_token, id_token, expires_at, ...},
         "platform": {access_token, refresh_token, expires_at}}
    IDP tokens are server-side only; platform tokens are returned to the client.

    user_attributes JSONB holds extensible user profile:
        {"email": "...", "name": "...", "roles": [], "groups": [], ...}
    """
    session_id: str = Field(..., description="Unique session identifier (UUID)")
    tenant_id: int = Field(..., description="FK to tenants.id")
    app_id: int = Field(..., description="FK to apps.id (integer)")
    provider_id: int = Field(..., description="FK to providers.id (integer)")
    user_id: int = Field(..., description="FK to users.id (internal database user ID)")
    user_attributes: Dict[str, Any] = Field(
        default_factory=dict,
        description="JSONB – extensible user profile: email, name, roles, groups, etc.",
    )
    tokens: Dict[str, Any] = Field(
        default_factory=dict,
        description="JSONB – {idp: {...}, platform: {...}}. IDP tokens server-side only.",
    )
    audit_log: List[Dict[str, Any]] = Field(
        default_factory=list,
        description="JSONB array – audit trail of scope switches and actions",
    )
    issued_at: float = Field(..., description="Unix timestamp when session was issued")
    expires_at: float = Field(..., description="Unix timestamp of session expiry")
    is_revoked: bool = Field(default=False)
    active_scope_id: Optional[int] = Field(None, description="FK to scopes.id — current active scope context. None if global.")
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    created_by: Optional[int] = None
    updated_by: Optional[int] = None


# ──────────────────────────────────────────────
# Initialization Models
# ──────────────────────────────────────────────

class InitializeStandaloneRequest(BaseConfig):
    """Request model for standalone initialization endpoint."""
    tenant_name: str = Field(..., description="Tenant name (e.g., 'acme')")
    tenant_description: Optional[str] = Field(None, description="Description of the tenant")
    domain: Optional[str] = Field(None, description="Primary domain e.g. 'acme.com'")
    details: Optional[Dict[str, Any]] = Field(default=None, description="Extra metadata (JSONB)")
    created_by: Optional[int] = Field(None, description="Audit: user ID who created")
    updated_by: Optional[int] = Field(None, description="Audit: user ID who last updated")
    app_name: str = Field(..., description="Application name (e.g., 'etlopt')")
    provider_name: str = Field(..., description="Provider name (e.g., 'google', 'microsoft')")
    issuer_url: str = Field(..., description="OIDC issuer URL (e.g., 'https://accounts.google.com')")
    client_id: str = Field(..., description="OAuth client ID from IdP")
    client_secret: str = Field(..., description="OAuth client secret from IdP")
    redirect_uri: str = Field(..., description="OAuth redirect URI (e.g., 'http://localhost:8000/auth/callback')")


class InitializeStandaloneResponse(BaseConfig):
    """Response model for standalone initialization endpoint."""
    success: bool = Field(..., description="Whether initialization succeeded")
    tenant_id: int = Field(..., description="Created/existing tenant ID")
    tenant_name: str = Field(..., description="Tenant name")
    app_id: int = Field(..., description="Created/existing app ID")
    app_name: str = Field(..., description="App name")
    provider_id: int = Field(..., description="Created/existing provider ID")
    provider_name: str = Field(..., description="Provider name")
    message: str = Field(..., description="Status message")
    scopes: List[str] = Field(default_factory=list, description="OAuth scopes configured")


# ──────────────────────────────────────────────
# Abstract Provider
# ──────────────────────────────────────────────

class OAuth2Provider(ABC):
    """Contract every OAuth implementation must satisfy."""

    @abstractmethod
    async def get_auth_url(self, tenant_id: Any, **params) -> Tuple[str, str]:
        """Return (authorization_url, state)."""
        ...

    @abstractmethod
    async def do_login(self, auth_code: str, state: str, **params) -> OAuthResult:
        """Exchange auth code for OAuthResult containing wrapper JWT."""
        ...

    @abstractmethod
    async def do_logout(self, jwt_token: str, **params) -> bool:
        """Revoke tokens, return True on success."""
        ...

    @abstractmethod
    async def do_refresh(self, token: str, **params) -> OAuthResult:
        """
        Refresh tokens, return new OAuthResult.
        
        STANDALONE: token = jwt_token (extracts session_id to retrieve stored IDP refresh_token)
        PLATFORM: token = platform_refresh_token (opaque token sent to platform service)
        """
        ...

    @abstractmethod
    async def get_user_profile(self, jwt_token: str) -> Dict[str, Any]:
        """Return user-info dict from the IDP."""
        ...


# ──────────────────────────────────────────────
# USER MANAGEMENT MODELS
# ──────────────────────────────────────────────

# User Models
class UserRecord(BaseModel):
    """User record from database."""
    id: int
    uuid: Optional[str] = None
    tenant_id: int
    email: str
    password_hash: Optional[str] = None
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    display_name: Optional[str] = None
    is_active: bool = True
    last_login_at: Optional[datetime] = None
    created_at: datetime
    updated_at: datetime

    created_by: Optional[int] = None
    updated_by: Optional[int] = None

    @field_validator('uuid', mode='before')
    @classmethod
    def convert_uuid_to_str(cls, v):
        if v is not None and not isinstance(v, str):
            return str(v)
        return v


class UserCreateRequest(BaseModel):
    """Request to create a user."""
    email: str = Field(..., description="User email (unique per tenant)")
    password: Optional[str] = Field(None, description="Password for password-based authentication (optional)")
    first_name: Optional[str] = Field(None, description="First name")
    last_name: Optional[str] = Field(None, description="Last name")
    display_name: Optional[str] = Field(None, description="Display name")
    is_active: bool = Field(True, description="Whether user is active")


class UserUpdateRequest(BaseModel):
    """Request to update a user."""
    password: Optional[str] = Field(None, description="New password for password-based authentication (optional)")
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    display_name: Optional[str] = None
    is_active: Optional[bool] = None


# User Identity Models
class UserIdentityRecord(BaseModel):
    """User identity linking user to IdP."""
    id: int
    user_id: int
    provider_id: int
    external_user_id: str
    idp_attributes: Dict[str, Any] = Field(default_factory=dict)
    last_synced_at: Optional[datetime] = None
    created_at: datetime
    updated_at: datetime
    provider_name: Optional[str] = None  # Joined from providers table


# Group Models
class GroupRecord(BaseModel):
    """Group record from database."""
    id: int
    tenant_id: int
    group_name: str
    parent_group_id: Optional[int] = None
    description: Optional[str] = None
    is_active: bool = True
    is_default: bool = False
    created_at: datetime
    updated_at: datetime
    created_by: Optional[int] = None
    updated_by: Optional[int] = None


class GroupDetailRecord(BaseModel):
    """Group with assigned scopes and roles (enriched response)."""
    id: int
    tenant_id: int
    group_name: str
    parent_group_id: Optional[int] = None
    description: Optional[str] = None
    is_active: bool = True
    is_default: bool = False
    created_at: datetime
    updated_at: datetime
    created_by: Optional[int] = None
    updated_by: Optional[int] = None
    scopes: List["ScopeRecord"] = Field(default_factory=list, description="Assigned scopes")
    roles: List["RoleRecord"] = Field(default_factory=list, description="Assigned roles")


class GroupCreateRequest(BaseModel):
    """Request to create a group."""
    group_name: str = Field(..., description="Group display name")
    parent_group_id: Optional[int] = Field(None, description="Parent group ID for hierarchy")
    description: Optional[str] = Field(None, description="Group description")
    is_default: bool = Field(False, description="Mark as default group for new OAuth users")
    scope_ids: List[int] = Field(default_factory=list, description="Scope IDs to assign to this group at creation")
    role_ids: List[int] = Field(default_factory=list, description="Role IDs to assign to this group at creation")


class GroupUpdateRequest(BaseModel):
    """Request to update a group."""
    group_name: Optional[str] = None
    parent_group_id: Optional[int] = None
    description: Optional[str] = None
    is_active: Optional[bool] = None
    is_default: Optional[bool] = None
    scope_ids: Optional[List[int]] = Field(None, description="Scope IDs to assign (replaces all existing scope assignments if provided)")
    role_ids: Optional[List[int]] = Field(None, description="Role IDs to assign (replaces all existing role assignments if provided)")


# Role Models
class RoleRecord(BaseModel):
    """Role record from database."""
    id: int
    tenant_id: int
    role_name: str
    description: Optional[str] = None
    is_active: bool = True
    created_at: datetime
    updated_at: datetime
    created_by: Optional[int] = None
    updated_by: Optional[int] = None


class RoleCreateRequest(BaseModel):
    """Request to create a role."""
    role_name: str = Field(..., description="Role display name")
    description: Optional[str] = Field(None, description="Role description")


class RoleUpdateRequest(BaseModel):
    """Request to update a role."""
    role_name: Optional[str] = None
    description: Optional[str] = None
    is_active: Optional[bool] = None


# Assignment Models
class UserGroupAssignRequest(BaseModel):
    """Request to assign user to group."""
    user_id: int = Field(..., description="User ID")
    group_id: int = Field(..., description="Group ID")


class GroupRoleAssignRequest(BaseModel):
    """Request to assign role to group."""
    group_id: int = Field(..., description="Group ID")
    role_id: int = Field(..., description="Role ID")


# ──────────────────────────────────────────────
# RBAC Models
# ──────────────────────────────────────────────

class ActionRecord(BaseModel):
    """Action record (create, read, update, delete, execute)."""
    id: int
    name: str
    description: Optional[str] = None
    created_at: datetime


class ResourceGroupRecord(BaseModel):
    """Resource group record."""
    id: int
    app_id: int
    name: str
    display_name: Optional[str] = None
    description: Optional[str] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)
    is_active: bool = True
    created_at: datetime
    updated_at: datetime
    created_by: Optional[int] = None
    updated_by: Optional[int] = None


class ResourceRecord(BaseModel):
    """Resource record with pattern matching support."""
    id: int
    app_id: int
    resource_group_id: Optional[int] = None
    name: str
    pattern: Optional[str] = None
    is_pattern: bool = False
    display_name: Optional[str] = None
    description: Optional[str] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)
    is_active: bool = True
    created_at: datetime
    updated_at: datetime
    created_by: Optional[int] = None
    updated_by: Optional[int] = None


class ScopeRecord(BaseModel):
    """Scope record — points to a single scope_entities row (any level)."""
    id: int
    uuid: Optional[str] = None
    tenant_id: int
    name: str
    description: Optional[str] = None
    entity_id: int
    entity_uuid: Optional[str] = None
    entity_name: Optional[str] = None
    level_name: Optional[str] = None
    entity_depth: Optional[int] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)
    is_active: bool = True
    created_at: datetime
    updated_at: datetime
    created_by: Optional[int] = None
    updated_by: Optional[int] = None
    created_by_email: Optional[str] = None
    updated_by_email: Optional[str] = None

    @field_validator('uuid', 'entity_uuid', mode='before')
    @classmethod
    def convert_uuid_to_str(cls, v):
        if v is not None and not isinstance(v, str):
            return str(v)
        return v


class ScopeHierarchyRecord(BaseModel):
    """
    Scope with full entity hierarchy (generic N-level).

    `parent_chain` lists ancestors from root to immediate parent, ordered by depth.
    Frontend can build a breadcrumb directly from this list without extra API calls.
    """
    scope_id: int = Field(..., description="Scope ID")
    scope_uuid: str = Field(..., description="Scope UUID")
    scope_name: str = Field(..., description="Scope name")

    entity_id: int = Field(..., description="Bound scope_entities row ID")
    entity_uuid: Optional[str] = Field(None, description="Bound entity UUID")
    entity_name: str = Field(..., description="Bound entity name")
    entity_level: str = Field(..., description="Level name of the entity (e.g. 'system', 'organization', or any app-defined level)")
    entity_depth: int = Field(..., description="Level depth (0 = root)")

    parent_chain: List["EntityNode"] = Field(
        default_factory=list,
        description="Ancestors from root to immediate parent (ordered by depth, root first)"
    )

    is_active: bool = Field(True, description="Whether scope is active")
    created_at: Optional[datetime] = Field(None, description="Creation timestamp")
    updated_at: Optional[datetime] = Field(None, description="Last update timestamp")
    created_by: Optional[int] = Field(None, description="User ID who created scope")
    updated_by: Optional[int] = Field(None, description="User ID who last updated scope")
    created_by_email: Optional[str] = Field(None, description="Email of user who created scope")
    updated_by_email: Optional[str] = Field(None, description="Email of user who last updated scope")

    @field_validator('scope_uuid', 'entity_uuid', mode='before')
    @classmethod
    def convert_uuid_to_str(cls, v):
        if v is not None and not isinstance(v, str):
            return str(v)
        return v

    class Config:
        from_attributes = True


class GroupScopeAssignment(BaseModel):
    """Record of a scope assigned to a user group."""
    id: int
    tenant_id: int
    group_id: int
    scope_id: int
    assigned_at: datetime
    assigned_by: Optional[int] = None


class PolicyRecord(BaseModel):
    """RBAC policy record — pure role capability (no scope dimension)."""
    id: int
    tenant_id: int
    role_id: int
    resource_id: Optional[int] = None
    resource_group_id: Optional[int] = None
    action_id: int
    is_allowed: bool = True
    metadata: Dict[str, Any] = Field(default_factory=dict)
    created_at: datetime
    created_by: Optional[int] = None


class PolicyBulkCreateRequest(BaseModel):
    """Request to bulk-create policies with multiple actions."""
    role_id: int = Field(..., description="Role ID")
    resource_group_id: Optional[int] = Field(None, description="Resource group ID (mutually exclusive with resource_id)")
    resource_id: Optional[int] = Field(None, description="Resource ID (mutually exclusive with resource_group_id)")
    actions: List[str] = Field(..., description="List of action names (e.g. ['create', 'read', 'update'])")
    is_allowed: bool = Field(True, description="Whether to allow or deny these actions")

    @field_validator("resource_group_id", "resource_id", mode="before")
    @classmethod
    def validate_resource_xor(cls, v, info):
        # This validator runs on both fields; we check the constraint at root level instead
        return v

    @model_validator(mode="before")
    @classmethod
    def check_resource_xor(cls, values):
        resource_group_id = values.get("resource_group_id")
        resource_id = values.get("resource_id")
        if not ((resource_id is None) ^ (resource_group_id is None)):
            raise ValueError("Exactly one of resource_id or resource_group_id must be set")
        return values


class ResourceGroupCreateRequest(BaseModel):
    """Request to create a resource group."""
    name: str = Field(..., description="Resource group name")
    display_name: Optional[str] = Field(None, description="Display name")
    description: Optional[str] = Field(None, description="Description")
    metadata: Optional[Dict[str, Any]] = Field(default_factory=dict)


class ResourceGroupUpdateRequest(BaseModel):
    """Request to update a resource group."""
    display_name: Optional[str] = None
    description: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None
    is_active: Optional[bool] = None


class ResourceCreateRequest(BaseModel):
    """Request to create a resource."""
    name: str = Field(..., description="Resource name")
    pattern: Optional[str] = Field(None, description="Regex pattern (e.g., /users/.*)")
    is_pattern: bool = Field(False, description="Whether this is a pattern-based resource")
    resource_group_id: Optional[int] = Field(None, description="Resource group ID")
    display_name: Optional[str] = Field(None, description="Display name")
    description: Optional[str] = Field(None, description="Description")
    metadata: Optional[Dict[str, Any]] = Field(default_factory=dict)


class ResourceUpdateRequest(BaseModel):
    """Request to update a resource."""
    pattern: Optional[str] = None
    display_name: Optional[str] = None
    description: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None
    is_active: Optional[bool] = None


class UserDetailsResponse(BaseModel):
    """Comprehensive user details including groups, roles, and identities."""
    user: UserRecord
    groups: List[GroupRecord]
    roles: List[RoleRecord]
    identities: List[UserIdentityRecord]
    
    class Config:
        from_attributes = True


class GroupScopeAssignRequest(BaseModel):
    """Request to assign a scope to a group."""
    group_id: int = Field(..., description="Group ID")
    scope_id: int = Field(..., description="Scope ID")


class ActionCreateRequest(BaseModel):
    """Request to create an action."""
    name: str = Field(..., description="Action name (e.g., create, read, update, delete, execute)")
    description: Optional[str] = Field(None, description="Action description")


class PolicyCreateRequest(BaseModel):
    """Request to create an RBAC policy — pure role capability, no scope dimension."""
    role_id: int = Field(..., description="Role ID")
    resource_id: Optional[int] = Field(None, description="Resource ID (mutually exclusive with resource_group_id)")
    resource_group_id: Optional[int] = Field(None, description="Resource group ID (mutually exclusive with resource_id)")
    action_id: int = Field(..., description="Action ID")
    is_allowed: bool = Field(True, description="Allow or deny")
    metadata: Optional[Dict[str, Any]] = Field(default_factory=dict)


class PolicyUpdateRequest(BaseModel):
    """Request to update an RBAC policy."""
    role_id: Optional[int] = None
    resource_id: Optional[int] = None
    resource_group_id: Optional[int] = None
    action_id: Optional[int] = None
    is_allowed: Optional[bool] = None
    metadata: Optional[Dict[str, Any]] = None


# ──────────────────────────────────────────────
# RBAC Policy Response Models
# ──────────────────────────────────────────────

class UserPolicyResponse(BaseModel):
    """Response model for user RBAC policies (truth table)."""
    policy_id: int = Field(..., description="Policy ID")
    role: str = Field(..., description="Role name")
    resource_group: Optional[str] = Field(None, description="Resource group name")
    resource_group_display: Optional[str] = Field(None, description="Resource group display name")
    resource: Optional[str] = Field(None, description="Resource name")
    resource_display: str = Field(..., description="Resource display name (resource or group:resource)")
    action: str = Field(..., description="Action name")
    allowed: bool = Field(..., description="Whether action is allowed")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Policy metadata")


class AllPoliciesResponse(BaseModel):
    """Response model for all RBAC policies."""
    policy_id: int = Field(..., description="Policy ID")
    role: str = Field(..., description="Role name")
    resource_group: Optional[str] = Field(None, description="Resource group name")
    resource_group_display: Optional[str] = Field(None, description="Resource group display name")
    resource: Optional[str] = Field(None, description="Resource name")
    resource_display: str = Field(..., description="Resource display name (resource or group:resource)")
    action: str = Field(..., description="Action name")
    allowed: bool = Field(..., description="Whether action is allowed")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Policy metadata")


# ──────────────────────────────────────────────
# Provider Management Request/Response Models
# ──────────────────────────────────────────────

class CreateProviderRequest(BaseModel):
    """Request body for creating an IDP provider for a tenant."""
    provider_name: str = Field(..., description="Provider name (e.g. 'google', 'microsoft')")
    issuer_url: str = Field(..., description="OIDC issuer URL")
    client_id: str = Field(..., description="OAuth client ID")
    client_secret: str = Field(..., description="OAuth client secret")
    redirect_uri: str = Field(..., description="Redirect URI registered with the IDP")


class CreateProviderResponse(BaseModel):
    """Response for provider creation (no app linkage)."""
    success: bool
    tenant_id: int
    provider_id: int
    provider_name: str
    scopes: List[str]
    message: str


class LinkAppProviderRequest(BaseModel):
    """Request to link an existing provider to an app."""
    app_id: int = Field(..., description="App ID")
    provider_id: int = Field(..., description="Provider ID")
    tenant_id: int = Field(..., description="Tenant ID (for validation)")


class LinkAppProviderResponse(BaseModel):
    """Response for app-provider linkage."""
    success: bool
    app_id: int
    provider_id: int
    tenant_id: int
    message: str


class UpdateProviderRequest(BaseModel):
    """Request to update an IDP provider."""
    issuer_url: Optional[str] = Field(None, description="OIDC issuer URL")
    client_id: Optional[str] = Field(None, description="OAuth client ID")
    client_secret: Optional[str] = Field(None, description="OAuth client secret")
    redirect_uri: Optional[str] = Field(None, description="Redirect URI registered with the IDP")


class UpdateProviderResponse(BaseModel):
    """Response for provider update."""
    success: bool
    provider_id: int
    provider_name: str
    message: str


class DeleteProviderResponse(BaseModel):
    """Response for provider deletion."""
    success: bool
    provider_id: int
    provider_name: str
    message: str


class UpdateAppProviderRequest(BaseModel):
    """Request to update app-provider linkage."""
    app_id: Optional[int] = Field(None, description="New app ID")
    provider_id: Optional[int] = Field(None, description="New provider ID")
    is_active: Optional[bool] = Field(None, description="Activation status")


class UpdateAppProviderResponse(BaseModel):
    """Response for app-provider update."""
    success: bool
    app_id: int
    provider_id: int
    tenant_id: int
    message: str


class DeleteAppProviderResponse(BaseModel):
    """Response for app-provider deletion."""
    success: bool
    app_id: int
    provider_id: int
    tenant_id: int
    message: str


# ──────────────────────────────────────────────
# OAuth Authentication Request/Response Schemas
# ──────────────────────────────────────────────

class AuthUrlRequest(BaseModel):
    """Request to get authorization URL."""
    tenant_name: str
    app_name: str
    provider_name: str
    redirect_uri: Optional[str] = None
    state: Optional[str] = None


class AuthTokenRequest(BaseModel):
    """Request to exchange authorization code for tokens."""
    tenant_name: Optional[str] = None
    app_name: Optional[str] = None
    provider_name: Optional[str] = None
    code: str
    state: str  # Required - used to recover saved OAuth state
    redirect_uri: Optional[str] = None
    code_verifier: Optional[str] = None


class AuthRefreshRequest(BaseModel):
    """Request to refresh platform tokens."""
    refresh_token: str


class AuthRevokeRequest(BaseModel):
    """Request to revoke session."""
    session_id: Optional[str] = None
    refresh_token: Optional[str] = None
    access_token: Optional[str] = None


class IdpTokenResponse(BaseModel):
    """Response containing IDP token information."""
    access_token: str
    token_type: str = "Bearer"
    expires_in: Optional[int] = None
    refresh_token: Optional[str] = None
    scope: Optional[str] = None


# ──────────────────────────────────────────────
# Platform Admin Request/Response Schemas
# ──────────────────────────────────────────────

class TenantCreateRequest(BaseModel):
    """Request to create a tenant."""
    tenant_name: str = Field(..., description="Unique tenant name")
    display_name: Optional[str] = Field(None, description="Display name for the tenant")
    domain: Optional[str] = Field(None, description="Primary domain e.g. 'acme.com'")
    details: Optional[Dict[str, Any]] = Field(default_factory=dict, description="Extra metadata (JSONB)")
    is_active: bool = Field(True, description="Whether tenant is active")


class TenantUpdateRequest(BaseModel):
    """Request to update a tenant."""
    tenant_name: Optional[str] = Field(None, description="Unique tenant name")
    display_name: Optional[str] = Field(None, description="Display name for the tenant")
    domain: Optional[str] = Field(None, description="Primary domain e.g. 'acme.com'")
    details: Optional[Dict[str, Any]] = Field(None, description="Extra metadata (JSONB)")
    is_active: Optional[bool] = Field(None, description="Whether tenant is active")


class ProviderCreateRequest(BaseModel):
    """Request to create a provider."""
    provider_name: str = Field(..., description="Provider name (e.g., 'google', 'azure')")
    issuer_url: str = Field(..., description="OIDC issuer URL")
    idp_config: Dict[str, Any] = Field(..., description="IDP configuration (client_id, client_secret, etc.)")
    config: Optional[Dict[str, Any]] = Field(default_factory=dict, description="Additional provider config")


class ProviderUpdateRequest(BaseModel):
    """Request to update a provider."""
    provider_name: Optional[str] = None
    issuer_url: Optional[str] = None
    idp_config: Optional[Dict[str, Any]] = None
    config: Optional[Dict[str, Any]] = None
    is_active: Optional[bool] = None
    updated_by: Optional[int] = None


class AppCreateRequest(BaseModel):
    """Request to create an app."""
    app_name: str = Field(..., description="App name")
    display_name: Optional[str] = Field(None, description="Display name for the app")
    is_active: bool = Field(True, description="Whether app is active")


class AppUpdateRequest(BaseModel):
    """Request to update an app."""
    app_name: Optional[str] = None
    display_name: Optional[str] = None
    is_active: Optional[bool] = None


class AppProviderCreateRequest(BaseModel):
    """Request to create an app-provider mapping."""
    app_id: int = Field(..., description="App ID")
    provider_id: int = Field(..., description="Provider ID")


class AppProviderUpdateRequest(BaseModel):
    """Request to update an app-provider mapping."""
    app_id: Optional[int] = Field(None, description="App ID")
    provider_id: Optional[int] = Field(None, description="Provider ID")
    is_active: Optional[bool] = Field(None, description="Whether mapping is active")


class TenantKeyCreateRequest(BaseModel):
    """Request to create a tenant signing key."""
    key_type: str = Field("RSA", description="Key type (RSA)")
    is_active: bool = Field(True, description="Whether key is active")


class TenantPropertyCreateRequest(BaseModel):
    """Request to create a tenant property."""
    property_key: str = Field(..., description="Property key")
    property_value: str = Field(..., description="Property value")
    description: Optional[str] = Field(None, description="Property description")


class TenantPropertyUpdateRequest(BaseModel):
    """Request to update a tenant property."""
    property_value: str = Field(..., description="New property value")
    description: Optional[str] = Field(None, description="Updated description")


# ──────────────────────────────────────────────
# BUSINESS ENTITY HIERARCHY MODELS
# ──────────────────────────────────────────────



class SwitchScopeRequest(BaseModel):
    """Request to switch active scope for a user session."""
    scope_uuid: Optional[str] = Field(None, description="Target scope UUID to activate. None to switch back to global.")


class SwitchScopeResponse(BaseModel):
    """Response after scope switch with new JWT and scope details."""
    jwt_token: str = Field(..., description="New JWT token with scoped permissions")
    active_scope_id: Optional[int] = Field(None, description="Active scope ID (None if global)")
    active_scope_uuid: Optional[str] = Field(None, description="Active scope UUID")
    active_scope_name: Optional[str] = Field(None, description="Human-readable scope name")
    entity_level: Optional[str] = Field(None, description="Entity level of the active scope (e.g. organization, team, project)")
    roles: List[str] = Field(default_factory=list, description="Roles applicable in this scope")
    perms: Optional[str] = Field(None, description="Base64-encoded scoped permissions")


# ──────────────────────────────────────────────
# GENERIC SCOPE ENTITY MODELS (N-level architecture)
# ──────────────────────────────────────────────

class ScopeEntityLevelRecord(BaseModel):
    """Configured level definition (system, organization, project, or any app-defined level)."""
    id: int
    tenant_id: int
    name: str  # level name: "system", "organization", "project", "company", "team", etc.
    depth: int  # 0 = root, 1 = child, 2 = grandchild, etc.
    description: Optional[str] = None
    is_active: bool = True


class ScopeEntityRecord(BaseModel):
    """Generic scope entity: any node in the hierarchy tree."""
    id: int
    uuid: Optional[str]
    tenant_id: int
    level_id: int
    level_name: str  # joined from scope_entity_levels
    parent_id: Optional[int] = None
    name: str
    description: Optional[str] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)
    is_active: bool = True
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    created_by: Optional[int] = None
    updated_by: Optional[int] = None
    created_by_email: Optional[str] = None
    updated_by_email: Optional[str] = None


class ScopeEntityCreate(BaseModel):
    """Request to create a new scope entity."""
    name: str = Field(..., description="Entity name")
    level_name: str = Field(..., description="Level name (must exist in scope_entity_levels)")
    parent_uuid: Optional[str] = Field(None, description="Parent entity UUID (None = root)")
    description: Optional[str] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)


class ScopeEntityUpdate(BaseModel):
    """Request to update a scope entity."""
    name: Optional[str] = None
    description: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None


class EntityNode(BaseModel):
    """Recursive tree node for rendering scope hierarchy."""
    id: int
    uuid: Optional[str]
    name: str
    level: str  # level name
    children: List["EntityNode"] = Field(default_factory=list)

    @field_validator('uuid', mode='before')
    @classmethod
    def convert_uuid_to_str(cls, v):
        if v is not None and not isinstance(v, str):
            return str(v)
        return v


EntityNode.model_rebuild()
ScopeHierarchyRecord.model_rebuild()
GroupDetailRecord.model_rebuild()


class BreadcrumbNode(BaseModel):
    """Ancestor node in a scope's parent chain — breadcrumb only, no children."""
    id: int
    uuid: Optional[str] = None
    name: str
    level: str

    @field_validator('uuid', mode='before')
    @classmethod
    def convert_uuid_to_str(cls, v):
        if v is not None and not isinstance(v, str):
            return str(v)
        return v


class ScopeContext(BaseModel):
    """
    Generic scope context response with complete hierarchy (N-level).

    Replaces the old hardcoded system/org/project fields with generic parent_chain and entity_level.
    Works for any number of hierarchy levels configured in the application.

    Fields:
      entity_level     — level name of the active scope's entity
      entity_depth     — depth of that level (0 = root)
      parent_chain     — ancestors from root to immediate parent, ordered by depth (breadcrumb, no children)
      children         — immediate children with their children nested recursively
    """
    scope_id: int
    scope_uuid: Optional[str]
    scope_name: str

    entity_id: int
    entity_uuid: Optional[str]
    entity_name: str
    entity_level: str  # level name: "system", "organization", "project", or any app-defined
    entity_depth: int  # 0 = root level

    parent_chain: List[BreadcrumbNode] = Field(
        default_factory=list,
        description="Ancestors from root to immediate parent (ordered by depth, root first)"
    )
    children: List[EntityNode] = Field(
        default_factory=list,
        description="Immediate children with their children nested (recursive tree structure)"
    )
