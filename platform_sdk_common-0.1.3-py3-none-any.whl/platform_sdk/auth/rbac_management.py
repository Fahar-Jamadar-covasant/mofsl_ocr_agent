"""
RBAC Management Classes

Separated by domain:
- ResourceManagement: Resources and resource groups
- ScopeManagement: Scopes (linked to business entities) and group-scope assignments
- GroupScopeManagement: Assign/remove scopes to/from groups
- PolicyManagement: RBAC policies (pure role capabilities) and actions
"""

import logging
import json
from typing import List, Optional, Dict, Any
from .database import AuthDatabase
from . import rbac_policy_cache
from .interfaces import (
    ResourceRecord, ResourceGroupRecord, ScopeRecord,
    PolicyRecord, GroupScopeAssignment, ActionRecord
)

logger = logging.getLogger(__name__)


def _parse_scope_metadata(row_dict: Dict[str, Any]) -> Dict[str, Any]:
    if isinstance(row_dict.get('metadata'), str):
        try:
            row_dict['metadata'] = json.loads(row_dict['metadata'])
        except (json.JSONDecodeError, TypeError):
            row_dict['metadata'] = {}
    if row_dict.get('uuid'):
        row_dict['uuid'] = str(row_dict['uuid'])
    return row_dict


def _parse_policy_metadata(row_dict: Dict[str, Any]) -> Dict[str, Any]:
    raw = row_dict.get('metadata')
    if raw is None:
        row_dict['metadata'] = {}
    elif isinstance(raw, str):
        raw = raw.strip()
        if raw == '' or raw.lower() == 'null':
            row_dict['metadata'] = {}
        else:
            try:
                row_dict['metadata'] = json.loads(raw)
            except (json.JSONDecodeError, TypeError):
                row_dict['metadata'] = {}
    elif not isinstance(raw, dict):
        row_dict['metadata'] = {}
    return row_dict


def _parse_resource_metadata(row_dict: Dict[str, Any]) -> Dict[str, Any]:
    if isinstance(row_dict.get('metadata'), str):
        try:
            row_dict['metadata'] = json.loads(row_dict['metadata'])
        except (json.JSONDecodeError, TypeError):
            row_dict['metadata'] = {}
    return row_dict


def _parse_resource_group_metadata(row_dict: Dict[str, Any]) -> Dict[str, Any]:
    if isinstance(row_dict.get('metadata'), str):
        try:
            row_dict['metadata'] = json.loads(row_dict['metadata'])
        except (json.JSONDecodeError, TypeError):
            row_dict['metadata'] = {}
    return row_dict


class RBACManagementError(Exception):
    """Base exception for RBAC operations."""
    pass


# ═══════════════════════════════════════════════════════════════════
# RESOURCE MANAGEMENT
# ═══════════════════════════════════════════════════════════════════

class ResourceManagement:
    """Manage resources and resource groups."""

    def __init__(self, db: AuthDatabase):
        self._db = db

    async def create_resource_group(
        self, app_id: int, name: str,
        display_name: Optional[str] = None,
        description: Optional[str] = None,
        metadata: Optional[Dict] = None,
        created_by: Optional[int] = None
    ) -> ResourceGroupRecord:
        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow("""
                INSERT INTO resource_groups
                (app_id, name, display_name, description, metadata, created_by, updated_by)
                VALUES ($1, $2, $3, $4, $5, $6, $6)
                RETURNING *
            """, app_id, name, display_name, description, json.dumps(metadata or {}), created_by)
            logger.info(f"Created resource_group {row['id']}: {name} for app {app_id}")
            return ResourceGroupRecord(**_parse_resource_group_metadata(dict(row)))

    async def get_resource_group(self, app_id: int, group_id: int) -> Optional[ResourceGroupRecord]:
        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow("""
                SELECT * FROM resource_groups WHERE id = $1 AND app_id = $2
            """, group_id, app_id)
            return ResourceGroupRecord(**_parse_resource_group_metadata(dict(row))) if row else None

    async def list_resource_groups(self, app_id: int, is_active: Optional[bool] = True) -> List[ResourceGroupRecord]:
        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            query = "SELECT * FROM resource_groups WHERE app_id = $1"
            params = [app_id]
            if is_active is not None:
                query += " AND is_active = $2"
                params.append(is_active)
            query += " ORDER BY name"
            rows = await conn.fetch(query, *params)
            return [ResourceGroupRecord(**_parse_resource_group_metadata(dict(r))) for r in rows]

    async def update_resource_group(
        self, app_id: int, group_id: int,
        display_name: Optional[str] = None,
        description: Optional[str] = None,
        metadata: Optional[Dict] = None,
        is_active: Optional[bool] = None,
        updated_by: Optional[int] = None
    ) -> ResourceGroupRecord:
        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            updates = []
            params = []
            param_idx = 1

            if display_name is not None:
                updates.append(f"display_name = ${param_idx}")
                params.append(display_name)
                param_idx += 1
            if description is not None:
                updates.append(f"description = ${param_idx}")
                params.append(description)
                param_idx += 1
            if metadata is not None:
                updates.append(f"metadata = ${param_idx}")
                params.append(json.dumps(metadata))
                param_idx += 1
            if is_active is not None:
                updates.append(f"is_active = ${param_idx}")
                params.append(is_active)
                param_idx += 1
            if updated_by is not None:
                updates.append(f"updated_by = ${param_idx}")
                params.append(updated_by)
                param_idx += 1

            updates.append("updated_at = NOW()")

            if not updates:
                raise RBACManagementError("No fields to update")

            params.extend([group_id, app_id])
            row = await conn.fetchrow(f"""
                UPDATE resource_groups
                SET {', '.join(updates)}
                WHERE id = ${param_idx} AND app_id = ${param_idx + 1}
                RETURNING *
            """, *params)

            if not row:
                raise RBACManagementError(f"Resource group {group_id} not found")

            logger.info(f"Updated resource_group {group_id}")
            return ResourceGroupRecord(**_parse_resource_group_metadata(dict(row)))

    async def delete_resource_group(self, app_id: int, group_id: int, updated_by: Optional[int] = None) -> None:
        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            if updated_by is not None:
                await conn.execute(
                    "UPDATE resource_groups SET is_active = FALSE, updated_by = $1, updated_at = NOW() WHERE id = $2 AND app_id = $3",
                    updated_by, group_id, app_id,
                )
            else:
                await conn.execute(
                    "UPDATE resource_groups SET is_active = FALSE, updated_at = NOW() WHERE id = $1 AND app_id = $2",
                    group_id, app_id,
                )
            logger.info(f"Deleted resource_group {group_id}")

    async def create_resource(
        self, app_id: int, name: str,
        pattern: Optional[str] = None,
        is_pattern: bool = False,
        resource_group_id: Optional[int] = None,
        display_name: Optional[str] = None,
        description: Optional[str] = None,
        metadata: Optional[Dict] = None,
        created_by: Optional[int] = None
    ) -> ResourceRecord:
        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow("""
                INSERT INTO resources
                (app_id, resource_group_id, name, pattern, is_pattern,
                 display_name, description, metadata, created_by, updated_by)
                VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $9)
                RETURNING *
            """, app_id, resource_group_id, name, pattern, is_pattern,
                display_name, description, json.dumps(metadata or {}), created_by)
            logger.info(f"Created resource {row['id']}: {name} (pattern={is_pattern})")
            return ResourceRecord(**_parse_resource_metadata(dict(row)))

    async def get_resource(self, app_id: int, resource_id: int) -> Optional[ResourceRecord]:
        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow("SELECT * FROM resources WHERE id = $1 AND app_id = $2", resource_id, app_id)
            return ResourceRecord(**_parse_resource_metadata(dict(row))) if row else None

    async def list_resources(
        self, app_id: int,
        resource_group_id: Optional[int] = None,
        is_pattern: Optional[bool] = None,
        is_active: Optional[bool] = True
    ) -> List[ResourceRecord]:
        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            query = "SELECT * FROM resources WHERE app_id = $1"
            params = [app_id]

            if is_active is not None:
                query += f" AND is_active = ${len(params) + 1}"
                params.append(is_active)
            if resource_group_id is not None:
                query += f" AND resource_group_id = ${len(params) + 1}"
                params.append(resource_group_id)
            if is_pattern is not None:
                query += f" AND is_pattern = ${len(params) + 1}"
                params.append(is_pattern)

            query += " ORDER BY is_pattern ASC, name"
            rows = await conn.fetch(query, *params)
            return [ResourceRecord(**_parse_resource_metadata(dict(r))) for r in rows]

    async def update_resource(
        self, app_id: int, resource_id: int,
        pattern: Optional[str] = None,
        display_name: Optional[str] = None,
        description: Optional[str] = None,
        metadata: Optional[Dict] = None,
        is_active: Optional[bool] = None,
        updated_by: Optional[int] = None
    ) -> ResourceRecord:
        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            updates = []
            params = []
            param_idx = 1

            if pattern is not None:
                updates.append(f"pattern = ${param_idx}")
                params.append(pattern)
                param_idx += 1
            if display_name is not None:
                updates.append(f"display_name = ${param_idx}")
                params.append(display_name)
                param_idx += 1
            if description is not None:
                updates.append(f"description = ${param_idx}")
                params.append(description)
                param_idx += 1
            if metadata is not None:
                updates.append(f"metadata = ${param_idx}")
                params.append(json.dumps(metadata))
                param_idx += 1
            if is_active is not None:
                updates.append(f"is_active = ${param_idx}")
                params.append(is_active)
                param_idx += 1
            if updated_by is not None:
                updates.append(f"updated_by = ${param_idx}")
                params.append(updated_by)
                param_idx += 1

            updates.append("updated_at = NOW()")

            if not updates:
                raise RBACManagementError("No fields to update")

            params.extend([resource_id, app_id])
            row = await conn.fetchrow(f"""
                UPDATE resources
                SET {', '.join(updates)}
                WHERE id = ${param_idx} AND app_id = ${param_idx + 1}
                RETURNING *
            """, *params)

            if not row:
                raise RBACManagementError(f"Resource {resource_id} not found")

            logger.info(f"Updated resource {resource_id}")
            return ResourceRecord(**_parse_resource_metadata(dict(row)))

    async def delete_resource(self, app_id: int, resource_id: int, updated_by: Optional[int] = None) -> None:
        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            if updated_by is not None:
                await conn.execute(
                    "UPDATE resources SET is_active = FALSE, updated_by = $1, updated_at = NOW() WHERE id = $2 AND app_id = $3",
                    updated_by, resource_id, app_id,
                )
            else:
                await conn.execute(
                    "UPDATE resources SET is_active = FALSE, updated_at = NOW() WHERE id = $1 AND app_id = $2",
                    resource_id, app_id,
                )
            logger.info(f"Deleted resource {resource_id}")


# ═══════════════════════════════════════════════════════════════════
# SCOPE MANAGEMENT
# ═══════════════════════════════════════════════════════════════════

class ScopeManagement:
    """Manage scopes linked to business entities (system / organization / project)."""

    def __init__(self, db: AuthDatabase):
        self._db = db

    async def create_scope(
        self,
        tenant_id: int,
        name: str,
        entity_id: int,
        description: Optional[str] = None,
        metadata: Optional[Dict] = None,
        created_by: Optional[int] = None,
    ) -> ScopeRecord:
        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            insert_row = await conn.fetchrow("""
                INSERT INTO scopes
                (tenant_id, name, entity_id, description, metadata, is_active, created_by, updated_by)
                VALUES ($1, $2, $3, $4, $5, TRUE, $6, $6)
                RETURNING id
            """, tenant_id, name, entity_id, description, json.dumps(metadata or {}), created_by)
            if not insert_row:
                raise RBACManagementError(f"Failed to create scope {name}")

            scope_id = insert_row['id']
            row = await conn.fetchrow("""
                SELECT s.*, se.uuid as entity_uuid, se.name as entity_name,
                       sel.name as level_name, sel.depth as entity_depth
                FROM scopes s
                JOIN scope_entities se ON se.id = s.entity_id
                JOIN scope_entity_levels sel ON sel.id = se.level_id
                WHERE s.id = $1
            """, scope_id)
            logger.info(f"Created scope {scope_id}: {name} for tenant {tenant_id}")
            return ScopeRecord(**_parse_scope_metadata(dict(row)))

    async def get_scope(self, scope_id: int) -> Optional[ScopeRecord]:
        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow("""
                SELECT s.*, se.uuid as entity_uuid, se.name as entity_name,
                       sel.name as level_name, sel.depth as entity_depth
                FROM scopes s
                JOIN scope_entities se ON se.id = s.entity_id
                JOIN scope_entity_levels sel ON sel.id = se.level_id
                WHERE s.id = $1
            """, scope_id)
            return ScopeRecord(**_parse_scope_metadata(dict(row))) if row else None

    async def get_scope_by_name(self, tenant_id: int, name: str) -> Optional[ScopeRecord]:
        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow("""
                SELECT s.*, se.uuid as entity_uuid, se.name as entity_name,
                       sel.name as level_name, sel.depth as entity_depth
                FROM scopes s
                JOIN scope_entities se ON se.id = s.entity_id
                JOIN scope_entity_levels sel ON sel.id = se.level_id
                WHERE s.tenant_id = $1 AND s.name = $2
            """, tenant_id, name)
            return ScopeRecord(**_parse_scope_metadata(dict(row))) if row else None

    async def get_scope_by_entity_id(self, entity_id: int) -> Optional[ScopeRecord]:
        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow("""
                SELECT s.*, se.uuid as entity_uuid, se.name as entity_name,
                       sel.name as level_name, sel.depth as entity_depth
                FROM scopes s
                JOIN scope_entities se ON se.id = s.entity_id
                JOIN scope_entity_levels sel ON sel.id = se.level_id
                WHERE s.entity_id = $1 AND s.is_active = TRUE
                ORDER BY s.created_at ASC
                LIMIT 1
            """, entity_id)
            return ScopeRecord(**_parse_scope_metadata(dict(row))) if row else None

    async def list_scopes(
        self,
        tenant_id: int,
        level_name: Optional[str] = None,
        is_active: Optional[bool] = True
    ) -> List[ScopeRecord]:
        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            query = """
                SELECT s.*, se.uuid as entity_uuid, se.name as entity_name,
                       sel.name as level_name, sel.depth as entity_depth
                FROM scopes s
                JOIN scope_entities se ON se.id = s.entity_id
                JOIN scope_entity_levels sel ON sel.id = se.level_id
                WHERE s.tenant_id = $1
            """
            params: List[Any] = [tenant_id]

            if level_name is not None:
                query += f" AND sel.name = ${len(params) + 1}"
                params.append(level_name)
            if is_active is not None:
                query += f" AND s.is_active = ${len(params) + 1}"
                params.append(is_active)

            query += " ORDER BY sel.depth, se.name"
            rows = await conn.fetch(query, *params)
            return [ScopeRecord(**_parse_scope_metadata(dict(r))) for r in rows]

    async def update_scope(
        self,
        scope_id: int,
        name: Optional[str] = None,
        description: Optional[str] = None,
        metadata: Optional[Dict] = None,
        is_active: Optional[bool] = None,
        updated_by: Optional[int] = None
    ) -> ScopeRecord:
        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            updates = []
            params: List[Any] = []
            param_idx = 1

            if name is not None:
                updates.append(f"name = ${param_idx}")
                params.append(name)
                param_idx += 1
            if description is not None:
                updates.append(f"description = ${param_idx}")
                params.append(description)
                param_idx += 1
            if metadata is not None:
                updates.append(f"metadata = ${param_idx}")
                params.append(json.dumps(metadata))
                param_idx += 1
            if is_active is not None:
                updates.append(f"is_active = ${param_idx}")
                params.append(is_active)
                param_idx += 1
            if updated_by is not None:
                updates.append(f"updated_by = ${param_idx}")
                params.append(updated_by)
                param_idx += 1

            updates.append("updated_at = NOW()")

            if not updates:
                raise RBACManagementError("No fields to update")

            params.append(scope_id)
            await conn.execute(f"""
                UPDATE scopes
                SET {', '.join(updates)}
                WHERE id = ${param_idx}
            """, *params)

            row = await conn.fetchrow("""
                SELECT s.*, se.uuid as entity_uuid, se.name as entity_name,
                       sel.name as level_name, sel.depth as entity_depth
                FROM scopes s
                JOIN scope_entities se ON se.id = s.entity_id
                JOIN scope_entity_levels sel ON sel.id = se.level_id
                WHERE s.id = $1
            """, scope_id)

            if not row:
                raise RBACManagementError(f"Scope {scope_id} not found")

            logger.info(f"Updated scope {scope_id}")
            return ScopeRecord(**_parse_scope_metadata(dict(row)))

    async def delete_scope(self, scope_id: int) -> bool:
        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            result = await conn.execute("DELETE FROM scopes WHERE id = $1", scope_id)
            deleted = result.split()[-1] == "1"
            if deleted:
                logger.info(f"Deleted scope {scope_id}")
            return deleted


class GroupScopeManagement:
    """Assign scopes to user groups and manage those assignments."""

    def __init__(self, db: AuthDatabase):
        self._db = db

    async def assign_scope_to_group(
        self,
        tenant_id: int,
        group_id: int,
        scope_id: int,
        assigned_by: Optional[int] = None,
    ) -> GroupScopeAssignment:
        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow("""
                INSERT INTO group_scopes (tenant_id, group_id, scope_id, assigned_by)
                VALUES ($1, $2, $3, $4)
                ON CONFLICT (group_id, scope_id) DO NOTHING
                RETURNING *
            """, tenant_id, group_id, scope_id, assigned_by)
            if not row:
                row = await conn.fetchrow(
                    "SELECT * FROM group_scopes WHERE group_id = $1 AND scope_id = $2",
                    group_id, scope_id
                )
            logger.info(f"Assigned scope {scope_id} to group {group_id}")
            return GroupScopeAssignment(**dict(row))

    async def list_group_scopes(self, group_id: int) -> List[GroupScopeAssignment]:
        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            rows = await conn.fetch(
                "SELECT * FROM group_scopes WHERE group_id = $1 ORDER BY assigned_at DESC",
                group_id
            )
            return [GroupScopeAssignment(**dict(r)) for r in rows]

    async def list_scope_groups(self, scope_id: int) -> List[GroupScopeAssignment]:
        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            rows = await conn.fetch(
                "SELECT * FROM group_scopes WHERE scope_id = $1 ORDER BY assigned_at DESC",
                scope_id
            )
            return [GroupScopeAssignment(**dict(r)) for r in rows]

    async def remove_scope_from_group(self, group_id: int, scope_id: int) -> bool:
        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            result = await conn.execute(
                "DELETE FROM group_scopes WHERE group_id = $1 AND scope_id = $2",
                group_id, scope_id
            )
            deleted = result.split()[-1] == "1"
            if deleted:
                logger.info(f"Removed scope {scope_id} from group {group_id}")
            return deleted


# ═══════════════════════════════════════════════════════════════════
# POLICY MANAGEMENT
# ═══════════════════════════════════════════════════════════════════

class PolicyManagement:
    """Manage RBAC policies (pure role capabilities) and actions."""

    def __init__(self, db: AuthDatabase):
        self._db = db

    async def get_action_by_name(self, name: str) -> Optional[ActionRecord]:
        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow("SELECT * FROM actions WHERE name = $1", name)
            return ActionRecord(**dict(row)) if row else None

    async def get_action(self, action_id: int) -> Optional[ActionRecord]:
        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow("SELECT * FROM actions WHERE id = $1", action_id)
            return ActionRecord(**dict(row)) if row else None

    async def list_actions(self) -> List[ActionRecord]:
        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            rows = await conn.fetch("SELECT * FROM actions ORDER BY name")
            return [ActionRecord(**dict(r)) for r in rows]

    async def create_action(self, name: str, description: Optional[str] = None) -> ActionRecord:
        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow("""
                INSERT INTO actions (name, description)
                VALUES ($1, $2)
                RETURNING *
            """, name, description)
            logger.info(f"Created action {row['id']}: {name}")
            return ActionRecord(**dict(row))

    async def create_policy(
        self,
        tenant_id: int,
        role_id: int,
        action_id: int,
        resource_id: Optional[int] = None,
        resource_group_id: Optional[int] = None,
        is_allowed: bool = True,
        metadata: Optional[Dict] = None,
        created_by: Optional[int] = None,
    ) -> PolicyRecord:
        """
        Create a policy: role + (resource OR resource_group) + action → allow/deny.
        No scope dimension — policies define universal role capabilities.
        """
        if not ((resource_id is None) ^ (resource_group_id is None)):
            raise RBACManagementError("Exactly one of resource_id or resource_group_id must be set")

        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow("""
                INSERT INTO rbac_policies
                (tenant_id, role_id, resource_id, resource_group_id,
                 action_id, is_allowed, metadata, created_by)
                VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
                RETURNING *
            """, tenant_id, role_id, resource_id, resource_group_id,
                action_id, is_allowed, json.dumps(metadata or {}), created_by)
            logger.info(
                f"Created policy {row['id']}: role={role_id} "
                f"resource={resource_id or f'group:{resource_group_id}'} "
                f"action={action_id} allow={is_allowed}"
            )
            rbac_policy_cache.clear_tenant_rbac_cache(tenant_id=tenant_id)
            return PolicyRecord(**_parse_policy_metadata(dict(row)))

    async def get_policy(self, policy_id: int) -> Optional[PolicyRecord]:
        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow("SELECT * FROM rbac_policies WHERE id = $1", policy_id)
            return PolicyRecord(**_parse_policy_metadata(dict(row))) if row else None

    async def list_policies(
        self,
        tenant_id: int,
        role_id: Optional[int] = None,
        resource_id: Optional[int] = None,
        resource_group_id: Optional[int] = None,
        action_id: Optional[int] = None,
    ) -> List[PolicyRecord]:
        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            query = "SELECT * FROM rbac_policies WHERE tenant_id = $1"
            params: List[Any] = [tenant_id]

            if role_id is not None:
                query += f" AND role_id = ${len(params) + 1}"
                params.append(role_id)
            if resource_id is not None:
                query += f" AND resource_id = ${len(params) + 1}"
                params.append(resource_id)
            if resource_group_id is not None:
                query += f" AND resource_group_id = ${len(params) + 1}"
                params.append(resource_group_id)
            if action_id is not None:
                query += f" AND action_id = ${len(params) + 1}"
                params.append(action_id)

            query += " ORDER BY created_at DESC"
            rows = await conn.fetch(query, *params)
            return [PolicyRecord(**_parse_policy_metadata(dict(r))) for r in rows]

    async def update_policy(
        self,
        policy_id: int,
        role_id: Optional[int] = None,
        resource_id: Optional[int] = None,
        resource_group_id: Optional[int] = None,
        action_id: Optional[int] = None,
        is_allowed: Optional[bool] = None,
        metadata: Optional[Dict] = None,
    ) -> PolicyRecord:
        if resource_id is not None and resource_group_id is not None:
            raise RBACManagementError("Exactly one of resource_id or resource_group_id must be set")

        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            updates: List[str] = []
            params: List[Any] = []
            param_idx = 1

            if role_id is not None:
                updates.append(f"role_id = ${param_idx}")
                params.append(role_id)
                param_idx += 1
            if action_id is not None:
                updates.append(f"action_id = ${param_idx}")
                params.append(action_id)
                param_idx += 1
            if is_allowed is not None:
                updates.append(f"is_allowed = ${param_idx}")
                params.append(is_allowed)
                param_idx += 1
            if metadata is not None:
                updates.append(f"metadata = ${param_idx}")
                params.append(json.dumps(metadata))
                param_idx += 1
            if resource_id is not None:
                updates.append(f"resource_id = ${param_idx}")
                params.append(resource_id)
                param_idx += 1
                updates.append(f"resource_group_id = ${param_idx}")
                params.append(None)
                param_idx += 1
            elif resource_group_id is not None:
                updates.append(f"resource_id = ${param_idx}")
                params.append(None)
                param_idx += 1
                updates.append(f"resource_group_id = ${param_idx}")
                params.append(resource_group_id)
                param_idx += 1

            if not updates:
                raise RBACManagementError("No fields to update")

            params.append(policy_id)
            row = await conn.fetchrow(
                f"UPDATE rbac_policies SET {', '.join(updates)} WHERE id = ${param_idx} RETURNING *",
                *params,
            )

            if not row:
                raise RBACManagementError(f"Policy {policy_id} not found")

            logger.info(f"Updated policy {policy_id}")
            rbac_policy_cache.clear_tenant_rbac_cache(tenant_id=row['tenant_id'])
            return PolicyRecord(**_parse_policy_metadata(dict(row)))

    async def delete_policy(self, policy_id: int) -> None:
        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow("SELECT tenant_id FROM rbac_policies WHERE id = $1", policy_id)
            if row:
                await conn.execute("DELETE FROM rbac_policies WHERE id = $1", policy_id)
                logger.info(f"Deleted policy {policy_id}")
                rbac_policy_cache.clear_tenant_rbac_cache(tenant_id=row['tenant_id'])
            else:
                logger.warning(f"Policy {policy_id} not found for deletion")

    async def get_resources_by_group(self, resource_group_id: int) -> List[Dict[str, Any]]:
        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            resources = await conn.fetch("""
                SELECT id, name, pattern, is_pattern, display_name, description, metadata
                FROM resources
                WHERE resource_group_id = $1
                ORDER BY name
            """, resource_group_id)
            return [_parse_resource_metadata(dict(r)) for r in resources]

    async def get_user_rbac_policies(self, user_id: int, tenant_id: int) -> List[Dict[str, Any]]:
        """Get all RBAC policies that apply to the user's roles (truth table)."""
        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            user_roles = await conn.fetch("""
                SELECT DISTINCT r.id, r.name as role_name
                FROM roles r
                JOIN group_roles gr ON gr.role_id = r.id
                JOIN user_groups ug ON ug.group_id = gr.group_id
                WHERE ug.user_id = $1 AND ug.tenant_id = $2
                  AND r.is_active = TRUE
            """, user_id, tenant_id)

            if not user_roles:
                return []

            role_ids = [r['id'] for r in user_roles]

            policies = await conn.fetch("""
                SELECT
                    p.id,
                    p.role_id,
                    p.resource_id,
                    p.resource_group_id,
                    p.action_id,
                    p.is_allowed,
                    p.metadata,
                    r.name as resource_name,
                    r.pattern as resource_pattern,
                    r.is_pattern,
                    rg.name as resource_group_name,
                    rg.display_name as resource_group_display,
                    a.name as action_name,
                    rl.name as role_name
                FROM rbac_policies p
                LEFT JOIN resources r ON r.id = p.resource_id
                LEFT JOIN resource_groups rg ON rg.id = p.resource_group_id
                JOIN actions a ON a.id = p.action_id
                JOIN roles rl ON rl.id = p.role_id
                WHERE p.tenant_id = $1
                  AND p.role_id = ANY($2::int[])
                ORDER BY rl.name, resource_group_name, resource_name, action_name
            """, tenant_id, role_ids)

            result = []
            for policy in policies:
                policy_dict = _parse_policy_metadata(dict(policy))
                if policy['resource_id']:
                    resource_display = policy['resource_name']
                elif policy['resource_group_id']:
                    resource_display = f"group:{policy['resource_group_name']}"
                else:
                    resource_display = "unknown"

                result.append({
                    "policy_id": policy['id'],
                    "role": policy['role_name'],
                    "resource_group": policy['resource_group_name'],
                    "resource_group_display": policy['resource_group_display'],
                    "resource": policy['resource_name'],
                    "resource_display": resource_display,
                    "action": policy['action_name'],
                    "allowed": policy['is_allowed'],
                    "metadata": policy_dict['metadata']
                })

            return result

    async def get_all_rbac_policies(self, tenant_id: int) -> List[Dict[str, Any]]:
        """Get all RBAC policies for all roles in a tenant."""
        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            policies = await conn.fetch("""
                SELECT
                    p.id,
                    p.role_id,
                    p.resource_id,
                    p.resource_group_id,
                    p.action_id,
                    p.is_allowed,
                    p.metadata,
                    r.name as resource_name,
                    r.pattern as resource_pattern,
                    r.is_pattern,
                    rg.name as resource_group_name,
                    rg.display_name as resource_group_display,
                    a.name as action_name,
                    rl.name as role_name
                FROM rbac_policies p
                LEFT JOIN resources r ON r.id = p.resource_id
                LEFT JOIN resource_groups rg ON rg.id = p.resource_group_id
                JOIN actions a ON a.id = p.action_id
                JOIN roles rl ON rl.id = p.role_id
                WHERE p.tenant_id = $1
                ORDER BY rl.name, resource_group_name, resource_name, action_name
            """, tenant_id)

            result = []
            for policy in policies:
                policy_dict = _parse_policy_metadata(dict(policy))
                if policy['resource_id']:
                    resource_display = policy['resource_name']
                elif policy['resource_group_id']:
                    resource_display = f"group:{policy['resource_group_name']}"
                else:
                    resource_display = "unknown"

                result.append({
                    "policy_id": policy['id'],
                    "role": policy['role_name'],
                    "resource_group": policy['resource_group_name'],
                    "resource_group_display": policy['resource_group_display'],
                    "resource": policy['resource_name'],
                    "resource_display": resource_display,
                    "action": policy['action_name'],
                    "allowed": policy['is_allowed'],
                    "metadata": policy_dict['metadata']
                })

            return result
