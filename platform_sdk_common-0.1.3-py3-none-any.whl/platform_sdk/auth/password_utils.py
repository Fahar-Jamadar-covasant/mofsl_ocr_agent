"""
Password hashing and verification utilities.
Uses PBKDF2-HMAC-SHA256 for secure password hashing.
"""

import base64
import hashlib
import hmac
import os


def hash_password(password: str) -> str:
    """
    Hash a password using PBKDF2-HMAC-SHA256.
    
    Args:
        password: Plain text password
        
    Returns:
        Hashed password string
    """
    if password is None:
        raise ValueError("Password cannot be None")

    salt = os.urandom(16)
    iterations = 200_000
    dk = hashlib.pbkdf2_hmac(
        "sha256",
        password.encode("utf-8"),
        salt,
        iterations,
        dklen=32,
    )

    salt_b64 = base64.b64encode(salt).decode("utf-8")
    dk_b64 = base64.b64encode(dk).decode("utf-8")
    return f"pbkdf2_sha256${iterations}${salt_b64}${dk_b64}"


def verify_password(password: str, password_hash: str) -> bool:
    """
    Verify a password against its hash.
    
    Args:
        password: Plain text password to verify
        password_hash: Stored password hash
        
    Returns:
        True if password matches, False otherwise
    """
    try:
        if not password_hash:
            return False

        # Format: pbkdf2_sha256$<iterations>$<salt_b64>$<dk_b64>
        parts = password_hash.split("$")
        if len(parts) != 4:
            return False
        algo, iterations_s, salt_b64, dk_b64 = parts
        if algo != "pbkdf2_sha256":
            return False

        iterations = int(iterations_s)
        salt = base64.b64decode(salt_b64.encode("utf-8"))
        expected = base64.b64decode(dk_b64.encode("utf-8"))
        computed = hashlib.pbkdf2_hmac(
            "sha256",
            password.encode("utf-8"),
            salt,
            iterations,
            dklen=len(expected),
        )
        return hmac.compare_digest(computed, expected)
    except Exception:
        return False


def generate_secure_password(length: int = 16) -> str:
    """
    Generate a cryptographically secure random password.
    
    Args:
        length: Password length (default: 16)
        
    Returns:
        Secure random password
    """
    import secrets
    import string
    
    alphabet = string.ascii_letters + string.digits + "!@#$%^&*"
    password = ''.join(secrets.choice(alphabet) for _ in range(length))
    return password
