"""
Authorization Engine

Delegates RBAC evaluation to centralized helpers in rbac_utilities.py.
"""

import json
import base64
import logging
from typing import List, Optional, Tuple, Dict, Any
from .database import AuthDatabase
from . import rbac_utilities

logger = logging.getLogger(__name__)


class AuthorizationEngine:
    """
    Core authorization logic backed by centralized helpers.
    """

    def __init__(self, db: AuthDatabase):
        self._db = db

    async def can_user_perform(
        self,
        user_id: int,
        tenant_id: int,
        app_id: int,
        resource_path: str,
        action_name: str,
        role_ids: Optional[List[int]] = None
    ) -> Tuple[bool, Optional[str], Optional[Dict]]:
        """
        Check if user can perform action on resource.

        Args:
            user_id: User ID
            tenant_id: Tenant ID
            app_id: App ID
            resource_path: Resource path (e.g., "/tenants/1/apps/5/settings")
            action_name: Action name (create, read, update, delete, execute)
            role_ids: Optional set of role IDs to use. If provided, skips DB lookup (for scoped JWT).

        Returns:
            (allowed: bool, reason: str, matched_policy: Optional[Dict])
        """
        try:
            allowed, reason, matched_policy = await rbac_utilities.rbac_policy_evaluate_user_access(
                db=self._db,
                user_id=user_id,
                tenant_id=tenant_id,
                resource_name=resource_path,
                action=action_name,
                role_ids=set(role_ids) if role_ids else None,
            )
            if allowed:
                logger.debug(f"Authorization allowed for user {user_id}, resource {resource_path}, action {action_name}")
            return allowed, reason, matched_policy
        except Exception as e:
            logger.error(f"RBAC evaluation failed for user {user_id}, resource {resource_path}, action {action_name}: {e}")
            return False, f"RBAC evaluation failed: {str(e)}", None

    async def get_user_permissions(
        self, user_id: int, tenant_id: int, app_id: int
    ) -> List[Dict[str, Any]]:
        """
        Get all permissions for a user (union across all their roles).

        Returns list of {resource, action, is_allowed}.
        """
        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            user_roles = await conn.fetch("""
                SELECT DISTINCT r.id
                FROM roles r
                JOIN group_roles gr ON gr.role_id = r.id
                JOIN user_groups ug ON ug.group_id = gr.group_id
                WHERE ug.user_id = $1 AND ug.tenant_id = $2
                  AND r.is_active = TRUE
            """, user_id, tenant_id)

            if not user_roles:
                return []

            role_ids = [r['id'] for r in user_roles]

            policies = await conn.fetch("""
                SELECT
                    p.id,
                    p.resource_id,
                    p.resource_group_id,
                    p.action_id,
                    p.is_allowed,
                    r.name as resource_name,
                    r.pattern as resource_pattern,
                    r.is_pattern,
                    rg.name as resource_group_name,
                    a.name as action_name
                FROM rbac_policies p
                LEFT JOIN resources r ON r.id = p.resource_id
                LEFT JOIN resource_groups rg ON rg.id = p.resource_group_id
                JOIN actions a ON a.id = p.action_id
                WHERE p.role_id = ANY($1::int[])
                  AND p.tenant_id = $2
            """, role_ids, tenant_id)

            permissions = []
            for policy in policies:
                resource_display = (
                    policy['resource_name'] or
                    f"group:{policy['resource_group_name']}"
                )
                permissions.append({
                    "resource": resource_display,
                    "action": policy['action_name'],
                    "is_allowed": policy['is_allowed'],
                    "policy_id": policy['id']
                })

            return permissions

    async def check_permission_simple(
        self, user_id: int, tenant_id: int,
        resource_path: str, action_name: str
    ) -> bool:
        """Simplified permission check (returns only bool)."""
        allowed, _, _ = await self.can_user_perform(
            user_id=user_id,
            tenant_id=tenant_id,
            app_id=0,
            resource_path=resource_path,
            action_name=action_name
        )
        return allowed

    async def get_user_resource_group_permissions(
        self,
        user_id: int,
        tenant_id: int,
        app_id: int,
    ) -> str:
        """
        Get simplified RBAC permissions for JWT — resource groups and allowed actions,
        unified across all the user's roles (no scope dimension).

        Returns:
            Base64 encoded string:
            {"resource_groups": [{"name": "system_config", "actions": ["create", "read"]}]}
        """
        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            policies = await conn.fetch("""
                SELECT DISTINCT
                    rg.name as resource_group_name,
                    a.name as action_name
                FROM rbac_policies p
                JOIN resource_groups rg ON p.resource_group_id = rg.id
                JOIN actions a ON p.action_id = a.id
                WHERE p.tenant_id = $1
                  AND p.is_allowed = TRUE
                  AND p.role_id IN (
                    SELECT DISTINCT gr.role_id
                    FROM group_roles gr
                    WHERE gr.group_id IN (
                        SELECT ug.group_id
                        FROM user_groups ug
                        WHERE ug.user_id = $2 AND ug.tenant_id = $1
                    )
                  )
                ORDER BY rg.name, a.name
            """, tenant_id, user_id)

            resource_groups: Dict[str, Dict] = {}
            for policy in policies:
                rg_name = policy['resource_group_name']
                action = policy['action_name']

                if rg_name not in resource_groups:
                    resource_groups[rg_name] = {"name": rg_name, "actions": []}

                if action not in resource_groups[rg_name]["actions"]:
                    resource_groups[rg_name]["actions"].append(action)

            perms_data = {"resource_groups": list(resource_groups.values())}

            compact_json = json.dumps(perms_data, separators=(',', ':'))
            base64_encoded = base64.urlsafe_b64encode(
                compact_json.encode('utf-8')
            ).decode('utf-8').rstrip('=')

            logger.debug(f"Resolved {len(resource_groups)} resource groups for user {user_id}, encoded size: {len(base64_encoded)} bytes")
            return base64_encoded

    async def get_user_scope_roles_map(
        self,
        user_id: int,
        tenant_id: int,
    ) -> Dict[str, List[str]]:
        """
        Get mapping of scopes to role names for a user.
        Includes scoped roles (groups with scope) and global roles (groups without scope).

        Returns:
            {"project-alpha": ["admin"], "org-X": ["member"], "_global": ["basic-user"]}
        """
        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            # Scoped roles: user's groups that carry scope S → roles from those groups
            scoped_roles = await conn.fetch("""
                SELECT s.name AS scope_name, r.name AS role_name
                FROM user_groups  ug
                JOIN group_scopes gs ON gs.group_id = ug.group_id
                JOIN scopes       s  ON s.id = gs.scope_id AND s.tenant_id = $2 AND s.is_active = TRUE
                JOIN group_roles  gr ON gr.group_id = ug.group_id
                JOIN roles        r  ON r.id = gr.role_id AND r.tenant_id = $2 AND r.is_active = TRUE
                WHERE ug.user_id = $1
            """, user_id, tenant_id)

            # Global roles: user's groups with NO scope assignments
            global_roles = await conn.fetch("""
                SELECT '_global' AS scope_name, r.name AS role_name
                FROM user_groups ug
                JOIN group_roles gr ON gr.group_id = ug.group_id
                JOIN roles       r  ON r.id = gr.role_id AND r.tenant_id = $2 AND r.is_active = TRUE
                WHERE ug.user_id = $1
                  AND NOT EXISTS (SELECT 1 FROM group_scopes gs WHERE gs.group_id = ug.group_id)
            """, user_id, tenant_id)

            # Aggregate into map
            scope_roles_map: Dict[str, List[str]] = {}
            for row in scoped_roles + global_roles:
                scope_name = row['scope_name']
                role_name = row['role_name']
                if scope_name not in scope_roles_map:
                    scope_roles_map[scope_name] = []
                if role_name not in scope_roles_map[scope_name]:
                    scope_roles_map[scope_name].append(role_name)

            logger.debug(f"Resolved scope_roles map for user {user_id}: {len(scope_roles_map)} scopes")
            return scope_roles_map

    async def get_role_ids_by_names(
        self,
        role_names: List[str],
        tenant_id: int,
    ) -> List[int]:
        """
        Resolve role names to role IDs for a tenant.
        Used when converting JWT role claims to role IDs for RBAC evaluation.

        Args:
            role_names: List of role names (e.g., ["admin", "member"])
            tenant_id: Tenant ID

        Returns:
            List of role IDs
        """
        if not role_names:
            return []

        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            roles = await conn.fetch("""
                SELECT DISTINCT id FROM roles
                WHERE name = ANY($1::text[])
                  AND tenant_id = $2
                  AND is_active = TRUE
            """, role_names, tenant_id)
            return [r['id'] for r in roles]

    async def get_user_scoped_resource_group_permissions(
        self,
        user_id: int,
        tenant_id: int,
        app_id: int,
        scope_id: int,
    ) -> str:
        """
        Get RBAC permissions for a user limited to a specific scope.
        Only includes policies for roles that apply in the given scope.

        Returns:
            Base64 encoded string (same format as get_user_resource_group_permissions)
        """
        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            # Get scoped role_ids: groups user belongs to that carry scope_id + global groups
            scoped_role_ids = await conn.fetch("""
                WITH user_group_ids AS (
                    SELECT group_id FROM user_groups WHERE user_id = $1 AND tenant_id = $2
                ),
                scoped_group_ids AS (
                    SELECT group_id FROM group_scopes WHERE scope_id = $3
                ),
                global_group_ids AS (
                    SELECT ugi.group_id FROM user_group_ids ugi
                    WHERE NOT EXISTS (SELECT 1 FROM group_scopes gs WHERE gs.group_id = ugi.group_id)
                )
                SELECT DISTINCT gr.role_id
                FROM group_roles gr
                JOIN roles r ON r.id = gr.role_id AND r.is_active = TRUE AND r.tenant_id = $2
                WHERE gr.group_id IN (
                    SELECT group_id FROM user_group_ids
                    INTERSECT
                    SELECT group_id FROM scoped_group_ids
                )
                UNION
                SELECT DISTINCT gr.role_id
                FROM group_roles gr
                JOIN roles r ON r.id = gr.role_id AND r.is_active = TRUE AND r.tenant_id = $2
                WHERE gr.group_id IN (SELECT group_id FROM global_group_ids)
            """, user_id, tenant_id, scope_id)

            role_ids = {row['role_id'] for row in scoped_role_ids}

            # Get policies for scoped role_ids
            policies = await conn.fetch("""
                SELECT DISTINCT
                    rg.name as resource_group_name,
                    a.name as action_name
                FROM rbac_policies p
                JOIN resource_groups rg ON p.resource_group_id = rg.id
                JOIN actions a ON p.action_id = a.id
                WHERE p.tenant_id = $1
                  AND p.is_allowed = TRUE
                  AND p.role_id = ANY($2::int[])
                ORDER BY rg.name, a.name
            """, tenant_id, list(role_ids))

            # Aggregate into resource groups
            resource_groups: Dict[str, Dict] = {}
            for policy in policies:
                rg_name = policy['resource_group_name']
                action = policy['action_name']

                if rg_name not in resource_groups:
                    resource_groups[rg_name] = {"name": rg_name, "actions": []}

                if action not in resource_groups[rg_name]["actions"]:
                    resource_groups[rg_name]["actions"].append(action)

            perms_data = {"resource_groups": list(resource_groups.values())}

            compact_json = json.dumps(perms_data, separators=(',', ':'))
            base64_encoded = base64.urlsafe_b64encode(
                compact_json.encode('utf-8')
            ).decode('utf-8').rstrip('=')

            logger.debug(f"Resolved {len(resource_groups)} resource groups for user {user_id} in scope {scope_id}, encoded size: {len(base64_encoded)} bytes")
            return base64_encoded

    async def get_user_available_scopes(
        self,
        user_id: int,
        tenant_id: int,
    ) -> List[Dict[str, Any]]:
        """
        Get all scopes available to a user (all scopes the user's groups carry).
        Used in login response for scope picker.

        Returns:
            [{"id": 42, "uuid": "...", "name": "project-alpha", "entity_level": "project"}, ...]
        """
        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            scopes = await conn.fetch("""
                SELECT DISTINCT s.id, s.uuid, s.name, sel.name AS entity_level, sel.depth, s.description, s.metadata
                FROM scopes s
                JOIN scope_entities se ON se.id = s.entity_id
                JOIN scope_entity_levels sel ON sel.id = se.level_id
                JOIN group_scopes gs ON gs.scope_id = s.id
                JOIN user_groups ug ON ug.group_id = gs.group_id
                WHERE ug.user_id = $1
                  AND s.tenant_id = $2
                  AND s.is_active = TRUE
                ORDER BY sel.depth, s.name
            """, user_id, tenant_id)

            result = []
            for scope in scopes:
                result.append({
                    "id": scope['id'],
                    "uuid": str(scope['uuid']) if scope['uuid'] else None,
                    "name": scope['name'],
                    "entity_level": scope['entity_level'],
                    "description": scope['description'],
                    "metadata": scope['metadata'] or {}
                })

            logger.debug(f"Resolved {len(result)} available scopes for user {user_id}")
            return result

    async def resolve_user_rbac_policies(
        self,
        user_id: int,
        tenant_id: int,
        app_id: int,
    ) -> str:
        """
        DEPRECATED: Use get_user_resource_group_permissions() for simplified JWT perms.

        Resolve ALL RBAC policies for logged-in user across all their roles.
        Returns base64 encoded compact JSON of actual database policies.
        """
        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            policies = await conn.fetch("""
                SELECT
                    p.resource_id,
                    p.resource_group_id,
                    p.is_allowed,
                    a.name as action_name,
                    a.description as action_description,
                    r.name as resource_name,
                    r.pattern as resource_pattern,
                    r.is_pattern as resource_is_pattern,
                    r.display_name as resource_display_name,
                    rg.name as resource_group_name,
                    rg.display_name as resource_group_display_name,
                    rol.name as role_name
                FROM rbac_policies p
                JOIN actions a ON p.action_id = a.id
                LEFT JOIN resources r ON p.resource_id = r.id
                LEFT JOIN resource_groups rg ON p.resource_group_id = rg.id
                LEFT JOIN roles rol ON p.role_id = rol.id
                WHERE p.tenant_id = $1
                  AND p.role_id IN (
                    SELECT DISTINCT gr.role_id
                    FROM group_roles gr
                    WHERE gr.group_id IN (
                        SELECT ug.group_id
                        FROM user_groups ug
                        WHERE ug.user_id = $2 AND ug.tenant_id = $1
                    )
                  )
                ORDER BY
                    rol.name,
                    CASE WHEN p.resource_id IS NOT NULL THEN 0 ELSE 1 END,
                    r.name, rg.name, a.name
            """, tenant_id, user_id)

            resource_group_details: Dict[int, List[Dict]] = {}
            for policy in policies:
                if policy['resource_group_id']:
                    rg_id = policy['resource_group_id']
                    if rg_id not in resource_group_details:
                        group_resources = await conn.fetch("""
                            SELECT name, pattern, is_pattern, display_name, metadata
                            FROM resources
                            WHERE resource_group_id = $1 AND is_active = true
                            ORDER BY name
                        """, rg_id)
                        resource_group_details[rg_id] = [dict(r) for r in group_resources]

            compact_policies = self._build_deduplicated_policies(policies, resource_group_details)

            compact_json = json.dumps(compact_policies, separators=(',', ':'))
            base64_encoded = base64.urlsafe_b64encode(
                compact_json.encode('utf-8')
            ).decode('utf-8').rstrip('=')

            logger.debug(f"Resolved {len(policies)} RBAC policies for user {user_id}, encoded size: {len(base64_encoded)} bytes")
            return base64_encoded

    def _build_deduplicated_policies(
        self,
        policies: List,
        resource_group_details: Dict[int, List[Dict]]
    ) -> Dict[str, Any]:
        """Build rbac_policies structure from database rows."""
        role_policies: Dict[str, Dict] = {}

        for policy in policies:
            role_name = policy['role_name']

            if role_name not in role_policies:
                role_policies[role_name] = {
                    "role": role_name,
                    "resources": {},
                    "resource_groups": {}
                }

            if policy['resource_id']:
                resource_name = policy['resource_name']
                action = policy['action_name']
                is_allowed = policy['is_allowed']

                if resource_name not in role_policies[role_name]["resources"]:
                    role_policies[role_name]["resources"][resource_name] = {
                        "n": resource_name,
                        "p": policy['resource_pattern'],
                        "is_pattern": policy['resource_is_pattern'],
                        "actions": {"allow": [], "deny": []}
                    }

                action_list = "allow" if is_allowed else "deny"
                if action not in role_policies[role_name]["resources"][resource_name]["actions"][action_list]:
                    role_policies[role_name]["resources"][resource_name]["actions"][action_list].append(action)

            elif policy['resource_group_id']:
                rg_id = policy['resource_group_id']
                rg_name = policy['resource_group_name']
                action = policy['action_name']
                is_allowed = policy['is_allowed']

                if rg_name not in role_policies[role_name]["resource_groups"]:
                    role_policies[role_name]["resource_groups"][rg_name] = {
                        "n": rg_name,
                        "actions": {"allow": [], "deny": []},
                        "res": [],
                        "_id": rg_id
                    }

                action_list = "allow" if is_allowed else "deny"
                if action not in role_policies[role_name]["resource_groups"][rg_name]["actions"][action_list]:
                    role_policies[role_name]["resource_groups"][rg_name]["actions"][action_list].append(action)

                if not role_policies[role_name]["resource_groups"][rg_name]["res"] and rg_id in resource_group_details:
                    role_policies[role_name]["resource_groups"][rg_name]["res"] = [
                        {
                            "n": res['name'],
                            "is_pattern": res['is_pattern'],
                            **({"p": res['pattern']} if res['is_pattern'] else {})
                        }
                        for res in resource_group_details[rg_id]
                    ]

        rbac_policies = []

        for role_name, role_data in role_policies.items():
            role_entry = {"role": role_name, "resources": [], "resource_groups": []}

            for resource_name, resource_data in role_data["resources"].items():
                all_actions = resource_data["actions"]["allow"] + resource_data["actions"]["deny"]
                if all_actions:
                    resource_entry = {
                        "n": resource_data["n"],
                        "is_pattern": resource_data["is_pattern"],
                        "actions": sorted(all_actions)
                    }
                    if resource_data["is_pattern"]:
                        resource_entry["p"] = resource_data["p"]
                    role_entry["resources"].append(resource_entry)

            for rg_name, rg_data in role_data["resource_groups"].items():
                all_actions = rg_data["actions"]["allow"] + rg_data["actions"]["deny"]
                if all_actions or rg_data["res"]:
                    role_entry["resource_groups"].append({
                        "n": rg_data["n"],
                        "actions": sorted(all_actions),
                        "res": rg_data["res"]
                    })

            rbac_policies.append(role_entry)

        return {"rbac_policies": rbac_policies}
