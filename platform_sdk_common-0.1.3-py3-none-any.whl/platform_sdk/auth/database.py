"""
Postgres storage for providers, tenants, tenant_properties, app_providers, apps, sessions,
oauth_states, tenant_keys, and user management tables.

Tables are auto-created on initialize() if they do not exist.
Uses asyncpg for async Postgres access.
Implements StateStore so it can be passed directly to the router.

Unified schema for both STANDALONE and PLATFORM modes.
ER: Tenant → App → Provider (via app_providers junction)

Schema (v2 – name-based API, SERIAL PKs throughout):
    tenants             – SERIAL PK id. tenant_name UNIQUE. No IDP fields.
    tenant_properties   – SERIAL PK id. Key/value metadata for tenants. UNIQUE(tenant_id, property_key).
    providers           – SERIAL PK id. Tenant-scoped (tenant_id FK). Credentials +
                          endpoints stored in idp_config JSONB. UNIQUE(tenant_id, provider_name).
    apps                – SERIAL PK id. Tenant-scoped. app_name only (no redirect/scope columns).
                          UNIQUE(tenant_id, app_name).
    app_providers       – Pure mapping (app_id INT FK, provider_id INT FK). No credentials.
                          UNIQUE(app_id, provider_id).
    sessions            – PK id (TEXT, UUID). tokens JSONB {idp:{}, platform:{}}. user_attributes JSONB.
                          issued_at replaces logged_in_at.
    oauth_states        – app_id / provider_id are INTEGER FKs.
    tenant_keys         – RSA key pairs per tenant for JWT signing.
    users               – User records with optional password_hash for email/password authentication.
    user_identities     – Links users to external IDP identities.
    u_groups, roles     – User groups and roles for authorization.

All created_by / updated_by columns are INTEGER (user ID) not TEXT.
"""

import json
import logging
import secrets
import time
import uuid
from typing import Any, Dict, List, Optional

import asyncpg
import httpx

from .interfaces import (
    OAuthConfig,
    ProviderConfig,
    TenantConfig,
    AppProviderConfig,
    AppConfig,
    SessionRecord,
    OAuthState,
    OAuthConfigurationError,
)
from .state_store import StateStore

logger = logging.getLogger(__name__)

# ──────────────────────────────────────────────
# DDL – auto-created on initialize()
# ──────────────────────────────────────────────

_CREATE_TENANTS = """
CREATE TABLE IF NOT EXISTS tenants (
    id                 SERIAL PRIMARY KEY,
    uuid               UUID UNIQUE NOT NULL DEFAULT gen_random_uuid(),
    tenant_name        TEXT NOT NULL UNIQUE,
    tenant_description TEXT,
    domain             TEXT,
    is_active          BOOLEAN NOT NULL DEFAULT TRUE,
    details            JSONB,
    created_at         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_by         INTEGER,
    updated_by         INTEGER
);
"""

_CREATE_TENANT_PROPERTIES = """
CREATE TABLE IF NOT EXISTS tenant_properties (
    id             SERIAL PRIMARY KEY,
    tenant_id      INTEGER NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    property_key   TEXT NOT NULL,
    property_value TEXT NOT NULL,
    is_active      BOOLEAN NOT NULL DEFAULT TRUE,
    created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_by     INTEGER,
    updated_by     INTEGER,
    UNIQUE(tenant_id, property_key)
);
"""

_CREATE_TENANT_PROPERTIES_INDEXES = """
CREATE INDEX IF NOT EXISTS idx_tenant_properties_tenant ON tenant_properties(tenant_id);
CREATE INDEX IF NOT EXISTS idx_tenant_properties_key ON tenant_properties(property_key);
"""

_CREATE_PROVIDERS = """
CREATE TABLE IF NOT EXISTS providers (
    id              SERIAL PRIMARY KEY,
    uuid            UUID UNIQUE NOT NULL DEFAULT gen_random_uuid(),
    tenant_id       INTEGER NOT NULL REFERENCES tenants(id),
    provider_name   TEXT NOT NULL,
    issuer_url      TEXT NOT NULL,
    idp_config      JSONB NOT NULL DEFAULT '{}',
    config          JSONB NOT NULL DEFAULT '{}',
    is_active       BOOLEAN NOT NULL DEFAULT TRUE,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_by      INTEGER,
    updated_by      INTEGER,
    UNIQUE(tenant_id, provider_name)
);
"""

_CREATE_APPS = """
CREATE TABLE IF NOT EXISTS apps (
    id          SERIAL PRIMARY KEY,
    uuid        UUID UNIQUE NOT NULL DEFAULT gen_random_uuid(),
    tenant_id   INTEGER NOT NULL REFERENCES tenants(id),
    app_name    TEXT NOT NULL,
    is_active   BOOLEAN NOT NULL DEFAULT TRUE,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_by  INTEGER,
    updated_by  INTEGER,
    UNIQUE(tenant_id, app_name)
);
"""

_CREATE_APP_PROVIDERS = """
CREATE TABLE IF NOT EXISTS app_providers (
    id          SERIAL PRIMARY KEY,
    app_id      INTEGER NOT NULL REFERENCES apps(id),
    tenant_id   INTEGER NOT NULL REFERENCES tenants(id),
    provider_id INTEGER NOT NULL REFERENCES providers(id),
    is_active   BOOLEAN NOT NULL DEFAULT TRUE,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_by  INTEGER,
    updated_by  INTEGER,
    UNIQUE(app_id, provider_id)
);
"""

_CREATE_SESSIONS = """
CREATE TABLE IF NOT EXISTS sessions (
    id              TEXT PRIMARY KEY,
    tenant_id       INTEGER NOT NULL REFERENCES tenants(id),
    app_id          INTEGER NOT NULL REFERENCES apps(id),
    provider_id     INTEGER NOT NULL REFERENCES providers(id),
    user_id         INTEGER NOT NULL REFERENCES users(id),
    active_scope_id INTEGER REFERENCES scopes(id) ON DELETE SET NULL,
    user_attributes JSONB NOT NULL DEFAULT '{}',
    tokens          JSONB NOT NULL DEFAULT '{}',
    audit_log       JSONB DEFAULT '[]'::jsonb,
    issued_at       DOUBLE PRECISION NOT NULL,
    expires_at      DOUBLE PRECISION NOT NULL,
    is_revoked      BOOLEAN NOT NULL DEFAULT FALSE,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_by      INTEGER,
    updated_by      INTEGER
);
"""

_CREATE_SESSION_INDEXES = """
CREATE INDEX IF NOT EXISTS idx_sessions_tenant ON sessions(tenant_id);
CREATE INDEX IF NOT EXISTS idx_sessions_app ON sessions(app_id);
CREATE INDEX IF NOT EXISTS idx_sessions_provider ON sessions(provider_id);
CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_sessions_active_scope ON sessions(active_scope_id) WHERE active_scope_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_sessions_expires ON sessions(expires_at) WHERE is_revoked = FALSE;
CREATE INDEX IF NOT EXISTS idx_sessions_platform_refresh_token
    ON sessions ((tokens->'platform'->>'refresh_token'))
    WHERE tokens->'platform'->>'refresh_token' IS NOT NULL
      AND is_revoked = FALSE;
"""

_CREATE_OAUTH_STATES = """
CREATE TABLE IF NOT EXISTS oauth_states (
    state                  TEXT PRIMARY KEY,
    tenant_id              INTEGER NOT NULL,
    app_id                 INTEGER,
    provider_id            INTEGER,
    redirect_uri           TEXT NOT NULL,
    code_verifier          TEXT,
    created_at             DOUBLE PRECISION NOT NULL,
    expires_at             DOUBLE PRECISION NOT NULL,
    created_by             INTEGER,
    frontend_callback_url  TEXT
);
"""

_CREATE_TENANT_KEYS = """
CREATE TABLE IF NOT EXISTS tenant_keys (
    key_id          SERIAL PRIMARY KEY,
    tenant_id       INTEGER NOT NULL REFERENCES tenants(id),
    public_key_pem  TEXT NOT NULL,
    private_key_pem TEXT NOT NULL,
    algorithm       TEXT NOT NULL DEFAULT 'RS256',
    is_active       BOOLEAN NOT NULL DEFAULT TRUE,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_by      INTEGER,
    updated_by      INTEGER
);
"""

# ──────────────────────────────────────────────
# USER MANAGEMENT TABLES
# ──────────────────────────────────────────────

_CREATE_USERS = """
CREATE TABLE IF NOT EXISTS users (
    id                  SERIAL PRIMARY KEY,
    uuid                UUID UNIQUE NOT NULL DEFAULT gen_random_uuid(),
    tenant_id           INTEGER NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    email               TEXT NOT NULL,
    password_hash       TEXT,
    first_name          TEXT,
    last_name           TEXT,
    display_name        TEXT,
    is_active           BOOLEAN NOT NULL DEFAULT TRUE,
    last_login_at       TIMESTAMPTZ,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_by          INTEGER,
    updated_by          INTEGER,
    
    UNIQUE(tenant_id, email)
);
"""

_CREATE_USER_INDEXES = """
CREATE INDEX IF NOT EXISTS idx_users_tenant ON users(tenant_id);
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_users_active ON users(is_active) WHERE is_active = TRUE;
CREATE INDEX IF NOT EXISTS idx_users_last_name ON users(last_name);
"""

_CREATE_USER_IDENTITIES = """
CREATE TABLE IF NOT EXISTS user_identities (
    id                  SERIAL PRIMARY KEY,
    tenant_id           INTEGER NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    user_id             INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    provider_id         INTEGER NOT NULL REFERENCES providers(id) ON DELETE CASCADE,
    external_user_id    TEXT NOT NULL,
    idp_attributes      JSONB NOT NULL DEFAULT '{}',
    last_synced_at      TIMESTAMPTZ,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    
    UNIQUE(tenant_id, provider_id, external_user_id)
);
"""

_CREATE_USER_IDENTITY_INDEXES = """
CREATE INDEX IF NOT EXISTS idx_user_identities_tenant ON user_identities(tenant_id);
CREATE INDEX IF NOT EXISTS idx_user_identities_user ON user_identities(user_id);
CREATE INDEX IF NOT EXISTS idx_user_identities_provider ON user_identities(provider_id);
CREATE INDEX IF NOT EXISTS idx_user_identities_external_id ON user_identities(external_user_id);
"""

_CREATE_U_GROUPS = """
CREATE TABLE IF NOT EXISTS u_groups (
    id                  SERIAL PRIMARY KEY,
    tenant_id           INTEGER NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    name               TEXT NOT NULL,
    parent_group_id     INTEGER REFERENCES u_groups(id) ON DELETE SET NULL,
    description         TEXT,
    is_active           BOOLEAN NOT NULL DEFAULT TRUE,
    is_default          BOOLEAN NOT NULL DEFAULT FALSE,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_by          INTEGER,
    updated_by          INTEGER,
    
    UNIQUE(tenant_id, name)
);
"""

_CREATE_U_GROUPS_INDEXES = """
CREATE INDEX IF NOT EXISTS idx_u_groups_tenant ON u_groups(tenant_id);
CREATE INDEX IF NOT EXISTS idx_u_groups_name ON u_groups(name);
CREATE INDEX IF NOT EXISTS idx_u_groups_parent ON u_groups(parent_group_id);
CREATE INDEX IF NOT EXISTS idx_u_groups_active ON u_groups(is_active) WHERE is_active = TRUE;
CREATE INDEX IF NOT EXISTS idx_u_groups_default ON u_groups(tenant_id, is_default) 
    WHERE is_default = TRUE AND is_active = TRUE;
CREATE UNIQUE INDEX IF NOT EXISTS uq_u_groups_default_per_tenant ON u_groups(tenant_id)
    WHERE is_default = TRUE AND is_active = TRUE;
"""

_CREATE_USER_GROUPS = """
CREATE TABLE IF NOT EXISTS user_groups (
    id                  SERIAL PRIMARY KEY,
    tenant_id           INTEGER NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    user_id             INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    group_id            INTEGER NOT NULL REFERENCES u_groups(id) ON DELETE CASCADE,
    assigned_at         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    assigned_by         INTEGER,
    
    UNIQUE(user_id, group_id)
);
"""

_CREATE_USER_GROUPS_INDEXES = """
CREATE INDEX IF NOT EXISTS idx_user_groups_tenant ON user_groups(tenant_id);
CREATE INDEX IF NOT EXISTS idx_user_groups_user ON user_groups(user_id);
CREATE INDEX IF NOT EXISTS idx_user_groups_group ON user_groups(group_id);
"""

_CREATE_ROLES = """
CREATE TABLE IF NOT EXISTS roles (
    id                  SERIAL PRIMARY KEY,
    tenant_id           INTEGER NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    name               TEXT NOT NULL,
    description         TEXT,
    is_active           BOOLEAN NOT NULL DEFAULT TRUE,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_by          INTEGER,
    updated_by          INTEGER,
    
    UNIQUE(tenant_id, name)
);
"""

_CREATE_ROLES_INDEXES = """
CREATE INDEX IF NOT EXISTS idx_roles_tenant ON roles(tenant_id);
CREATE INDEX IF NOT EXISTS idx_roles_name ON roles(name);
CREATE INDEX IF NOT EXISTS idx_roles_active ON roles(is_active) WHERE is_active = TRUE;
"""

_CREATE_GROUP_ROLES = """
CREATE TABLE IF NOT EXISTS group_roles (
    id                  SERIAL PRIMARY KEY,
    group_id            INTEGER NOT NULL REFERENCES u_groups(id) ON DELETE CASCADE,
    role_id             INTEGER NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
    assigned_at         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    assigned_by         INTEGER,
    
    UNIQUE(group_id, role_id)
);
"""

_CREATE_GROUP_ROLES_INDEXES = """
CREATE INDEX IF NOT EXISTS idx_group_roles_group ON group_roles(group_id);
CREATE INDEX IF NOT EXISTS idx_group_roles_role ON group_roles(role_id);
"""

# ──────────────────────────────────────────────
# SCOPE-BASED RBAC TABLES
# ──────────────────────────────────────────────

_CREATE_ACTIONS = """
CREATE TABLE IF NOT EXISTS actions (
    id              SERIAL PRIMARY KEY,
    name            TEXT NOT NULL UNIQUE,
    description     TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
"""

_CREATE_ACTIONS_INDEXES = """
CREATE INDEX IF NOT EXISTS idx_actions_name ON actions(name);
"""

_CREATE_RESOURCE_GROUPS = """
CREATE TABLE IF NOT EXISTS resource_groups (
    id              SERIAL PRIMARY KEY,
    app_id          INTEGER NOT NULL REFERENCES apps(id) ON DELETE CASCADE,
    name            TEXT NOT NULL,
    display_name    TEXT,
    description     TEXT,
    metadata        JSONB DEFAULT '{}',
    is_active       BOOLEAN NOT NULL DEFAULT TRUE,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_by      INTEGER,
    updated_by      INTEGER,
    UNIQUE(app_id, name)
);
"""

_CREATE_RESOURCE_GROUPS_INDEXES = """
CREATE INDEX IF NOT EXISTS idx_rg_app ON resource_groups(app_id);
"""

_CREATE_RESOURCES = """
CREATE TABLE IF NOT EXISTS resources (
    id                  SERIAL PRIMARY KEY,
    app_id              INTEGER NOT NULL REFERENCES apps(id) ON DELETE CASCADE,
    resource_group_id   INTEGER REFERENCES resource_groups(id) ON DELETE SET NULL,
    name                TEXT NOT NULL,
    pattern             TEXT,
    is_pattern          BOOLEAN NOT NULL DEFAULT FALSE,
    display_name        TEXT,
    description         TEXT,
    metadata            JSONB DEFAULT '{}',
    is_active           BOOLEAN NOT NULL DEFAULT TRUE,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_by          INTEGER,
    updated_by          INTEGER,
    UNIQUE(app_id, name)
);
"""

_CREATE_RESOURCES_INDEXES = """
CREATE INDEX IF NOT EXISTS idx_resources_app ON resources(app_id);
CREATE INDEX IF NOT EXISTS idx_resources_group ON resources(resource_group_id);
CREATE INDEX IF NOT EXISTS idx_resources_pattern ON resources(app_id, is_pattern) WHERE is_pattern = TRUE;
"""

_CREATE_SCOPES = """
CREATE TABLE IF NOT EXISTS scopes (
    id              SERIAL PRIMARY KEY,
    uuid            UUID UNIQUE NOT NULL DEFAULT gen_random_uuid(),
    tenant_id       INTEGER NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    name            TEXT NOT NULL,
    description     TEXT,
    entity_id       INTEGER NOT NULL REFERENCES scope_entities(id) ON DELETE CASCADE,
    metadata        JSONB DEFAULT '{}',
    is_active       BOOLEAN NOT NULL DEFAULT TRUE,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_by      INTEGER,
    updated_by      INTEGER,
    UNIQUE(tenant_id, name)
);
"""

_CREATE_SCOPES_INDEXES = """
CREATE INDEX IF NOT EXISTS idx_scopes_tenant ON scopes(tenant_id) WHERE is_active = TRUE;
CREATE INDEX IF NOT EXISTS idx_scopes_name ON scopes(tenant_id, name);
CREATE INDEX IF NOT EXISTS idx_scopes_entity ON scopes(entity_id);
CREATE INDEX IF NOT EXISTS idx_scopes_uuid ON scopes(uuid);
"""

_CREATE_GROUP_SCOPES = """
CREATE TABLE IF NOT EXISTS group_scopes (
    id          SERIAL PRIMARY KEY,
    tenant_id   INTEGER NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    group_id    INTEGER NOT NULL REFERENCES u_groups(id) ON DELETE CASCADE,
    scope_id    INTEGER NOT NULL REFERENCES scopes(id) ON DELETE CASCADE,
    assigned_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    assigned_by INTEGER,
    UNIQUE(group_id, scope_id)
);
"""

_CREATE_GROUP_SCOPES_INDEXES = """
CREATE INDEX IF NOT EXISTS idx_group_scopes_group ON group_scopes(group_id);
CREATE INDEX IF NOT EXISTS idx_group_scopes_scope ON group_scopes(scope_id);
CREATE INDEX IF NOT EXISTS idx_group_scopes_tenant ON group_scopes(tenant_id);
"""

# ──────────────────────────────────────────────
# BUSINESS ENTITY HIERARCHY TABLES (GENERIC)
# ──────────────────────────────────────────────

_CREATE_SCOPE_ENTITY_LEVELS = """
CREATE TABLE IF NOT EXISTS scope_entity_levels (
    id          SERIAL PRIMARY KEY,
    tenant_id   INTEGER NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    name        TEXT NOT NULL,
    depth       INTEGER NOT NULL,
    description TEXT,
    is_active   BOOLEAN NOT NULL DEFAULT TRUE,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(tenant_id, depth),
    UNIQUE(tenant_id, name)
);
"""

_CREATE_SCOPE_ENTITY_LEVELS_INDEXES = """
CREATE INDEX IF NOT EXISTS idx_scope_entity_levels_tenant ON scope_entity_levels(tenant_id);
CREATE INDEX IF NOT EXISTS idx_scope_entity_levels_depth ON scope_entity_levels(tenant_id, depth);
"""

_CREATE_SCOPE_ENTITIES = """
CREATE TABLE IF NOT EXISTS scope_entities (
    id          SERIAL PRIMARY KEY,
    uuid        UUID UNIQUE NOT NULL DEFAULT gen_random_uuid(),
    tenant_id   INTEGER NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    level_id    INTEGER NOT NULL REFERENCES scope_entity_levels(id) ON DELETE CASCADE,
    parent_id   INTEGER REFERENCES scope_entities(id) ON DELETE CASCADE,
    name        TEXT NOT NULL,
    description TEXT,
    metadata    JSONB DEFAULT '{}',
    is_active   BOOLEAN NOT NULL DEFAULT TRUE,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_by  INTEGER,
    updated_by  INTEGER
);
"""

_CREATE_SCOPE_ENTITIES_INDEXES = """
CREATE INDEX IF NOT EXISTS idx_scope_entities_tenant ON scope_entities(tenant_id) WHERE is_active = TRUE;
CREATE INDEX IF NOT EXISTS idx_scope_entities_parent ON scope_entities(parent_id);
CREATE INDEX IF NOT EXISTS idx_scope_entities_level ON scope_entities(level_id);
CREATE INDEX IF NOT EXISTS idx_scope_entities_uuid ON scope_entities(uuid);
CREATE UNIQUE INDEX IF NOT EXISTS ux_scope_entities_parent_name ON scope_entities(COALESCE(parent_id, -1), name);
"""


_CREATE_RBAC_POLICIES = """
CREATE TABLE IF NOT EXISTS rbac_policies (
    id                  SERIAL PRIMARY KEY,
    tenant_id           INTEGER NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    role_id             INTEGER NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
    resource_id         INTEGER REFERENCES resources(id) ON DELETE CASCADE,
    resource_group_id   INTEGER REFERENCES resource_groups(id) ON DELETE CASCADE,
    action_id           INTEGER NOT NULL REFERENCES actions(id) ON DELETE CASCADE,
    is_allowed          BOOLEAN NOT NULL DEFAULT TRUE,
    metadata            JSONB DEFAULT '{}',
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_by          INTEGER,

    CONSTRAINT chk_resource_or_group CHECK (
        (resource_id IS NOT NULL AND resource_group_id IS NULL) OR
        (resource_id IS NULL AND resource_group_id IS NOT NULL)
    )
);
"""

_CREATE_RBAC_POLICIES_INDEXES = """
CREATE INDEX IF NOT EXISTS idx_rbac_role ON rbac_policies(role_id);
CREATE INDEX IF NOT EXISTS idx_rbac_resource ON rbac_policies(resource_id);
CREATE INDEX IF NOT EXISTS idx_rbac_resource_group ON rbac_policies(resource_group_id);
CREATE INDEX IF NOT EXISTS idx_rbac_action ON rbac_policies(action_id);
CREATE INDEX IF NOT EXISTS idx_rbac_tenant ON rbac_policies(tenant_id);

CREATE UNIQUE INDEX IF NOT EXISTS uq_rbac_policy_resource
    ON rbac_policies(tenant_id, role_id, resource_id, action_id)
    WHERE resource_id IS NOT NULL;

CREATE UNIQUE INDEX IF NOT EXISTS uq_rbac_policy_resource_group
    ON rbac_policies(tenant_id, role_id, resource_group_id, action_id)
    WHERE resource_group_id IS NOT NULL;

CREATE INDEX IF NOT EXISTS idx_rbac_auth_check_resource ON rbac_policies(tenant_id, role_id, resource_id, action_id)
    WHERE resource_id IS NOT NULL;

CREATE INDEX IF NOT EXISTS idx_rbac_auth_check_group ON rbac_policies(tenant_id, role_id, resource_group_id, action_id)
    WHERE resource_group_id IS NOT NULL;
"""



class AuthDatabase(StateStore):
    """
    Postgres-backed storage for the platform auth module.
    Also implements StateStore so it can be passed directly to the router.

    Usage:
        db = AuthDatabase("postgresql://user:pass@localhost:5432/mydb")
        await db.initialize()   # auto-creates tables
        ...
        await db.close()
    """

    def __init__(self, database_url: str, config: Optional['OAuthConfig'] = None) -> None:
        self._dsn = database_url
        self._pool: Optional[asyncpg.Pool] = None
        self._config = config

    async def initialize(self) -> None:
        """Create connection pool and ensure all tables exist."""
        self._pool = await asyncpg.create_pool(dsn=self._dsn, min_size=2, max_size=10)
        async with self._pool.acquire() as conn:
            # Core auth tables
            await conn.execute(_CREATE_TENANTS)          # no deps
            await conn.execute(_CREATE_TENANT_PROPERTIES)  # needs tenants
            await conn.execute(_CREATE_TENANT_PROPERTIES_INDEXES)
            await conn.execute(_CREATE_PROVIDERS)         # needs tenants
            await conn.execute(_CREATE_APPS)              # needs tenants
            await conn.execute(_CREATE_APP_PROVIDERS)     # needs apps + providers
            # await conn.execute(_CREATE_SESSIONS)          # needs apps + providers + tenants
            # await conn.execute(_CREATE_SESSION_INDEXES)
            await conn.execute(_CREATE_OAUTH_STATES)      # integer FKs (soft)
            await conn.execute(_CREATE_TENANT_KEYS)       # needs tenants
            
            # User management tables
            await conn.execute(_CREATE_USERS)             # needs tenants
            await conn.execute(_CREATE_USER_INDEXES)
            await conn.execute(_CREATE_USER_IDENTITIES)   # needs users + providers
            await conn.execute(_CREATE_USER_IDENTITY_INDEXES)
            await conn.execute(_CREATE_U_GROUPS)          # needs tenants
            await conn.execute(_CREATE_U_GROUPS_INDEXES)
            await conn.execute(_CREATE_USER_GROUPS)       # needs users + groups
            await conn.execute(_CREATE_USER_GROUPS_INDEXES)
            await conn.execute(_CREATE_ROLES)             # needs tenants
            await conn.execute(_CREATE_ROLES_INDEXES)
            await conn.execute(_CREATE_GROUP_ROLES)       # needs groups + roles
            await conn.execute(_CREATE_GROUP_ROLES_INDEXES)
            
            # Business entity hierarchy tables (GENERIC)
            await conn.execute(_CREATE_SCOPE_ENTITY_LEVELS)
            await conn.execute(_CREATE_SCOPE_ENTITY_LEVELS_INDEXES)
            await conn.execute(_CREATE_SCOPE_ENTITIES)
            await conn.execute(_CREATE_SCOPE_ENTITIES_INDEXES)

            # RBAC tables
            await conn.execute(_CREATE_ACTIONS)              # no deps
            await conn.execute(_CREATE_ACTIONS_INDEXES)
            await conn.execute(_CREATE_RESOURCE_GROUPS)      # needs apps
            await conn.execute(_CREATE_RESOURCE_GROUPS_INDEXES)
            await conn.execute(_CREATE_RESOURCES)             # needs apps + resource_groups
            await conn.execute(_CREATE_RESOURCES_INDEXES)
            await conn.execute(_CREATE_SCOPES)                # needs tenants + scope_entity_levels + scope_entities
            await conn.execute(_CREATE_SCOPES_INDEXES)
            await conn.execute(_CREATE_GROUP_SCOPES)          # needs tenants + u_groups + scopes
            await conn.execute(_CREATE_GROUP_SCOPES_INDEXES)
            await conn.execute(_CREATE_RBAC_POLICIES)        # needs tenants + roles + resources + actions
            await conn.execute(_CREATE_RBAC_POLICIES_INDEXES)

            await conn.execute(_CREATE_SESSIONS)          # needs apps + providers + tenants
            await conn.execute(_CREATE_SESSION_INDEXES)
        
        logger.info("AuthDatabase initialised – all tables ensured")
    
    async def seed_standalone_defaults(
        self,
        tenant_name: str,
        tenant_description: str,
        app_name: str,
        app_description: str,
        admin_email: str,
        admin_password_hash: str,
        admin_first_name: str,
        admin_last_name: str,
        admin_display_name: str,
        roles: Optional[List[Dict[str, Any]]] = None,
        groups: Optional[List[Dict[str, Any]]] = None,
        role_group_mappings: Optional[Dict[str, str]] = None,
        tenant_domain: Optional[str] = None,
        tenant_details: Optional[Dict[str, Any]] = None,
        rbac_config: Optional[Dict[str, Any]] = None,
        providers: Optional[List[Dict[str, Any]]] = None,
        entity_hierarchy: Optional[Dict[str, Any]] = None,
        group_scope_mappings: Optional[Dict[str, List[str]]] = None,
    ) -> dict:
        """
        Seed default data for standalone mode.

        Delegates to seed_defaults.seed_standalone_defaults() for the actual implementation.

        entity_hierarchy seeds the N-level generic entity hierarchy:
          {
            "levels": [{"name": "...", "depth": 0, "description": "..."}, ...],
            "entities": [{"name": "...", "level": "...", "parent": "...", "description": "..."}, ...]
          }

        Returns:
            dict with tenant_id, app_id, user_id, created counts
        """
        from .seed_defaults import seed_standalone_defaults as _seed

        pool = self._need_pool()
        return await _seed(
            pool=pool,
            tenant_name=tenant_name,
            tenant_description=tenant_description,
            app_name=app_name,
            app_description=app_description,
            admin_email=admin_email,
            admin_password_hash=admin_password_hash,
            admin_first_name=admin_first_name,
            admin_last_name=admin_last_name,
            admin_display_name=admin_display_name,
            roles=roles,
            groups=groups,
            role_group_mappings=role_group_mappings,
            tenant_domain=tenant_domain,
            tenant_details=tenant_details,
            rbac_config=rbac_config,
            providers=providers,
            entity_hierarchy=entity_hierarchy,
            group_scope_mappings=group_scope_mappings,
        )

    async def close(self) -> None:
        """Close the connection pool."""
        if self._pool:
            await self._pool.close()

    def _need_pool(self) -> asyncpg.Pool:
        if not self._pool:
            raise OAuthConfigurationError("AuthDatabase not initialised. Call initialize() first.")
        return self._pool

    # ──────────────────────────────────────────
    # StateStore implementation
    # ──────────────────────────────────────────

    async def save_state(self, state: OAuthState) -> None:
        pool = self._need_pool()
        async with pool.acquire() as conn:
            await conn.execute(
                """
                INSERT INTO oauth_states
                    (state, tenant_id, app_id, provider_id, redirect_uri,
                     code_verifier, created_at, expires_at, created_by,
                     frontend_callback_url)
                VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)
                ON CONFLICT (state) DO NOTHING
                """,
                state.state,
                state.tenant_id,
                state.app_id,
                state.provider_id,
                state.redirect_uri,
                state.code_verifier,
                state.created_at,
                state.expires_at,
                state.created_by,
                state.frontend_callback_url,
            )

    async def get_state(self, state_value: str) -> Optional[OAuthState]:
        """Retrieve state without deleting."""
        pool = self._need_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                """
                SELECT 
                    os.*,
                    t.tenant_name,
                    a.app_name,
                    p.provider_name
                FROM oauth_states os
                LEFT JOIN tenants t ON t.id = os.tenant_id
                LEFT JOIN apps a ON a.id = os.app_id
                LEFT JOIN providers p ON p.id = os.provider_id
                WHERE os.state = $1 AND os.expires_at > $2
                """,
                state_value,
                time.time(),
            )
            if not row:
                return None
            return OAuthState(
                state=row["state"],
                tenant_id=row["tenant_id"],
                tenant_name=row["tenant_name"],
                app_id=row["app_id"],
                app_name=row["app_name"],
                provider_id=row["provider_id"],
                provider_name=row["provider_name"],
                redirect_uri=row["redirect_uri"],
                code_verifier=row["code_verifier"],
                created_at=row["created_at"],
                expires_at=row["expires_at"],
                created_by=row["created_by"],
                frontend_callback_url=row["frontend_callback_url"],
            )

    async def get_and_delete_state(self, state_value: str) -> Optional[OAuthState]:
        pool = self._need_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                """
                DELETE FROM oauth_states
                WHERE state = $1 AND expires_at > $2
                RETURNING
                    state, tenant_id, app_id, provider_id, redirect_uri,
                    code_verifier, created_at, expires_at, created_by,
                    frontend_callback_url
                """,
                state_value,
                time.time(),
            )
            if not row:
                return None

            # After delete, fetch the names from related tables
            names = await conn.fetchrow(
                """
                SELECT
                    t.tenant_name,
                    a.app_name,
                    p.provider_name
                FROM tenants t
                LEFT JOIN apps a ON a.id = $2
                LEFT JOIN providers p ON p.id = $3
                WHERE t.id = $1
                """,
                row["tenant_id"],
                row["app_id"],
                row["provider_id"],
            )

            return OAuthState(
                state=row["state"],
                tenant_id=row["tenant_id"],
                tenant_name=names["tenant_name"] if names else None,
                app_id=row["app_id"],
                app_name=names["app_name"] if names else None,
                provider_id=row["provider_id"],
                provider_name=names["provider_name"] if names else None,
                redirect_uri=row["redirect_uri"],
                code_verifier=row["code_verifier"],
                created_at=row["created_at"],
                expires_at=row["expires_at"],
                created_by=row["created_by"],
                frontend_callback_url=row["frontend_callback_url"],
            )

    # ──────────────────────────────────────────
    # Provider CRUD + OIDC Discovery
    # ──────────────────────────────────────────

    async def create_provider(self, provider: ProviderConfig) -> ProviderConfig:
        """
        Insert a new provider. Auto-discovers OIDC endpoints from issuer_url.
        Discovered endpoints (authorize_url, token_url, userinfo_url, revoke_url)
        are merged into idp_config alongside the supplied credentials.
        Non-credential discovery metadata (jwks_url, scopes_supported, provider_type)
        is stored in the config JSONB.
        Returns the created ProviderConfig with the auto-generated id.
        """
        idp_cfg = dict(provider.idp_config) if provider.idp_config else {}
        meta_cfg = dict(provider.config) if provider.config else {}

        needs_discovery = not all([idp_cfg.get("authorize_url"), idp_cfg.get("token_url")])
        if needs_discovery:
            logger.info("Running OIDC discovery for %s", provider.issuer_url)
            discovered = await self._discover_endpoints(provider.issuer_url)
            if discovered:
                issuer_lower = provider.issuer_url.lower()
                is_google = "google" in issuer_lower or "googleapis" in issuer_lower
                is_microsoft = "microsoft" in issuer_lower or "microsoftonline" in issuer_lower
                default_scopes = ["openid", "profile", "email"]
                if is_microsoft:
                    default_scopes.append("offline_access")
                idp_cfg.setdefault("authorize_url", discovered.get("authorization_endpoint"))
                idp_cfg.setdefault("token_url", discovered.get("token_endpoint"))
                idp_cfg.setdefault("userinfo_url", discovered.get("userinfo_endpoint"))
                idp_cfg.setdefault("revoke_url", discovered.get("revocation_endpoint"))
                meta_cfg.update({
                    "jwks_url": discovered.get("jwks_uri"),
                    "scopes_supported": discovered.get("scopes_supported", []),
                    "default_scopes": default_scopes,
                    "provider_type": "google" if is_google else "microsoft" if is_microsoft else "generic",
                })
            else:
                logger.warning(
                    "OIDC discovery failed for provider '%s' (issuer: %s).",
                    provider.provider_name, provider.issuer_url,
                )

        pool = self._need_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                """
                INSERT INTO providers
                    (tenant_id, provider_name, issuer_url, idp_config, config,
                     is_active, created_by, updated_by)
                VALUES ($1,$2,$3,$4::jsonb,$5::jsonb,TRUE,$6,$6)
                RETURNING *
                """,
                provider.tenant_id,
                provider.provider_name,
                provider.issuer_url,
                json.dumps(idp_cfg),
                json.dumps(meta_cfg),
                provider.created_by,
            )
        result = self._row_to_provider(row)
        logger.info(
            "Provider '%s' (id=%d) created for tenant %d",
            result.provider_name, result.id, result.tenant_id,
        )
        return result

    async def get_provider(self, provider_id: int) -> Optional[ProviderConfig]:
        """Fetch a provider by integer PK."""
        pool = self._need_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                "SELECT * FROM providers WHERE id = $1 AND is_active = TRUE",
                provider_id,
            )
            if not row:
                return None
            return self._row_to_provider(row)

    async def get_provider_by_name(
        self, tenant_id: int, provider_name: str
    ) -> Optional[ProviderConfig]:
        """Fetch a provider by tenant + name (API lookup)."""
        pool = self._need_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                """
                SELECT * FROM providers
                WHERE tenant_id = $1 AND provider_name = $2 AND is_active = TRUE
                """,
                tenant_id,
                provider_name,
            )
            if not row:
                return None
            return self._row_to_provider(row)

    async def list_providers(self, tenant_id: int) -> List[ProviderConfig]:
        """List all active providers for a tenant."""
        pool = self._need_pool()
        async with pool.acquire() as conn:
            rows = await conn.fetch(
                "SELECT * FROM providers WHERE tenant_id = $1 AND is_active = TRUE ORDER BY provider_name",
                tenant_id,
            )
            return [self._row_to_provider(r) for r in rows]

    async def refresh_provider_discovery(self, provider_id: int) -> Optional[ProviderConfig]:
        """Re-fetch OIDC endpoints for a provider and update idp_config + config."""
        provider = await self.get_provider(provider_id)
        if not provider:
            return None
        discovered = await self._discover_endpoints(provider.issuer_url)
        if not discovered:
            return provider
        new_idp = dict(provider.idp_config)
        new_meta = dict(provider.config)
        new_idp.update({
            "authorize_url": discovered.get("authorization_endpoint") or new_idp.get("authorize_url"),
            "token_url": discovered.get("token_endpoint") or new_idp.get("token_url"),
            "userinfo_url": discovered.get("userinfo_endpoint") or new_idp.get("userinfo_url"),
            "revoke_url": discovered.get("revocation_endpoint") or new_idp.get("revoke_url"),
        })
        new_meta.update({
            "jwks_url": discovered.get("jwks_uri") or new_meta.get("jwks_url"),
            "scopes_supported": discovered.get("scopes_supported") or new_meta.get("scopes_supported", []),
        })
        pool = self._need_pool()
        async with pool.acquire() as conn:
            await conn.execute(
                """
                UPDATE providers SET
                    idp_config = $2::jsonb,
                    config = $3::jsonb,
                    updated_at = NOW()
                WHERE id = $1
                """,
                provider_id,
                json.dumps(new_idp),
                json.dumps(new_meta),
            )
        return await self.get_provider(provider_id)

    async def update_provider(self, provider_id: int, provider: ProviderConfig, updated_by: Optional[int] = None) -> ProviderConfig:
        """Update an existing provider."""
        pool = self._need_pool()
        async with pool.acquire() as conn:
            result = await conn.execute(
                """
                UPDATE providers SET
                    provider_name = $2,
                    issuer_url = $3,
                    idp_config = $4::jsonb,
                    config = $5::jsonb,
                    updated_at = NOW(),
                    updated_by = $6
                WHERE id = $1
                """,
                provider_id,
                provider.provider_name,
                provider.issuer_url,
                json.dumps(provider.idp_config) if provider.idp_config else None,
                json.dumps(provider.config) if provider.config else None,
                updated_by,
            )
            if result != "UPDATE 1":
                raise ValueError(f"Provider {provider_id} not found or update failed")
            return await self.get_provider(provider_id)

    async def delete_provider(self, provider_id: int, updated_by: Optional[int] = None) -> bool:
        pool = self._need_pool()
        async with pool.acquire() as conn:
            result = await conn.execute(
                "UPDATE providers SET is_active = FALSE, updated_at = NOW(), updated_by = $2 WHERE id = $1",
                provider_id,
                updated_by,
            )
            return result == "UPDATE 1"

    async def _discover_endpoints(self, issuer_url: str) -> Dict[str, Any]:
        """Fetch OIDC .well-known/openid-configuration from the issuer."""
        discovery_url = issuer_url.rstrip("/") + "/.well-known/openid-configuration"
        try:
            async with httpx.AsyncClient(timeout=15.0) as client:
                resp = await client.get(discovery_url)
                resp.raise_for_status()
                data = resp.json()
                logger.info("OIDC discovery successful for %s", issuer_url)
                return data
        except Exception as exc:
            logger.warning("OIDC discovery failed for %s: %s", issuer_url, exc)
            return {}

    @staticmethod
    def _parse_jsonb(raw) -> Any:
        if isinstance(raw, str):
            return json.loads(raw)
        if isinstance(raw, dict):
            return raw
        if isinstance(raw, list):
            return raw
        return {}

    def _row_to_provider(self, row: asyncpg.Record) -> ProviderConfig:
        return ProviderConfig(
            id=row["id"],
            uuid=str(row["uuid"]) if row.get("uuid") else None,
            tenant_id=row["tenant_id"],
            provider_name=row["provider_name"],
            issuer_url=row["issuer_url"],
            idp_config=self._parse_jsonb(row["idp_config"]),
            config=self._parse_jsonb(row["config"]),
            is_active=row["is_active"],
            created_at=row["created_at"],
            updated_at=row["updated_at"],
            created_by=row["created_by"],
            updated_by=row["updated_by"],
        )

    # ──────────────────────────────────────────
    # Tenant CRUD (clean – no IDP fields)
    # ──────────────────────────────────────────

    async def create_tenant(self, tenant: TenantConfig) -> TenantConfig:
        """Insert a new tenant. Returns the TenantConfig with auto-generated id."""
        pool = self._need_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                """
                INSERT INTO tenants
                    (tenant_name, tenant_description, domain, is_active, details,
                     created_by, updated_by)
                VALUES ($1,$2,$3,TRUE,$4,$5,$5)
                RETURNING *
                """,
                tenant.tenant_name,
                tenant.tenant_description,
                tenant.domain,
                json.dumps(tenant.details) if tenant.details else None,
                tenant.created_by,
            )
        result = self._row_to_tenant(row)
        logger.info("Tenant %d ('%s') created", result.tenant_id, result.tenant_name)
        return result

    async def get_tenant(self, tenant_id: int) -> Optional[TenantConfig]:
        pool = self._need_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                "SELECT * FROM tenants WHERE id = $1 AND is_active = TRUE",
                tenant_id,
            )
            if not row:
                return None
            return self._row_to_tenant(row)

    async def get_tenant_by_name(self, tenant_name: str) -> Optional[TenantConfig]:
        """Fetch a tenant by unique name (API lookup)."""
        pool = self._need_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                "SELECT * FROM tenants WHERE tenant_name = $1 AND is_active = TRUE",
                tenant_name,
            )
            if not row:
                return None
            return self._row_to_tenant(row)

    async def list_tenants(self) -> List[TenantConfig]:
        pool = self._need_pool()
        async with pool.acquire() as conn:
            rows = await conn.fetch("SELECT * FROM tenants WHERE is_active = TRUE ORDER BY tenant_name")
            return [self._row_to_tenant(r) for r in rows]

    async def update_tenant(self, tenant: TenantConfig) -> bool:
        pool = self._need_pool()
        async with pool.acquire() as conn:
            result = await conn.execute(
                """
                UPDATE tenants SET
                    tenant_name = $2, tenant_description = $3, domain = $4, details = $5,
                    updated_at = NOW(), updated_by = $6
                WHERE id = $1 AND is_active = TRUE
                """,
                tenant.tenant_id,
                tenant.tenant_name,
                tenant.tenant_description,
                tenant.domain,
                json.dumps(tenant.details) if tenant.details else None,
                tenant.updated_by,
            )
            return result == "UPDATE 1"

    async def delete_tenant(self, tenant_id: int, updated_by: Optional[int] = None) -> bool:
        pool = self._need_pool()
        async with pool.acquire() as conn:
            result = await conn.execute(
                "UPDATE tenants SET is_active = FALSE, updated_at = NOW(), updated_by = $2 WHERE id = $1",
                tenant_id,
                updated_by,
            )
            return result == "UPDATE 1"

    def _row_to_tenant(self, row: asyncpg.Record) -> TenantConfig:
        return TenantConfig(
            tenant_id=row["id"],  # maps SERIAL 'id' to the tenant_id field
            uuid=str(row["uuid"]) if row.get("uuid") else None,
            tenant_name=row["tenant_name"],
            tenant_description=row["tenant_description"],
            domain=row["domain"],
            is_active=row["is_active"],
            details=self._parse_jsonb(row["details"]) if row["details"] else None,
            created_at=row["created_at"],
            updated_at=row["updated_at"],
            created_by=row["created_by"],
            updated_by=row["updated_by"],
        )

    # ──────────────────────────────────────────
    # App-Provider Junction CRUD
    # ──────────────────────────────────────────

    async def create_app_provider(self, ap: AppProviderConfig) -> AppProviderConfig:
        """Create a pure mapping between an app (int) and a provider (int)."""
        pool = self._need_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                """
                INSERT INTO app_providers
                    (app_id, tenant_id, provider_id, is_active, created_by, updated_by)
                VALUES ($1,$2,$3,TRUE,$4,$4)
                RETURNING *
                """,
                ap.app_id,
                ap.tenant_id,
                ap.provider_id,
                ap.created_by,
            )
        logger.info(
            "App-provider link created: app_id=%d tenant=%d provider_id=%d",
            ap.app_id, ap.tenant_id, ap.provider_id,
        )
        return self._row_to_app_provider(row)

    async def get_app_provider(
        self, app_id: int, provider_id: int
    ) -> Optional[AppProviderConfig]:
        pool = self._need_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                """
                SELECT * FROM app_providers
                WHERE app_id = $1 AND provider_id = $2 AND is_active = TRUE
                """,
                app_id, provider_id,
            )
            if not row:
                return None
            return self._row_to_app_provider(row)

    async def list_app_providers(self, app_id: int) -> List[AppProviderConfig]:
        """List all active provider mappings for a given app."""
        pool = self._need_pool()
        async with pool.acquire() as conn:
            rows = await conn.fetch(
                "SELECT * FROM app_providers WHERE app_id = $1 AND is_active = TRUE",
                app_id,
            )
            return [self._row_to_app_provider(r) for r in rows]

    async def list_providers_for_tenant(self, tenant_id: int) -> List[AppProviderConfig]:
        """List all active app-provider links for a tenant (across all apps)."""
        pool = self._need_pool()
        async with pool.acquire() as conn:
            rows = await conn.fetch(
                "SELECT * FROM app_providers WHERE tenant_id = $1 AND is_active = TRUE",
                tenant_id,
            )
            return [self._row_to_app_provider(r) for r in rows]

    async def update_app_provider(
        self, app_id: int, provider_id: int, app_provider: AppProviderConfig, updated_by: Optional[int] = None
    ) -> AppProviderConfig:
        """Update an app-provider link."""
        pool = self._need_pool()
        async with pool.acquire() as conn:
            result = await conn.execute(
                """
                UPDATE app_providers SET
                    app_id = $2,
                    provider_id = $3,
                    tenant_id = $4,
                    is_active = $5,
                    updated_at = NOW(),
                    updated_by = $6
                WHERE app_id = $1 AND provider_id = $7
                """,
                app_id,
                app_provider.app_id,
                app_provider.provider_id,
                app_provider.tenant_id,
                app_provider.is_active,
                updated_by,
                provider_id,
            )
            if result != "UPDATE 1":
                raise ValueError(f"App-provider link {app_id}-{provider_id} not found or update failed")
            return await self.get_app_provider(app_provider.app_id, app_provider.provider_id)

    async def delete_app_provider(
        self, app_id: int, provider_id: int, updated_by: Optional[int] = None
    ) -> bool:
        """Soft-delete an app-provider link."""
        pool = self._need_pool()
        async with pool.acquire() as conn:
            result = await conn.execute(
                """
                UPDATE app_providers SET is_active = FALSE, updated_at = NOW(), updated_by = $3
                WHERE app_id = $1 AND provider_id = $2
                """,
                app_id, provider_id, updated_by,
            )
            return result == "UPDATE 1"

    async def get_app_with_provider(
        self, tenant_name: str, app_name: str, provider_name: str
    ) -> Optional[Dict[str, Any]]:
        """
        Single-query resolution: tenant_name + app_name + provider_name → full config.
        Returns a dict with integer IDs and the full idp_config / config dicts.
        Used by both STANDALONE and PLATFORM auth flows.
        """
        pool = self._need_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                """
                SELECT
                    t.id          AS tenant_id,
                    t.tenant_name,
                    t.domain,
                    a.id          AS app_id,
                    a.app_name,
                    p.id          AS provider_id,
                    p.provider_name,
                    p.issuer_url,
                    p.idp_config,
                    p.config      AS provider_config
                FROM tenants t
                JOIN apps a        ON a.tenant_id = t.id AND a.app_name = $2
                JOIN providers p   ON p.tenant_id = t.id AND p.provider_name = $3
                JOIN app_providers ap ON ap.app_id = a.id AND ap.provider_id = p.id
                WHERE t.tenant_name = $1
                  AND t.is_active = TRUE
                  AND a.is_active = TRUE
                  AND p.is_active = TRUE
                  AND ap.is_active = TRUE
                """,
                tenant_name, app_name, provider_name,
            )
            if not row:
                return None
            result = dict(row)
            result["idp_config"] = self._parse_jsonb(result.get("idp_config"))
            result["config"] = self._parse_jsonb(result.pop("provider_config", None))
            return result

    async def get_app_with_provider_by_id(
        self, app_id: int, provider_id: int
    ) -> Optional[Dict[str, Any]]:
        """
        Same as get_app_with_provider but resolves by integer PKs instead of names.
        Used during token refresh / revoke where the session already has numeric IDs.
        """
        pool = self._need_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                """
                SELECT
                    t.id          AS tenant_id,
                    t.tenant_name,
                    t.domain,
                    a.id          AS app_id,
                    a.app_name,
                    p.id          AS provider_id,
                    p.provider_name,
                    p.issuer_url,
                    p.idp_config,
                    p.config      AS provider_config
                FROM apps a
                JOIN tenants t     ON t.id = a.tenant_id
                JOIN providers p   ON p.id = $2
                JOIN app_providers ap ON ap.app_id = a.id AND ap.provider_id = p.id
                WHERE a.id = $1
                  AND a.is_active = TRUE
                  AND p.is_active = TRUE
                  AND ap.is_active = TRUE
                """,
                app_id, provider_id,
            )
            if not row:
                return None
            result = dict(row)
            result["idp_config"] = self._parse_jsonb(result.get("idp_config"))
            result["config"] = self._parse_jsonb(result.pop("provider_config", None))
            return result

    def _row_to_app_provider(self, row: asyncpg.Record) -> AppProviderConfig:
        return AppProviderConfig(
            id=row["id"],
            app_id=row["app_id"],
            tenant_id=row["tenant_id"],
            provider_id=row["provider_id"],
            is_active=row["is_active"],
            created_at=row["created_at"],
            updated_at=row["updated_at"],
            created_by=row["created_by"],
            updated_by=row["updated_by"],
        )

    # ──────────────────────────────────────────
    # App CRUD
    # ──────────────────────────────────────────

    async def create_app(self, app: AppConfig) -> AppConfig:
        """Register a new application under a tenant. Returns the AppConfig with auto-generated id."""
        pool = self._need_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                """
                INSERT INTO apps (tenant_id, app_name, is_active, created_by, updated_by)
                VALUES ($1,$2,TRUE,$3,$3)
                RETURNING *
                """,
                app.tenant_id,
                app.app_name,
                app.created_by,
            )
        result = self._row_to_app(row)
        logger.info("App '%s' (id=%d) created for tenant %d", result.app_name, result.id, result.tenant_id)
        return result

    async def get_app(self, app_id: int) -> Optional[AppConfig]:
        """Fetch an app by integer PK."""
        pool = self._need_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                "SELECT * FROM apps WHERE id = $1 AND is_active = TRUE",
                app_id,
            )
            if not row:
                return None
            return self._row_to_app(row)

    async def get_app_by_name(self, tenant_id: int, app_name: str) -> Optional[AppConfig]:
        """Fetch an app by tenant + name (API lookup)."""
        pool = self._need_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                "SELECT * FROM apps WHERE tenant_id = $1 AND app_name = $2 AND is_active = TRUE",
                tenant_id, app_name,
            )
            if not row:
                return None
            return self._row_to_app(row)

    async def list_apps(self, tenant_id: int) -> List[AppConfig]:
        """List all active apps for a tenant."""
        pool = self._need_pool()
        async with pool.acquire() as conn:
            rows = await conn.fetch(
                "SELECT * FROM apps WHERE tenant_id = $1 AND is_active = TRUE ORDER BY app_name",
                tenant_id,
            )
            return [self._row_to_app(r) for r in rows]

    async def update_app(self, app: AppConfig) -> bool:
        pool = self._need_pool()
        async with pool.acquire() as conn:
            result = await conn.execute(
                """
                UPDATE apps SET app_name = $2, updated_at = NOW(), updated_by = $3
                WHERE id = $1 AND is_active = TRUE
                """,
                app.id,
                app.app_name,
                app.updated_by,
            )
            return result == "UPDATE 1"

    async def delete_app(self, app_id: int, updated_by: Optional[int] = None) -> bool:
        pool = self._need_pool()
        async with pool.acquire() as conn:
            result = await conn.execute(
                "UPDATE apps SET is_active = FALSE, updated_at = NOW(), updated_by = $2 WHERE id = $1",
                app_id, updated_by,
            )
            return result == "UPDATE 1"

    def _row_to_app(self, row: asyncpg.Record) -> AppConfig:
        return AppConfig(
            id=row["id"],
            uuid=str(row["uuid"]) if row.get("uuid") else None,
            tenant_id=row["tenant_id"],
            app_name=row["app_name"],
            is_active=row["is_active"],
            created_at=row["created_at"],
            updated_at=row["updated_at"],
            created_by=row["created_by"],
            updated_by=row["updated_by"],
        )

    # ──────────────────────────────────────────
    # Session CRUD
    # ──────────────────────────────────────────

    async def create_session(
        self,
        app_id: int,
        provider_id: int,
        tenant_id: int,
        user_id: int,
        user_attributes: Optional[Dict[str, Any]] = None,
        idp_tokens: Optional[Dict[str, Any]] = None,
        ttl_seconds: Optional[int] = None,
        created_by: Optional[int] = None,
        include_platform_tokens: bool = True,
        active_scope_id: Optional[int] = None,
    ) -> SessionRecord:
        """
        Create a new session record.

        tokens JSONB stores both sub-dicts:
            {"idp": {...}, "platform": {...}}
        idp tokens are server-side only; platform tokens are sent to the client.
        user_attributes holds email, name, roles, groups and any future claims.
        
        Parameters
        ----------
        include_platform_tokens : bool
            If True (PLATFORM mode), generate platform access/refresh tokens.
            If False (STANDALONE mode), only store IDP tokens.
        """
        # Use config default if ttl_seconds not provided
        if ttl_seconds is None:
            ttl_seconds = self._config.jwt_expiry_seconds if self._config else 3600
        
        session_id = str(uuid.uuid4())
        now = time.time()
        expires_at = now + ttl_seconds

        # Only create platform tokens for PLATFORM mode
        tokens = {"idp": idp_tokens or {}}
        if include_platform_tokens:
            platform_tokens = {
                "access_token": secrets.token_urlsafe(48),
                "refresh_token": secrets.token_urlsafe(48),
                "expires_at": expires_at,
            }
            tokens["platform"] = platform_tokens
        
        attrs = user_attributes or {}

        pool = self._need_pool()
        async with pool.acquire() as conn:
            await conn.execute(
                """
                INSERT INTO sessions
                    (id, tenant_id, app_id, provider_id, user_id,
                     user_attributes, tokens, issued_at, expires_at,
                     is_revoked, active_scope_id, created_by, updated_by)
                VALUES ($1,$2,$3,$4,$5,$6::jsonb,$7::jsonb,$8,$9,FALSE,$10,$11,$11)
                """,
                session_id,
                tenant_id,
                app_id,
                provider_id,
                user_id,
                json.dumps(attrs),
                json.dumps(tokens),
                now,
                expires_at,
                active_scope_id,
                created_by,
            )

        return SessionRecord(
            session_id=session_id,
            tenant_id=tenant_id,
            app_id=app_id,
            provider_id=provider_id,
            user_id=user_id,
            user_attributes=attrs,
            tokens=tokens,
            issued_at=now,
            expires_at=expires_at,
            is_revoked=False,
            active_scope_id=active_scope_id,
            created_by=created_by,
            updated_by=created_by,
        )

    async def get_session(self, session_id: str) -> Optional[SessionRecord]:
        pool = self._need_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                "SELECT * FROM sessions WHERE id = $1",
                session_id,
            )
            if not row:
                return None
            return self._row_to_session(row)

    async def get_session_by_refresh_token(self, platform_refresh_token: str) -> Optional[SessionRecord]:
        """Look up a valid session by its platform-generated refresh token."""
        pool = self._need_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                """
                SELECT * FROM sessions
                WHERE tokens->'platform'->>'refresh_token' = $1
                  AND is_revoked = FALSE
                  AND expires_at > $2
                """,
                platform_refresh_token,
                time.time(),
            )
            if not row:
                return None
            return self._row_to_session(row)

    async def update_session_tokens(
        self,
        session_id: str,
        idp_tokens: Optional[Dict[str, Any]] = None,
        platform_tokens: Optional[Dict[str, Any]] = None,
        updated_by: Optional[int] = None,
    ) -> bool:
        """
        Rotate tokens on a session (used during refresh).
        Updates the nested idp / platform sub-dicts inside the tokens JSONB.
        """
        pool = self._need_pool()
        async with pool.acquire() as conn:
            result = await conn.execute(
                """
                UPDATE sessions SET
                    tokens = jsonb_set(
                        jsonb_set(
                            COALESCE(tokens, '{}'::jsonb),
                            '{idp}',
                            COALESCE($2::jsonb, tokens->'idp', '{}'::jsonb)
                        ),
                        '{platform}',
                        COALESCE($3::jsonb, tokens->'platform', '{}'::jsonb)
                    ),
                    updated_at = NOW(),
                    updated_by = $4
                WHERE id = $1 AND is_revoked = FALSE
                """,
                session_id,
                json.dumps(idp_tokens) if idp_tokens else None,
                json.dumps(platform_tokens) if platform_tokens else None,
                updated_by,
            )
            return result == "UPDATE 1"

    async def is_session_valid(self, session_id: str) -> bool:
        """Check if session exists, is not revoked, and has not expired."""
        session = await self.get_session(session_id)
        if not session:
            return False
        if session.is_revoked:
            return False
        if session.expires_at < time.time():
            return False
        return True

    async def revoke_session(self, session_id: str, updated_by: Optional[int] = None) -> bool:
        """Revoke a single session (logout)."""
        pool = self._need_pool()
        async with pool.acquire() as conn:
            result = await conn.execute(
                "UPDATE sessions SET is_revoked = TRUE, updated_at = NOW(), updated_by = $2 WHERE id = $1",
                session_id,
                updated_by,
            )
            return result == "UPDATE 1"

    async def revoke_user_sessions(self, user_id: str, tenant_id: int, updated_by: Optional[int] = None) -> int:
        """Revoke all sessions for a user in a tenant (force-logout)."""
        pool = self._need_pool()
        async with pool.acquire() as conn:
            result = await conn.execute(
                "UPDATE sessions SET is_revoked = TRUE, updated_at = NOW(), updated_by = $3 WHERE user_id = $1 AND tenant_id = $2 AND is_revoked = FALSE",
                user_id,
                tenant_id,
                updated_by,
            )
            count = int(result.split(" ")[1]) if result else 0
            return count

    async def list_active_sessions(self, tenant_id: int) -> List[SessionRecord]:
        """List all active (non-revoked, non-expired) sessions for a tenant."""
        pool = self._need_pool()
        async with pool.acquire() as conn:
            rows = await conn.fetch(
                """
                SELECT * FROM sessions
                WHERE tenant_id = $1 AND is_revoked = FALSE AND expires_at > $2
                ORDER BY issued_at DESC
                """,
                tenant_id,
                time.time(),
            )
            return [self._row_to_session(r) for r in rows]

    async def cleanup_expired_sessions(self, retention_days: int = 30) -> int:
        """
        Delete sessions that expired more than N days ago.
        
        Parameters
        ----------
        retention_days : int
            Keep expired sessions for this many days before deletion (default: 30).
            This allows for audit trails and debugging of recent sessions.
        
        Returns
        -------
        int : Number of sessions deleted.
        """
        pool = self._need_pool()
        cutoff = time.time() - (retention_days * 86400)
        async with pool.acquire() as conn:
            result = await conn.execute(
                "DELETE FROM sessions WHERE expires_at < $1", cutoff
            )
            count = int(result.split(" ")[1]) if result else 0
            return count

    def _row_to_session(self, row: asyncpg.Record) -> SessionRecord:
        return SessionRecord(
            session_id=row["id"],
            tenant_id=row["tenant_id"],
            app_id=row["app_id"],
            provider_id=row["provider_id"],
            user_id=row["user_id"],
            user_attributes=self._parse_jsonb(row["user_attributes"]),
            tokens=self._parse_jsonb(row["tokens"]),
            audit_log=self._parse_jsonb(row.get("audit_log", "[]")),
            issued_at=row["issued_at"],
            expires_at=row["expires_at"],
            is_revoked=row["is_revoked"],
            active_scope_id=row.get("active_scope_id"),
            created_at=row["created_at"],
            updated_at=row["updated_at"],
            created_by=row["created_by"],
            updated_by=row["updated_by"],
        )

    # ──────────────────────────────────────────
    # Tenant Keys (RS256 – per tenant)
    # ──────────────────────────────────────────

    async def store_tenant_key(
        self, tenant_id: int, public_key_pem: str, private_key_pem: str,
        created_by: Optional[int] = None,
    ) -> None:
        """Store an RSA key pair for a tenant. The key_id is auto-generated SERIAL."""
        pool = self._need_pool()
        async with pool.acquire() as conn:
            await conn.execute(
                """
                INSERT INTO tenant_keys (tenant_id, public_key_pem, private_key_pem, algorithm, is_active,
                    created_by, updated_by)
                VALUES ($1, $2, $3, 'RS256', TRUE, $4, $4)
                """,
                tenant_id,
                public_key_pem,
                private_key_pem,
                created_by,
            )
        logger.info("Tenant key stored for tenant %d", tenant_id)

    async def get_active_tenant_key(self, tenant_id: int) -> Optional[Dict[str, Any]]:
        """Get the newest active signing key for a tenant (for JWT signing)."""
        pool = self._need_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                """
                SELECT * FROM tenant_keys
                WHERE tenant_id = $1 AND is_active = TRUE
                ORDER BY created_at DESC LIMIT 1
                """,
                tenant_id,
            )
            if not row:
                return None
            return {
                "key_id": row["key_id"],
                "tenant_id": row["tenant_id"],
                "public_key_pem": row["public_key_pem"],
                "private_key_pem": row["private_key_pem"],
                "algorithm": row["algorithm"],
            }

    async def get_all_public_keys(self, tenant_id: Optional[int] = None) -> List[Dict[str, Any]]:
        """Get all active public keys. Optionally filter by tenant_id. Used for JWKS endpoint."""
        pool = self._need_pool()
        async with pool.acquire() as conn:
            if tenant_id:
                rows = await conn.fetch(
                    "SELECT key_id, tenant_id, public_key_pem, algorithm FROM tenant_keys WHERE tenant_id = $1 AND is_active = TRUE",
                    tenant_id,
                )
            else:
                rows = await conn.fetch(
                    "SELECT key_id, tenant_id, public_key_pem, algorithm FROM tenant_keys WHERE is_active = TRUE"
                )
            return [dict(r) for r in rows]

    async def deactivate_tenant_key(self, key_id: str, updated_by: Optional[int] = None) -> bool:
        """Deactivate a tenant key (key rotation)."""
        pool = self._need_pool()
        async with pool.acquire() as conn:
            result = await conn.execute(
                "UPDATE tenant_keys SET is_active = FALSE, updated_at = NOW(), updated_by = $2 WHERE key_id = $1",
                key_id,
                updated_by,
            )
            return result == "UPDATE 1"

    # ──────────────────────────────────────────
    # STANDALONE INITIALIZATION
    # ──────────────────────────────────────────

    async def initialize_standalone(
        self,
        tenant_name: str,
        app_name: str,
        provider_name: str,
        issuer_url: str,
        client_id: str,
        client_secret: str,
        redirect_uri: str,
        public_key_pem: str,
        private_key_pem: str,
        tenant_description: Optional[str] = None,
        domain: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None,
        created_by: Optional[int] = None,
        updated_by: Optional[int] = None,
    ) -> Dict[str, Any]:
        """
        Initialize standalone deployment with tenant, provider, app, and keys.
        This is the programmatic equivalent of seed.py --setup-standalone.
        All operations are idempotent.
        
        Returns:
            Dict with tenant_id, app_id, provider_id, scopes, and status message.
        """
        from .interfaces import TenantConfig, ProviderConfig, AppConfig, AppProviderConfig
        
        # 1. Create or get tenant
        tenants = await self.list_tenants()
        existing_tenant = next((t for t in tenants if t.tenant_name == tenant_name), None)
        if existing_tenant:
            tenant_id = existing_tenant.tenant_id
            logger.info(f"Tenant '{tenant_name}' already exists (id={tenant_id})")

            # If optional metadata is provided, update the existing tenant.
            if any([
                tenant_description is not None,
                domain is not None,
                details is not None,
                updated_by is not None,
            ]):
                updated = TenantConfig(
                    tenant_id=tenant_id,
                    tenant_name=tenant_name,
                    tenant_description=tenant_description if tenant_description is not None else existing_tenant.tenant_description,
                    domain=domain if domain is not None else existing_tenant.domain,
                    details=details if details is not None else existing_tenant.details,
                    updated_by=updated_by,
                )
                await self.update_tenant(updated)
        else:
            tenant = TenantConfig(
                tenant_name=tenant_name,
                tenant_description=tenant_description or f"Standalone tenant for {tenant_name}",
                domain=domain,
                details=details,
                created_by=created_by,
            )
            created_tenant = await self.create_tenant(tenant)
            tenant_id = created_tenant.tenant_id
            logger.info(f"Tenant '{tenant_name}' created (id={tenant_id})")
        
        # 2. Create or get provider (with OIDC discovery)
        existing_provider = await self.get_provider_by_name(tenant_id, provider_name)
        if existing_provider:
            provider_id = existing_provider.id
            allowed_scopes = existing_provider.idp_config.get("allowed_scopes", [])
            logger.info(f"Provider '{provider_name}' already exists (id={provider_id})")
        else:
            # Detect provider type and set appropriate scopes
            provider_lower = provider_name.lower()
            if "microsoft" in provider_lower or "azure" in provider_lower:
                allowed_scopes = ["openid", "profile", "email", "offline_access"]
            else:
                allowed_scopes = ["openid", "profile", "email"]
            
            provider = ProviderConfig(
                tenant_id=tenant_id,
                provider_name=provider_name,
                issuer_url=issuer_url,
                idp_config={
                    "client_id": client_id,
                    "client_secret": client_secret,
                    "redirect_uris": [redirect_uri],
                    "allowed_scopes": allowed_scopes,
                },
                config={},
            )
            created_provider = await self.create_provider(provider)
            provider_id = created_provider.id
            logger.info(
                f"Provider '{provider_name}' created (id={provider_id}). "
                f"OIDC endpoints discovered. Scopes: {allowed_scopes}"
            )
        
        # 3. Create or get app
        apps = await self.list_apps(tenant_id)
        existing_app = next((a for a in apps if a.app_name == app_name), None)
        if existing_app:
            app_id = existing_app.id
            logger.info(f"App '{app_name}' already exists (id={app_id})")
        else:
            app = AppConfig(
                tenant_id=tenant_id,
                app_name=app_name,
            )
            created_app = await self.create_app(app)
            app_id = created_app.id
            logger.info(f"App '{app_name}' created (id={app_id})")
        
        # 4. Link app to provider
        existing_link = await self.get_app_provider(app_id, provider_id)
        if existing_link:
            logger.info(f"App-provider link already exists")
        else:
            ap = AppProviderConfig(
                app_id=app_id,
                tenant_id=tenant_id,
                provider_id=provider_id,
            )
            await self.create_app_provider(ap)
            logger.info(f"App {app_id} linked to provider {provider_id}")
        
        # 5. Store tenant signing key
        existing_key = await self.get_active_tenant_key(tenant_id)
        if existing_key:
            logger.info(f"Signing key for tenant {tenant_id} already exists")
        else:
            await self.store_tenant_key(
                tenant_id=tenant_id,
                public_key_pem=public_key_pem,
                private_key_pem=private_key_pem,
            )
            logger.info(f"Tenant key stored for tenant {tenant_id}")
        
        return {
            "tenant_id": tenant_id,
            "tenant_name": tenant_name,
            "app_id": app_id,
            "app_name": app_name,
            "provider_id": provider_id,
            "provider_name": provider_name,
            "scopes": allowed_scopes,
            "message": "Standalone initialization complete",
        }

