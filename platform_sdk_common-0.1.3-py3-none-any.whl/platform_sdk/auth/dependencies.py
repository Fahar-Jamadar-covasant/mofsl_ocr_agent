"""
FastAPI dependencies for route protection.

Four levels:
    require_auth       – any logged-in user (validates wrapper JWT)
    require_roles      – user must have specific roles
    require_tenant     – user's tenant_id must match the path parameter
    require_permission – RBAC permission check (resource + action)
"""

from typing import Any, Dict, List, Optional, TYPE_CHECKING
import time
import jwt

from .jwt_wrapper import JWTWrapper
from .interfaces import OAuthConfig, OAuthTokenExpiredError

if TYPE_CHECKING:
    from .database import AuthDatabase
    from .authorization import AuthorizationEngine

try:
    from fastapi import HTTPException, Depends
    from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
except ImportError:
    raise ImportError("Install fastapi to use auth dependencies: pip install fastapi")

_bearer_scheme = HTTPBearer()


class _AuthDependency:
    """
    Validates the wrapper JWT from the Authorization header.
    Returns the full claims dict on success.
    
    IMPORTANT: Also checks if session is revoked (logout protection).

    Usage:
        auth = require_auth(config, database=db)

        @app.get("/protected")
        async def protected(user: dict = Depends(auth)):
            print(user["sub"], user["email"], user["tenant_id"])
    """

    def __init__(self, config: OAuthConfig, database: Optional[Any] = None):
        self._jwt = JWTWrapper(config)
        self._db = database

    async def __call__(
        self,
        credentials: HTTPAuthorizationCredentials = Depends(_bearer_scheme),
    ) -> Dict[str, Any]:
        try:
            claims = self._jwt.decode_claims(credentials.credentials)

            # Check if session is revoked or expired (logout + expiry protection)
            if self._db:
                session_id = claims.get("session_id")
                if session_id:
                    session = await self._db.get_session(session_id)
                    if not session:
                        raise HTTPException(status_code=401, detail="Session not found")
                    if session.is_revoked:
                        raise HTTPException(status_code=401, detail="Session has been revoked (logged out)")
                    # Check session expiry and auto-revoke if expired
                    if session.expires_at < time.time():
                        # Auto-revoke expired session
                        await self._db.revoke_session(session_id)
                        raise HTTPException(status_code=401, detail="Session has expired")

                    # Validate scope context: JWT active_scope_id must match session active_scope_id
                    jwt_scope_id = claims.get("active_scope_id")
                    session_scope_id = session.active_scope_id if hasattr(session, 'active_scope_id') else None
                    if jwt_scope_id != session_scope_id:
                        # Mismatch indicates scope switch occurred — old JWT is invalid
                        raise HTTPException(
                            status_code=401,
                            detail="Scope context changed. Please re-authenticate or refresh token."
                        )

            # Add raw token to claims for delegation to platform service
            claims["_raw_token"] = credentials.credentials
            return claims
        except HTTPException:
            raise
        except OAuthTokenExpiredError:
            # Auto-revoke session when JWT expires
            if self._db:
                try:
                    # Decode expired JWT to get session_id for revocation
                    key = self._jwt._get_verify_key(credentials.credentials)
                    # Decode without expiry verification to get claims
                    expired_claims = jwt.decode(
                        credentials.credentials,
                        key,
                        algorithms=[self._jwt._alg],
                        issuer=self._jwt._iss,
                        audience=self._jwt._aud,
                        options={"verify_exp": False}  # Skip expiry check
                    )
                    session_id = expired_claims.get("session_id")
                    if session_id:
                        await self._db.revoke_session(session_id)
                except Exception:
                    # If we can't decode or revoke, continue with expiry error
                    pass
            raise HTTPException(status_code=401, detail="Token expired")
        except Exception as exc:
            raise HTTPException(status_code=401, detail=f"Invalid token: {exc}")


class _RoleDependency:
    """
    Validates JWT and checks that the user has every role in required_roles.

    Usage:
        admin = require_roles(config, ["admin"], database=db)

        @app.delete("/users/{uid}")
        async def delete_user(uid: str, user: dict = Depends(admin)):
            ...
    """

    def __init__(self, config: OAuthConfig, required_roles: List[str], database: Optional[Any] = None):
        self._auth = _AuthDependency(config, database=database)
        self._roles = required_roles

    async def __call__(
        self,
        credentials: HTTPAuthorizationCredentials = Depends(_bearer_scheme),
    ) -> Dict[str, Any]:
        claims = await self._auth(credentials=credentials)
        user_roles: List[str] = claims.get("roles", [])
        missing = [r for r in self._roles if r not in user_roles]
        if missing:
            raise HTTPException(
                status_code=403,
                detail=f"Missing required roles: {', '.join(missing)}",
            )
        return claims


class _TenantDependency:
    """
    Validates JWT and ensures the token's tenant_id matches the
    tenant_id path parameter. Prevents cross-tenant data access.

    Usage:
        tenant_check = require_tenant(config, database=db)

        @app.get("/tenants/{tenant_id}/data")
        async def tenant_data(tenant_id: str, user: dict = Depends(tenant_check)):
            ...
    """

    def __init__(self, config: OAuthConfig, database: Optional[Any] = None):
        self._auth = _AuthDependency(config, database=database)

    async def __call__(
        self,
        tenant_id: str,
        credentials: HTTPAuthorizationCredentials = Depends(_bearer_scheme),
    ) -> Dict[str, Any]:
        claims = await self._auth(credentials=credentials)
        if claims.get("tenant_id") != tenant_id:
            raise HTTPException(
                status_code=403,
                detail="Token tenant does not match requested tenant",
            )
        return claims


def require_auth(config: OAuthConfig, database: Optional[Any] = None) -> _AuthDependency:
    """Returns a FastAPI dependency that validates the wrapper JWT and checks session revocation."""
    return _AuthDependency(config, database=database)


def require_roles(config: OAuthConfig, roles: List[str], database: Optional[Any] = None) -> _RoleDependency:
    """Returns a FastAPI dependency that validates JWT + checks roles."""
    return _RoleDependency(config, roles, database=database)


def require_tenant(config: OAuthConfig, database: Optional[Any] = None) -> _TenantDependency:
    """Returns a FastAPI dependency that validates JWT + tenant isolation."""
    return _TenantDependency(config, database=database)


class _PermissionDependency:
    """
    Validates JWT and checks RBAC permission using AuthorizationEngine.
    
    Checks if the user can perform the specified action on the specified resource
    based on their roles, the app's scope, and the RBAC policies.
    
    Usage:
        from platform_sdk.auth.authorization import AuthorizationEngine
        
        auth_engine = AuthorizationEngine(db)
        can_read_users = require_permission(
            config, 
            auth_engine, 
            resource_path="/users", 
            action="read",
            database=db
        )
        
        @app.get("/users")
        async def list_users(user: dict = Depends(can_read_users)):
            # User is authorized to read /users
            return {"users": [...]}
    """
    
    def __init__(
        self, 
        config: OAuthConfig, 
        auth_engine: "AuthorizationEngine",
        resource_path: str,
        action: str,
        database: Optional[Any] = None
    ):
        self._auth = _AuthDependency(config, database=database)
        self._engine = auth_engine
        self._resource = resource_path
        self._action = action
    
    async def __call__(
        self,
        credentials: HTTPAuthorizationCredentials = Depends(_bearer_scheme),
    ) -> Dict[str, Any]:
        claims = await self._auth(credentials=credentials)

        # Extract required info from JWT
        user_id = claims.get("sub")
        tenant_id = claims.get("tenant_id")
        app_id = claims.get("app_id")

        if not all([user_id, tenant_id, app_id]):
            raise HTTPException(
                status_code=403,
                detail="Missing required claims in JWT (user_id, tenant_id, app_id)"
            )

        # Resolve role_ids for RBAC evaluation
        # If JWT is scoped (scope_mode="scoped"), use role names from JWT (already filtered for that scope)
        # Otherwise (scope_mode="global"), let AuthorizationEngine fetch all user roles from DB
        role_ids = None
        scope_mode = claims.get("scope_mode", "global")
        if scope_mode == "scoped":
            jwt_role_names: List[str] = claims.get("roles", [])
            if jwt_role_names:
                try:
                    role_ids = await self._engine.get_role_ids_by_names(jwt_role_names, tenant_id)
                except Exception as e:
                    import logging
                    logger = logging.getLogger(__name__)
                    logger.warning(f"Failed to resolve scoped role IDs for user {user_id}: {e}")

        # Check permission using AuthorizationEngine
        try:
            allowed, reason, policy = await self._engine.can_user_perform(
                user_id=int(user_id) if isinstance(user_id, str) else user_id,
                tenant_id=int(tenant_id) if isinstance(tenant_id, str) else tenant_id,
                app_id=int(app_id) if isinstance(app_id, str) else app_id,
                resource_path=self._resource,
                action_name=self._action,
                role_ids=role_ids
            )
        except Exception as e:
            # Log error and deny access on RBAC system failure
            import logging
            logger = logging.getLogger(__name__)
            logger.error(f"RBAC permission check failed for user {user_id}, resource {self._resource}, action {self._action}: {e}")
            raise HTTPException(
                status_code=403,
                detail="Permission check failed - contact administrator"
            )

        if not allowed:
            raise HTTPException(
                status_code=403,
                detail=f"Permission denied: {reason}"
            )

        # Add permission info to claims for downstream use
        claims["_rbac_check"] = {
            "resource": self._resource,
            "action": self._action,
            "allowed": True,
            "reason": reason,
            "policy_id": policy.get("id") if policy else None
        }

        return claims


def require_permission(
    config: OAuthConfig,
    auth_engine: "AuthorizationEngine",
    resource_path: str,
    action: str,
    database: Optional[Any] = None
) -> _PermissionDependency:
    """
    Returns a FastAPI dependency that validates JWT + checks RBAC permission.
    
    Args:
        config: OAuth configuration
        auth_engine: AuthorizationEngine instance
        resource_path: Resource path to check (e.g., "/users", "/pipelines/123")
        action: Action to check (e.g., "read", "create", "update", "delete")
        database: Optional database instance for session revocation checks
    
    Example:
        from platform_sdk.auth.authorization import AuthorizationEngine
        
        db = AuthDatabase(...)
        auth_engine = AuthorizationEngine(db)
        
        can_read_pipelines = require_permission(
            config, auth_engine, "/pipelines", "read", database=db
        )
        
        @app.get("/pipelines")
        async def list_pipelines(user: dict = Depends(can_read_pipelines)):
            return {"pipelines": [...]}
    """
    return _PermissionDependency(config, auth_engine, resource_path, action, database=database)
