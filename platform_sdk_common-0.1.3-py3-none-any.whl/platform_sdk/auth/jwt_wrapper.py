"""
JWT wrapper – packs / unpacks OAuth tokens inside a signed JWT.
Supports HS256 (STANDALONE) and RS256 (PLATFORM).
"""

import time
from typing import Any, Dict, List, Optional

import jwt
from jwt import PyJWKClient

from platform_sdk.common import ValidationError
from .interfaces import (
    OAuthConfig,
    OAuthTokenExpiredError,
    JWTAlgorithm,
)


class JWTWrapper:
    """
    HS256 (STANDALONE): same key signs and verifies.
    RS256 (PLATFORM):   private key signs (platform service), public key verifies (apps).
    """

    def __init__(self, config: OAuthConfig):
        self._alg = config.jwt_algorithm.value
        self._iss = config.jwt_issuer
        self._aud = config.jwt_audience
        self._exp = config.jwt_expiry_seconds

        # Signing key (for wrap) – only platform service or STANDALONE app has this
        self._sign_key: Optional[str] = config.jwt_signing_key

        # Verification key (for unwrap / decode_claims)
        if config.jwt_algorithm == JWTAlgorithm.HS256:
            self._verify_key: Optional[str] = config.jwt_signing_key
        else:
            self._verify_key = config.jwt_public_key

        self._jwks_uri = config.jwt_jwks_uri
        self._jwks_client: Optional[PyJWKClient] = None

    def _get_verify_key(self, token: str) -> Any:
        """
        Resolve the verification key.

        HS256          → shared secret string
        RS256 (PEM)    → PEM public key string
        RS256 (JWKS)   → fetched from JWKS endpoint using kid in JWT header
        """
        if self._verify_key:
            return self._verify_key

        if self._jwks_uri:
            if not self._jwks_client:
                self._jwks_client = PyJWKClient(self._jwks_uri, cache_keys=True)
            return self._jwks_client.get_signing_key_from_jwt(token).key

        raise ValidationError(
            "No verification key. Provide jwt_signing_key (HS256), "
            "jwt_public_key (RS256), or jwt_jwks_uri (RS256 JWKS)."
        )

    def wrap(
        self,
        provider: str,
        user_id: str,
        session_id: str,
        idp_sub: Optional[str] = None,
        email: Optional[str] = None,
        name: Optional[str] = None,
        groups: Optional[List[str]] = None,
        tenant_id: Optional[Any] = None,
        tenant_uuid: Optional[str] = None,
        app_id: Optional[Any] = None,
        app_uuid: Optional[str] = None,
        provider_id: Optional[Any] = None,
        provider_uuid: Optional[str] = None,
        roles: Optional[List[str]] = None,
        scopes: Optional[List[str]] = None,
        user_uuid: Optional[str] = None,
        perms: Optional[str] = None,
        user_type: Optional[str] = None,
        kid: Optional[str] = None,
        signing_key: Optional[str] = None,
        active_scope_id: Optional[int] = None,
        active_scope_name: Optional[str] = None,
        active_scope_uuid: Optional[str] = None,
        entity_level: Optional[str] = None,
    ) -> str:
        """
        Sign a JWT with user info and session reference.

        No IDP tokens are included in the JWT payload.
        IDP tokens are stored server-side in the sessions table.

        Parameters
        ----------
        roles       : List of role names to embed in the JWT payload.
        scopes      : List of scope names user has access to (via groups).
        perms       : Base64 encoded RBAC resource-group permissions (union of all roles).
        kid         : Key ID to include in JWT header (required for JWKS verification).
        signing_key : Override signing key (e.g. per-tenant private key from DB).
                      Falls back to self._sign_key if not provided.
        """
        effective_key = signing_key or self._sign_key
        if not effective_key:
            raise ValidationError(
                "Cannot sign JWT: no signing key available. "
                "Only the platform service or STANDALONE app can sign."
            )

        now = time.time()

        payload: Dict[str, Any] = {
            "sub": user_id,
            "user_uuid": user_uuid,
            "iss": self._iss,
            "aud": self._aud,
            "iat": now,
            "exp": now + self._exp,
            "email": email,
            "name": name,
            "roles": sorted(roles or []),
            "scopes": sorted(scopes or []),
            "groups": groups or [],
            "provider": provider,
            "tenant_id": tenant_id,
            "tenant_uuid": tenant_uuid,
            "app_id": app_id,
            "app_uuid": app_uuid,
            "provider_id": provider_id,
            "provider_uuid": provider_uuid,
            "session_id": session_id,
        }

        if active_scope_id is not None:
            payload["active_scope_id"] = active_scope_id
            payload["active_scope_uuid"] = active_scope_uuid
            payload["active_scope_name"] = active_scope_name
            payload["entity_level"] = entity_level

        if perms:
            payload["perms"] = perms

        if user_type:
            payload["user_type"] = user_type

        if idp_sub is not None:
            payload["idp_sub"] = idp_sub

        headers: Dict[str, Any] = {}
        if kid:
            headers["kid"] = kid

        return jwt.encode(payload, effective_key, algorithm=self._alg, headers=headers or None)

    def decode_claims(self, token: str) -> Dict[str, Any]:
        """Verify the wrapper JWT and return the full claims dict (used by route protection)."""
        try:
            key = self._get_verify_key(token)
            return jwt.decode(
                token,
                key,
                algorithms=[self._alg],
                issuer=self._iss,
                audience=self._aud,
            )
        except jwt.ExpiredSignatureError:
            raise OAuthTokenExpiredError("Wrapper JWT has expired")
        except jwt.InvalidTokenError as exc:
            raise ValidationError(f"Invalid wrapper JWT: {exc}")
