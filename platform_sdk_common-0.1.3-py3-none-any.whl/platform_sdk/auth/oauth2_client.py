"""
OAuth 2.1 client – implements the five core methods for both modes.

STANDALONE: Uses Authlib + OIDC discovery to talk directly to the IDP.
PLATFORM:   Delegates every call to the Platform OAuth service via httpx.

Supports PKCE (required by OAuth 2.1), OIDC auto-discovery of endpoints,
session creation, and pluggable state storage.
"""

import base64
import hashlib
import logging
import os
import secrets
import time
import uuid
from typing import Any, Dict, List, Optional, Tuple

import httpx
from authlib.integrations.httpx_client import AsyncOAuth2Client

from platform_sdk.common import BaseProvider
from .database import AuthDatabase
from .user_management import UserManagement
from .authorization import AuthorizationEngine
from .interfaces import (
    OAuthConfig,
    OAuthMode,
    OAuthResult,
    OAuthState,
    OAuth2Provider,
    OAuthError,
    OAuthConfigurationError,
    SessionRecord,
)
from .jwt_wrapper import JWTWrapper
from .state_store import StateStore, InMemoryStateStore

logger = logging.getLogger(__name__)


def _pkce_pair() -> Tuple[str, str]:
    """Generate PKCE code_verifier and code_challenge (S256)."""
    verifier = secrets.token_urlsafe(48)
    digest = hashlib.sha256(verifier.encode("ascii")).digest()
    challenge = base64.urlsafe_b64encode(digest).rstrip(b"=").decode("ascii")
    return verifier, challenge


async def _discover_oidc(issuer_url: str) -> Dict[str, Any]:
    """Fetch OIDC .well-known/openid-configuration from an issuer URL."""
    discovery_url = issuer_url.rstrip("/") + "/.well-known/openid-configuration"
    async with httpx.AsyncClient(timeout=15.0) as client:
        resp = await client.get(discovery_url)
        resp.raise_for_status()
        return resp.json()


def _select_redirect_uri(redirect_uris: List[str], base_url: Optional[str]) -> Optional[str]:
    """
    Select redirect URI whose scheme+host matches the current request's base URL.

    When the same database is shared between local dev and deployed environments,
    multiple redirect URIs may be configured. This function selects the one that
    matches the incoming request's origin to avoid mismatched URIs.

    Args:
        redirect_uris: List of redirect URIs configured in the database (e.g.,
                      ['https://api.prod.example.com/auth/callback', 'http://localhost:8000/auth/callback'])
        base_url: The incoming request's base URL (e.g., 'http://localhost:8000/')

    Returns:
        The selected redirect URI, or the first in the list if no match is found.
    """
    if not redirect_uris:
        return None
    if base_url:
        from urllib.parse import urlparse
        parsed = urlparse(base_url)
        current_base = f"{parsed.scheme}://{parsed.netloc}"
        for uri in redirect_uris:
            if uri.startswith(current_base):
                return uri
    return redirect_uris[0]


class OAuth2Client(BaseProvider[OAuthConfig], OAuth2Provider):
    """
    Concrete OAuth 2.1 client for STANDALONE and PLATFORM modes.

    STANDALONE:
        - Uses issuer_url to auto-discover endpoints (or uses explicit endpoints)
        - Requires AuthDatabase for session management (same schema as PLATFORM)
        - Uses Authlib AsyncOAuth2Client for token exchange
        - Resolves tenant/app from config.default_tenant_name + default_app_name + default_provider_name

    PLATFORM:
        - Delegates all calls to the Platform OAuth HTTP service
        - Does not use AuthDatabase directly
    """

    def __init__(
        self,
        config: OAuthConfig,
        state_store: Optional[StateStore] = None,
        database: Optional[AuthDatabase] = None,
    ):
        super().__init__(config)

        # STANDALONE mode requires AuthDatabase (unified schema)
        if config.mode == OAuthMode.STANDALONE and not database:
            raise OAuthConfigurationError(
                "STANDALONE mode requires AuthDatabase for session management. "
                "Provide database parameter: OAuth2Client(config, database=AuthDatabase(url))"
            )

        self._jwt = JWTWrapper(config)
        self._state_store = state_store or InMemoryStateStore()
        self._db: Optional[AuthDatabase] = database
        self._oauth: Optional[AsyncOAuth2Client] = None
        self._platform: Optional[httpx.AsyncClient] = None

        # Permission cache: {cache_key: (perms, expiry_time)}
        # Cache key format: f"{user_id}:{tenant_id}:{app_id}:{scope_id}"
        self._perm_cache: Dict[str, Tuple[str, float]] = {}
        self._perm_cache_ttl = 1800  # 30 minutes

    # ── lifecycle ─────────────────────────────

    async def initialize(self) -> None:
        if self.config.mode == OAuthMode.STANDALONE:
            # IDP credentials and endpoints are resolved per-request from the DB.
            # No static OAuth client is built at startup.
            pass
        else:
            headers = {"Content-Type": "application/json"}
            if self.config.platform_api_key:
                headers["X-Api-Key"] = self.config.platform_api_key
            self._platform = httpx.AsyncClient(
                base_url=self.config.platform_oauth_url,
                headers=headers,
                timeout=30.0,
            )
        self._initialized = True
        logger.info("OAuth2Client initialised in %s mode", self.config.mode.value)

    async def shutdown(self) -> None:
        if self._oauth:
            await self._oauth.aclose()
        if self._platform:
            await self._platform.aclose()
        self._initialized = False

    def validate_config(self) -> bool:
        try:
            self.config._check_mode_fields()
            return True
        except Exception:
            return False

    # ── internal helpers ──────────────────────

    def _need_oauth(self, client_id: str, client_secret: str, redirect_uri: str, scope: Optional[str] = None) -> AsyncOAuth2Client:
        """Build a fresh Authlib client with DB-resolved credentials."""
        return AsyncOAuth2Client(
            client_id=client_id,
            client_secret=client_secret,
            scope=scope,
            redirect_uri=redirect_uri,
        )

    async def _resolve_idp_config(
        self, tenant_name: str, app_name: str, provider_name: str
    ) -> Dict[str, Any]:
        """Single-query name resolution → integer IDs + idp_config dict."""
        if not self._db:
            raise OAuthConfigurationError("No database configured for STANDALONE mode")
        data = await self._db.get_app_with_provider(tenant_name, app_name, provider_name)
        if not data:
            raise OAuthError(
                f"No active config: tenant='{tenant_name}' app='{app_name}' "
                f"provider='{provider_name}'. Run the seed script first."
            )
        idp = data.get("idp_config", {})
        if not idp.get("authorize_url") or not idp.get("token_url"):
            raise OAuthError(
                f"Provider '{provider_name}' missing endpoint config. Re-run seed script."
            )
        return {
            "tenant_id": data["tenant_id"],
            "app_id": data["app_id"],
            "provider_id": data["provider_id"],
            "tenant_name": tenant_name,
            "app_name": app_name,
            "provider_name": provider_name,
            "client_id": idp.get("client_id"),
            "client_secret": idp.get("client_secret"),
            "redirect_uris": idp.get("redirect_uris", []),
            "allowed_scopes": idp.get("allowed_scopes", ["openid", "profile", "email"]),
            "authorize_url": idp.get("authorize_url"),
            "token_url": idp.get("token_url"),
            "userinfo_url": idp.get("userinfo_url"),
            "revoke_url": idp.get("revoke_url"),
            "issuer_url": data.get("issuer_url"),
        }

    def _need_platform(self) -> httpx.AsyncClient:
        if not self._platform:
            raise OAuthConfigurationError("Platform client not initialised (call initialize())")
        return self._platform

    async def _fetch_userinfo(self, access_token: str, userinfo_url: Optional[str] = None) -> Dict[str, Any]:
        """Call the IDP / Platform userinfo endpoint."""
        url = userinfo_url or self.config.userinfo_endpoint
        if self.config.mode == OAuthMode.STANDALONE:
            if not url:
                raise OAuthError("No userinfo_endpoint configured or discovered")
            async with httpx.AsyncClient() as c:
                r = await c.get(url, headers={"Authorization": f"Bearer {access_token}"})
                r.raise_for_status()
                userinfo = r.json()
                logger.info("Userinfo fetched: %s", userinfo)
                return userinfo
        else:
            r = await self._need_platform().get(
                "/api/v1/auth/userinfo",
                headers={"Authorization": f"Bearer {access_token}"},
            )
            r.raise_for_status()
            return r.json()

    def _build_result(
        self,
        jwt_token: str,
        session_id: str,
        userinfo: Dict[str, Any],
        provider: str,
        tenant_id: Optional[int],
        expires_at: Optional[float],
    ) -> OAuthResult:
        # STANDALONE mode: no refresh_token in response
        # PLATFORM mode: includes platform_refresh_token
        refresh_token = None
        if self.config.mode == OAuthMode.PLATFORM:
            # PLATFORM mode would include platform_refresh_token here
            # For now, keep None - platform service handles this
            pass
        
        return OAuthResult(
            jwt_token=jwt_token,
            refresh_token=refresh_token,  # STANDALONE: None, PLATFORM: platform_refresh_token
            session_id=session_id,
            user_id=userinfo.get("sub", userinfo.get("id", "unknown")),
            email=userinfo.get("email"),
            name=userinfo.get("name"),  # Should be populated from userinfo
            roles=userinfo.get("roles", []),
            groups=userinfo.get("groups", []),
            provider=provider,
            tenant_id=tenant_id,
            expires_at=expires_at,
        )

    # ── 1. get_auth_url ──────────────────────

    async def get_auth_url(
        self,
        tenant_name: Optional[str] = None,
        app_name: Optional[str] = None,
        provider_name: Optional[str] = None,
        frontend_callback_url: Optional[str] = None,
        base_url: Optional[str] = None,
        **params,
    ) -> Tuple[str, str]:
        try:
            if self.config.mode == OAuthMode.STANDALONE:
                t = tenant_name or self.config.default_tenant_name
                a = app_name or self.config.default_app_name
                p = provider_name or self.config.default_provider_name
                if not t or not a or not p:
                    raise OAuthError(
                        "STANDALONE: tenant_name, app_name, provider_name required. "
                        "Set defaults in OAuthConfig."
                    )
                idp = await self._resolve_idp_config(t, a, p)

                verifier, challenge = _pkce_pair()

                allowed_scopes = idp.get("allowed_scopes", ["openid", "profile", "email"])
                scope_str = " ".join(allowed_scopes)

                redirect_uri = _select_redirect_uri(idp.get("redirect_uris", []), base_url)
                if not redirect_uri:
                    raise OAuthError(f"Provider '{p}' missing redirect_uri config.")

                oauth_client = self._need_oauth(idp["client_id"], idp["client_secret"], redirect_uri=redirect_uri, scope=scope_str)

                auth_params = {"code_challenge": challenge, "code_challenge_method": "S256", **params}

                issuer_lower = idp.get("issuer_url", "").lower()
                if "google" in issuer_lower or "googleapis" in issuer_lower:
                    auth_params["access_type"] = "offline"
                    auth_params["prompt"] = "consent"

                url, state = oauth_client.create_authorization_url(
                    idp["authorize_url"],
                    **auth_params,
                )
                logger.info("[get_auth_url] generated URL = %s", url)
                now = time.time()
                oauth_state = OAuthState(
                    state=state,
                    tenant_id=idp["tenant_id"],
                    app_id=idp["app_id"],
                    provider_id=idp["provider_id"],
                    tenant_name=t,
                    app_name=a,
                    provider_name=p,
                    redirect_uri=redirect_uri,
                    code_verifier=verifier,
                    created_at=now,
                    expires_at=now + 600,
                    frontend_callback_url=frontend_callback_url,
                )
                await self._state_store.save_state(oauth_state)
            else:
                # PLATFORM: delegate using business names
                r = await self._need_platform().post(
                    "/api/v1/auth/url",
                    json={
                        "tenant_name": tenant_name,
                        "app_name": app_name,
                        "provider_name": provider_name,
                        **params,
                    },
                )
                r.raise_for_status()
                data = r.json()
                url = data["auth_url"]
                state = data["state"]
                redirect_uri = data.get("redirect_uri")
                now = time.time()
                oauth_state = OAuthState(
                    state=state,
                    tenant_name=tenant_name,
                    app_name=app_name,
                    provider_name=provider_name,
                    redirect_uri=redirect_uri,
                    created_at=now,
                    expires_at=now + 600,
                    frontend_callback_url=frontend_callback_url,
                )
                await self._state_store.save_state(oauth_state)

            return url, state

        except OAuthError:
            raise
        except Exception as exc:
            raise OAuthError(f"get_auth_url failed: {exc}", provider=provider_name)

    # ── 2. do_login ──────────────────────────

    async def do_login(self, auth_code: str, state: str, **params) -> OAuthResult:
        try:
            saved = await self._state_store.get_and_delete_state(state)
            if not saved:
                raise OAuthError("Invalid or expired OAuth state", error_code="INVALID_STATE")

            t_name = saved.tenant_name
            a_name = saved.app_name
            p_name = saved.provider_name

            if self.config.mode == OAuthMode.STANDALONE:
                idp = await self._resolve_idp_config(t_name, a_name, p_name)
                client_id = idp["client_id"]
                client_secret = idp["client_secret"]
                redirect_uri = saved.redirect_uri or _select_redirect_uri(idp.get("redirect_uris", []), None)
                if not redirect_uri:
                    raise OAuthError(f"Provider '{p_name}' missing redirect_uri config.")

                logger.info(
                    "[do_login] token exchange → client_id=%s secret=%s...%s redirect_uri=%s has_verifier=%s",
                    client_id,
                    (client_secret or "")[:4],
                    (client_secret or "")[-4:],
                    redirect_uri,
                    bool(saved.code_verifier),
                )
                oauth_client = self._need_oauth(client_id, client_secret, redirect_uri=redirect_uri)
                fetch_kwargs: Dict[str, Any] = {
                    "url": idp["token_url"],
                    "code": auth_code,
                    "redirect_uri": redirect_uri,
                }
                if saved.code_verifier:
                    fetch_kwargs["code_verifier"] = saved.code_verifier
                try:
                    token = await oauth_client.fetch_token(**fetch_kwargs)
                    logger.info(
                        "[do_login] IDP token response keys: %s, has_refresh_token=%s",
                        list(token.keys()),
                        "refresh_token" in token
                    )
                except Exception as _fetch_exc:
                    _resp = getattr(_fetch_exc, "response", None)
                    if _resp is not None:
                        logger.error(
                            "[do_login] raw IDP error body: %s",
                            _resp.text if hasattr(_resp, "text") else _resp.content,
                        )
                        logger.error("[do_login] IDP response headers: %s", getattr(_resp, "headers", {}))
                    else:
                        logger.error("[do_login] fetch_token exception: %r", _fetch_exc)
                        # Fallback: direct POST to see Google's raw JSON error
                        import httpx
                        async with httpx.AsyncClient() as client:
                            resp = await client.post(
                                idp["token_url"],
                                data={
                                    "grant_type": "authorization_code",
                                    "code": auth_code,
                                    "redirect_uri": redirect_uri,
                                    "client_id": client_id,
                                    "client_secret": client_secret,
                                    **({"code_verifier": saved.code_verifier} if saved.code_verifier else {}),
                                },
                            )
                            logger.error("[do_login] fallback direct POST status=%s body=%s", resp.status_code, resp.text)
                    raise
            else:
                r = await self._need_platform().post(
                    "/api/v1/auth/token",
                    json={
                        "code": auth_code,  # Schema expects 'code', not 'auth_code'
                        "state": state,
                        "tenant_name": t_name,
                        "app_name": a_name,
                        "provider_name": p_name,
                        "redirect_uri": getattr(self.config, "redirect_uri", None),
                        **params,
                    },
                )
                r.raise_for_status()
                data = r.json()
                return OAuthResult(
                    jwt_token=data["jwt_token"],
                    refresh_token=data.get("refresh_token"),
                    session_id=data["session_id"],
                    user_id=data.get("user_id", "unknown"),
                    email=data.get("email"),
                    name=data.get("name"),
                    provider=data.get("provider", p_name),
                    tenant_id=data.get("tenant_id"),
                    expires_at=data.get("expires_at"),
                )

            # STANDALONE: fetch userinfo, create session, sign JWT locally
            userinfo = await self._fetch_userinfo(token["access_token"], userinfo_url=idp["userinfo_url"])
            id_token_claims: Dict[str, Any] = {}
            if token.get("id_token"):
                try:
                    import jwt as pyjwt
                    id_token_claims = pyjwt.decode(token["id_token"], options={"verify_signature": False})
                except Exception as e:
                    logger.warning("Failed to decode ID token: %s", e)
            merged_userinfo = {**id_token_claims, **userinfo}
            user_id = merged_userinfo.get("sub", merged_userinfo.get("id", "unknown"))
            now = time.time()
            returned_scope = token.get("scope")
            if not returned_scope:
                allowed_scopes = idp.get("allowed_scopes", ["openid", "profile", "email"])
                returned_scope = " ".join(allowed_scopes)

            idp_tokens = {
                "access_token": token["access_token"],
                "refresh_token": token.get("refresh_token"),
                "id_token": token.get("id_token"),
                "token_type": token.get("token_type", "Bearer"),
                "expires_in": token.get("expires_in", 3600),
                "expires_at": now + token.get("expires_in", 3600),
                "scope": returned_scope,
            }
            # JIT user provisioning
            user_mgmt = UserManagement(self._db)
            internal_user_id = await user_mgmt.upsert_user_on_login(
                tenant_id=idp["tenant_id"],
                provider_id=idp["provider_id"],
                external_user_id=user_id,
                email=merged_userinfo.get("email"),
                first_name=merged_userinfo.get("given_name"),
                last_name=merged_userinfo.get("family_name"),
                display_name=merged_userinfo.get("name"),
                idp_attributes=merged_userinfo,
            )
            logger.info(f"JIT provisioned user: internal_id={internal_user_id}, email={merged_userinfo.get('email')}")

            groups = await user_mgmt.get_user_groups(idp["tenant_id"], internal_user_id)
            group_names = [g.group_name for g in groups]
            roles = await user_mgmt.get_user_roles(idp["tenant_id"], internal_user_id)
            role_names = [r.role_name for r in roles]

            # Initialize auth_engine BEFORE using it (fixes bug where it was used at line 492 before init at 525)
            auth_engine = AuthorizationEngine(self._db)

            # Fetch user scopes via group-scope mappings and auto-select first scope if available
            scope_names = []
            active_scope_id = None
            active_scope_name = None
            try:
                scope_names = await self._get_user_scope_names(internal_user_id, idp["tenant_id"])
                logger.info(f"Resolved {len(scope_names)} scopes for user {internal_user_id}")

                # Auto-select first scope if user has any scopes
                available_scopes = await auth_engine.get_user_available_scopes(
                    internal_user_id, idp["tenant_id"]
                )
                if available_scopes:
                    first_scope = available_scopes[0]
                    active_scope_id = first_scope["id"]
                    active_scope_name = first_scope["name"]
                    logger.info(f"Auto-selected first scope for user {internal_user_id}: scope_id={active_scope_id}, name={active_scope_name}")
            except Exception as e:
                logger.warning(f"Failed to resolve scopes and scope_roles for user {internal_user_id}: {e}")

            user_attributes = {
                "email": merged_userinfo.get("email"),
                "name": merged_userinfo.get("name"),
                "groups": group_names,
                "internal_user_id": internal_user_id,
                "provider": p_name,
            }

            session = await self._db.create_session(
                app_id=idp["app_id"],
                provider_id=idp["provider_id"],
                tenant_id=idp["tenant_id"],
                user_id=internal_user_id,
                user_attributes=user_attributes,
                idp_tokens=idp_tokens,
                ttl_seconds=self.config.jwt_expiry_seconds,
                include_platform_tokens=False,
                active_scope_id=active_scope_id,
            )

            # Always compute fresh permissions on login — never serve stale cache
            self._clear_cache_for_user(internal_user_id)
            # Generate JWT (use helper which handles scoped vs global)
            jwt_token = await self._refresh_jwt_from_session(session)
            return self._build_result(
                jwt_token=jwt_token,
                session_id=session.session_id,
                userinfo=merged_userinfo,
                provider=p_name,
                tenant_id=idp["tenant_id"],
                expires_at=idp_tokens["expires_at"],
            )

        except OAuthError:
            raise
        except Exception as exc:
            raise OAuthError(f"do_login failed: {exc}", provider=p_name)

    def _get_perm_cache_key(self, user_id: int, tenant_id: int, app_id: int, scope_id: Optional[int]) -> str:
        """Generate cache key for permissions."""
        return f"{user_id}:{tenant_id}:{app_id}:{scope_id or 'global'}"

    def _get_cached_perms(self, cache_key: str) -> Optional[str]:
        """Retrieve cached permissions if not expired."""
        if cache_key in self._perm_cache:
            perms, expiry = self._perm_cache[cache_key]
            if time.time() < expiry:
                logger.debug(f"Permission cache hit for {cache_key}")
                return perms
            else:
                # Expired - remove from cache
                del self._perm_cache[cache_key]
        return None

    def _set_cached_perms(self, cache_key: str, perms: str) -> None:
        """Store permissions in cache with TTL."""
        expiry = time.time() + self._perm_cache_ttl
        self._perm_cache[cache_key] = (perms, expiry)
        logger.debug(f"Permission cached for {cache_key} (TTL: {self._perm_cache_ttl}s)")

    def _clear_cache_for_user(self, user_id: int) -> None:
        """Clear all cached permissions for a user (call after permission changes)."""
        keys_to_remove = [k for k in self._perm_cache.keys() if k.startswith(f"{user_id}:")]
        for key in keys_to_remove:
            del self._perm_cache[key]
        logger.info(f"Cleared {len(keys_to_remove)} cached permissions for user {user_id}")

    async def _get_user_scope_names(self, user_id: int, tenant_id: int) -> List[str]:
        """Fetch all scope names accessible to user via group-scope mappings."""
        try:
            from .rbac_management import GroupScopeManagement
            scope_mgmt = GroupScopeManagement(self._db)
            user_mgmt = UserManagement(self._db)
            groups = await user_mgmt.get_user_groups(tenant_id, user_id)
            scope_names = []
            for group in groups:
                group_scopes = await scope_mgmt.list_group_scopes(group.id)
                for gs in group_scopes:
                    scope = await scope_mgmt._db._need_pool().fetchrow(
                        "SELECT name FROM scopes WHERE id = $1", gs.scope_id
                    )
                    if scope:
                        scope_names.append(scope['name'])
            return sorted(list(set(scope_names)))
        except Exception as e:
            logger.warning(f"Failed to fetch scope names for user {user_id}: {e}")
            return []

    async def _refresh_jwt_from_session(self, session: "SessionRecord") -> str:
        """Generate fresh JWT for session with current scope context from session.active_scope_id."""
        from .authorization import AuthorizationEngine
        from .rbac_utilities import rbac_policy_get_scoped_user_role_ids
        auth_engine = AuthorizationEngine(self._db)
        user_mgmt = UserManagement(self._db)
        tenant = await self._db.get_tenant(session.tenant_id)
        app = await self._db.get_app(session.app_id)
        provider = await self._db.get_provider(session.provider_id)
        user = await user_mgmt.get_user_by_id(session.tenant_id, session.user_id)
        roles = await user_mgmt.get_user_roles(session.tenant_id, session.user_id)
        groups = await user_mgmt.get_user_groups(session.tenant_id, session.user_id)
        role_names = [r.role_name for r in roles]
        group_names = [g.group_name for g in groups]
        scope_names = await self._get_user_scope_names(session.user_id, session.tenant_id)
        available_scopes = await auth_engine.get_user_available_scopes(session.user_id, session.tenant_id)

        # Handle scope deletion: validate active_scope_id still exists
        active_scope_id = session.active_scope_id
        if active_scope_id is not None:
            scope_exists = any(s["id"] == active_scope_id for s in available_scopes)
            if not scope_exists:
                # Scope was deleted - auto-fallback to first available scope
                logger.warning(
                    f"Scope {active_scope_id} not found for user {session.user_id}. "
                    f"Auto-switching to first available scope."
                )
                if available_scopes:
                    active_scope_id = available_scopes[0]["id"]
                    # Update session to new scope
                    pool = self._db._need_pool()
                    async with pool.acquire() as conn:
                        await conn.execute(
                            "UPDATE sessions SET active_scope_id = $1 WHERE id = $2",
                            active_scope_id, session.session_id
                        )
                else:
                    # No scopes available - fallback to global
                    logger.warning(f"User {session.user_id} has no scopes available. Switching to global.")
                    active_scope_id = None

        scope_uuid = None
        entity_level = None
        if active_scope_id is not None:
            scoped_role_ids = await rbac_policy_get_scoped_user_role_ids(
                self._db, session.user_id, session.tenant_id, active_scope_id
            )
            pool = self._db._need_pool()
            async with pool.acquire() as conn:
                role_rows = await conn.fetch(
                    "SELECT name FROM roles WHERE id = ANY($1::int[]) AND is_active = TRUE",
                    list(scoped_role_ids)
                )
            role_names = [r['name'] for r in role_rows]
            scope_info = next((s for s in available_scopes if s["id"] == active_scope_id), None)
            scope_name = scope_info["name"] if scope_info else None
            scope_uuid = scope_info.get("uuid") if scope_info else None
            entity_level = scope_info.get("entity_level") if scope_info else None

            # Try to get permissions from cache first
            cache_key = self._get_perm_cache_key(
                session.user_id, session.tenant_id, session.app_id, active_scope_id
            )
            perms = self._get_cached_perms(cache_key)
            if not perms:
                perms = await auth_engine.get_user_scoped_resource_group_permissions(
                    session.user_id, session.tenant_id, session.app_id, active_scope_id
                )
                self._set_cached_perms(cache_key, perms)
        else:
            scope_name = None
            # Try to get global permissions from cache first
            cache_key = self._get_perm_cache_key(
                session.user_id, session.tenant_id, session.app_id, None
            )
            perms = self._get_cached_perms(cache_key)
            if not perms:
                perms = await auth_engine.get_user_resource_group_permissions(
                    session.user_id, session.tenant_id, session.app_id
                )
                self._set_cached_perms(cache_key, perms)
        return self._jwt.wrap(
            provider=session.user_attributes.get("provider", "password"),
            user_id=str(session.user_id),
            session_id=session.session_id,
            email=session.user_attributes.get("email"),
            name=session.user_attributes.get("name"),
            roles=role_names,
            scopes=scope_names,
            groups=group_names,
            tenant_id=session.tenant_id,
            tenant_uuid=tenant.uuid if tenant else None,
            app_id=session.app_id,
            app_uuid=app.uuid if app else None,
            provider_id=session.provider_id,
            provider_uuid=provider.uuid if provider else None,
            user_uuid=user.uuid if user else None,
            perms=perms,
            active_scope_id=active_scope_id,
            active_scope_name=scope_name,
            active_scope_uuid=scope_uuid,
            entity_level=entity_level,
        )

    # ── 3. do_logout ─────────────────────────

    async def do_logout(self, jwt_token: str, **params) -> bool:
        try:
            claims = self._jwt.decode_claims(jwt_token)
            session_id = claims.get("session_id")

            if self.config.mode == OAuthMode.STANDALONE:
                if not session_id:
                    raise OAuthError("No session_id in JWT claims")
                session = await self._db.get_session(session_id)
                stored_idp = session.tokens.get("idp", {}) if session else {}
                if session and stored_idp.get("access_token"):
                    try:
                        provider_claim = claims.get("provider", "")
                        tenant_claim = claims.get("tenant_name") or ""
                        app_claim = claims.get("app_name") or ""
                        if tenant_claim and app_claim and provider_claim:
                            idp = await self._resolve_idp_config(tenant_claim, app_claim, provider_claim)
                            if idp.get("revoke_url"):
                                async with httpx.AsyncClient() as http_client:
                                    await http_client.post(
                                        idp["revoke_url"],
                                        data={
                                            "token": stored_idp["access_token"],
                                            "client_id": idp["client_id"],
                                            "client_secret": idp["client_secret"],
                                        },
                                    )
                    except Exception as exc:
                        logger.warning("Failed to revoke IDP tokens: %s", exc)
                await self._db.revoke_session(session_id)
            else:
                # PLATFORM mode: session-based revocation
                if not session_id:
                    raise OAuthError("No session_id in JWT claims")
                r = await self._need_platform().post(
                    "/api/v1/auth/revoke",
                    json={
                        "session_id": session_id,
                        **params,
                    },
                )
                r.raise_for_status()

            # Invalidate in-memory permission cache so re-login always gets fresh policies
            user_id_claim = claims.get("sub")
            if user_id_claim:
                try:
                    self._clear_cache_for_user(int(user_id_claim))
                except Exception:
                    pass

            return True

        except OAuthError:
            raise
        except Exception as exc:
            raise OAuthError(f"do_logout failed: {exc}")

    # ── 4. do_refresh ────────────────────────

    async def do_refresh(self, token: str, **params) -> OAuthResult:
        """
        Refresh tokens.

        Parameters
        ----------
        token : For STANDALONE mode: jwt_token (extracts session_id to retrieve stored IDP refresh_token)
                For PLATFORM mode: platform_refresh_token (opaque token sent to platform service)
        """
        claims: Dict[str, Any] = {}
        try:
            if self.config.mode == OAuthMode.STANDALONE:
                claims = self._jwt.decode_claims(token)
                session_id = claims.get("session_id")
                if not session_id:
                    raise OAuthError("No session_id in JWT claims")
                
                session = await self._db.get_session(session_id)
                stored_idp = session.tokens.get("idp", {}) if session else {}
                if not session:
                    raise OAuthError("Session not found")
                if session.is_revoked:
                    raise OAuthError("Session has been revoked")
                
                # Handle password-based sessions differently (no external OAuth provider)
                if claims.get("provider") == "password":
                    # Validate that refresh token exists
                    if not stored_idp or not stored_idp.get("refresh_token"):
                        raise OAuthError("No refresh token found for password-based session. Please login again.")
                    
                    # Check if refresh token has expired (90 days)
                    refresh_token_expires_at = stored_idp.get("expires_at", 0)
                    now = time.time()
                    if now > refresh_token_expires_at:
                        raise OAuthError("Refresh token has expired. Please login again.")
                    
                    # For password-based auth, regenerate JWT (helper handles scope context)
                    new_jwt = await self._refresh_jwt_from_session(session)

                    # Extract roles and groups from session for response
                    user_mgmt = UserManagement(self._db)
                    roles = await user_mgmt.get_user_roles(session.tenant_id, session.user_id)
                    groups = await user_mgmt.get_user_groups(session.tenant_id, session.user_id)
                    role_names = [r.role_name for r in roles]
                    group_names = [g.group_name for g in groups]

                    return OAuthResult(
                        jwt_token=new_jwt,
                        refresh_token=None,
                        session_id=session.session_id,
                        user_id=str(session.user_id),
                        email=session.user_attributes.get("email", ""),
                        name=session.user_attributes.get("name", ""),
                        roles=role_names,
                        groups=group_names,
                    )
                
                # OAuth-based sessions continue with normal flow
                if not stored_idp:
                    raise OAuthError("No IDP tokens stored")
                
                # Use integer IDs from JWT claims
                tenant_id = claims.get("tenant_id")
                app_id = claims.get("app_id")
                provider_id = claims.get("provider_id")
                p_name = claims.get("provider", "")
                
                if not all([tenant_id, app_id, provider_id]):
                    raise OAuthError("JWT missing required ID claims (tenant_id, app_id, provider_id)")
                
                # Query by IDs instead of names
                data = await self._db.get_app_with_provider_by_id(app_id, provider_id)
                if not data:
                    raise OAuthError("No active config for app_id/provider_id. Session may be corrupted.")
                
                # Extract IDP config from database result
                idp = data.get("idp_config", {})
                if not idp.get("authorize_url") or not idp.get("token_url"):
                    raise OAuthError(f"Provider '{p_name}' missing endpoint config. Re-run seed script.")
                
                oauth_client = self._need_oauth(idp["client_id"], idp["client_secret"], redirect_uri=idp["redirect_uris"][0] if idp.get("redirect_uris") else "")
                new_token = await oauth_client.fetch_token(
                    idp["token_url"],
                    grant_type="refresh_token",
                    refresh_token=stored_idp["refresh_token"],
                )
                userinfo = await self._fetch_userinfo(new_token["access_token"], userinfo_url=idp["userinfo_url"])
                id_token_claims: Dict[str, Any] = {}
                if new_token.get("id_token"):
                    try:
                        import jwt as pyjwt
                        id_token_claims = pyjwt.decode(new_token["id_token"], options={"verify_signature": False})
                    except Exception as exc:
                        logger.warning("Failed to decode ID token during refresh: %s", exc)
                merged = {**id_token_claims, **userinfo}
                if not merged.get("name"):
                    merged["name"] = claims.get("name")
                now = time.time()
                updated_idp = {
                    "access_token": new_token["access_token"],
                    "refresh_token": new_token.get("refresh_token", stored_idp["refresh_token"]),
                    "id_token": new_token.get("id_token"),
                    "token_type": new_token.get("token_type", "Bearer"),
                    "expires_in": new_token.get("expires_in", 3600),
                    "expires_at": now + new_token.get("expires_in", 3600),
                    "scope": new_token.get("scope", stored_idp.get("scope")),
                }
                await self._db.update_session_tokens(session_id=session_id, idp_tokens=updated_idp)

                # Regenerate JWT (helper handles scope context)
                new_jwt = await self._refresh_jwt_from_session(session)
                return self._build_result(
                    jwt_token=new_jwt,
                    session_id=session_id,
                    userinfo=merged,
                    provider=p_name,
                    tenant_id=session.tenant_id,
                    expires_at=updated_idp["expires_at"],
                )
            else:
                # PLATFORM: token is platform_refresh_token (opaque)
                r = await self._need_platform().post(
                    "/api/v1/auth/refresh",
                    json={"platform_refresh_token": token, **params},
                )
                r.raise_for_status()
                data = r.json()
                return OAuthResult(
                    jwt_token=data["jwt_token"],
                    refresh_token=data.get("refresh_token"),
                    session_id=data["session_id"],
                    user_id=data.get("user_id", "unknown"),
                    email=data.get("email"),
                    name=data.get("name"),
                    provider=data.get("provider", ""),
                    tenant_id=data.get("tenant_id"),
                    expires_at=data.get("expires_at"),
                )

        except OAuthError:
            raise
        except Exception as exc:
            raise OAuthError(f"do_refresh failed: {exc}", provider=claims.get("provider", "unknown"))

    # ── 5. get_idp_access_token ──────────────

    async def get_idp_access_token(self, jwt_token: str) -> str:
        """
        Get the IDP access token for making API calls to Microsoft Graph, Google APIs, etc.
        
        STANDALONE mode: Retrieves from session, auto-refreshes if expired.
        PLATFORM mode: Not supported (use platform service endpoints).
        
        Parameters
        ----------
        jwt_token : Current JWT token (contains session_id for lookup).
        
        Returns
        -------
        str : IDP access_token for calling IDP APIs.
        """
        if self.config.mode != OAuthMode.STANDALONE:
            raise OAuthError("get_idp_access_token only supported in STANDALONE mode")
        
        # Extract session_id from JWT
        claims = self._jwt.decode_claims(jwt_token)
        session_id = claims.get("session_id")
        if not session_id:
            raise OAuthError("No session_id in JWT claims")
        
        session = await self._db.get_session(session_id)
        stored_idp = session.tokens.get("idp", {}) if session else {}
        if not session or not stored_idp:
            raise OAuthError("Session not found or no IDP tokens stored")
        if session.is_revoked:
            raise OAuthError("Session has been revoked")
        now = time.time()
        if now >= stored_idp.get("expires_at", 0) - 60:
            logger.info("IDP access_token expiring, refreshing...")
            await self.do_refresh(jwt_token)
            session = await self._db.get_session(session_id)
            stored_idp = session.tokens.get("idp", {}) if session else {}
        return stored_idp["access_token"]

    # ── 6. get_user_profile ──────────────────

    async def get_user_profile(self, jwt_token: str) -> Dict[str, Any]:
        """
        Return user profile from JWT claims (PLATFORM mode uses /auth/userinfo).
        IDP tokens are no longer in the JWT, so we use the JWT claims directly
        or call the platform service's userinfo proxy.
        """
        try:
            if self.config.mode == OAuthMode.PLATFORM:
                r = await self._need_platform().get(
                    "/api/v1/auth/userinfo",
                    headers={"Authorization": f"Bearer {jwt_token}"},
                )
                r.raise_for_status()
                return r.json()
            else:
                claims = self._jwt.decode_claims(jwt_token)
                return {
                    "sub": claims.get("sub"),
                    "email": claims.get("email"),
                    "name": claims.get("name"),
                    "roles": claims.get("roles", []),
                    "groups": claims.get("groups", []),
                    "provider": claims.get("provider"),
                    "tenant_id": claims.get("tenant_id"),
                }
        except OAuthError:
            raise
        except Exception as exc:
            raise OAuthError(f"get_user_profile failed: {exc}")
