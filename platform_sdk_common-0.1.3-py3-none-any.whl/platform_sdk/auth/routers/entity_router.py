"""
Generic scope entity CRUD router (N-level hierarchy).

Replaces hardcoded system_router, organization_router, project_router with
a single generic entity endpoint that works for any number of hierarchy levels.
"""

from typing import Optional, List
from fastapi import APIRouter, HTTPException, Depends

from ..interfaces import (
    ScopeEntityRecord,
    ScopeEntityCreate,
    ScopeEntityUpdate,
    ScopeEntityLevelRecord,
    EntityNode,
)
from ..business_entity_management import BusinessEntityManagement
from ..user_management import UserManagement
from ..rbac_management import ScopeManagement


def create_entity_router(
    db,
    auth_dep=None
) -> APIRouter:
    """
    Create entity management router.

    Args:
        db: AuthDatabase instance
        auth_dep: Authentication dependency (optional, used for checking permissions)

    Returns:
        APIRouter configured for entity operations
    """
    router = APIRouter(tags=["entity"])
    _db = db
    _auth_dep = auth_dep

    async def _enrich_entity_with_emails(entity: dict, tenant_id: int) -> dict:
        """Fetch user emails for created_by and updated_by."""
        enriched = dict(entity)
        user_mgmt = UserManagement(_db)

        if enriched.get('created_by'):
            try:
                user = await user_mgmt.get_user_by_id(tenant_id, enriched['created_by'])
                if user:
                    enriched['created_by_email'] = user.email
            except:
                pass

        if enriched.get('updated_by'):
            try:
                user = await user_mgmt.get_user_by_id(tenant_id, enriched['updated_by'])
                if user:
                    enriched['updated_by_email'] = user.email
            except:
                pass

        return enriched

    @router.get("/entity-levels", response_model=List[ScopeEntityLevelRecord])
    async def get_entity_levels(claims: dict = Depends(_auth_dep)):
        """Get all configured scope entity levels for the user's tenant."""
        if not _db:
            raise HTTPException(500, "Entity management requires database")

        tenant_id = int(claims.get("tenant_id"))
        em = BusinessEntityManagement(_db)
        levels = await em.list_levels(tenant_id)
        return levels

    @router.get("/entities", response_model=List[dict])
    async def list_entities(
        entity_uuid: Optional[str] = None,
        level_name: Optional[str] = None,
        claims: dict = Depends(_auth_dep)
    ):
        """
        Return the given entity + all its descendants as a flat list.
        If level_name is provided, only items at that level are included.
        Fields: id, uuid, name, level_name, created_at, updated_at,
                created_by_email, updated_by_email.
        """
        if not _db:
            raise HTTPException(500, "Entity management requires database")
        if not entity_uuid:
            raise HTTPException(400, "entity_uuid is required")

        tenant_id = int(claims.get("tenant_id"))
        em = BusinessEntityManagement(_db)

        entity = await em.get_entity_by_uuid(entity_uuid)
        if not entity:
            raise HTTPException(404, f"Entity '{entity_uuid}' not found")

        descendants = await em.list_children(entity["id"], recursive=True)
        all_items = [entity] + descendants

        if level_name:
            all_items = [i for i in all_items if i.get('level_name') == level_name]

        def _slim(e: dict, email_map: dict) -> dict:
            return {
                'id': e.get('id'),
                'uuid': e.get('uuid'),
                'name': e.get('name'),
                'level_name': e.get('level_name'),
                'created_at': e.get('created_at'),
                'updated_at': e.get('updated_at'),
                'created_by_email': email_map.get(e.get('created_by')),
                'updated_by_email': email_map.get(e.get('updated_by')),
            }

        # Collect all unique user IDs and batch-fetch emails
        user_ids = {
            uid for i in all_items
            for uid in (i.get('created_by'), i.get('updated_by'))
            if uid
        }
        user_mgmt = UserManagement(_db)
        email_map: dict = {}
        for uid in user_ids:
            try:
                user = await user_mgmt.get_user_by_id(tenant_id, uid)
                if user:
                    email_map[uid] = user.email
            except:
                pass

        return [_slim(i, email_map) for i in all_items]

    @router.get("/entities/{entity_uuid}", response_model=dict)
    async def get_entity(
        entity_uuid: str,
        claims: dict = Depends(_auth_dep)
    ):
        """Get a single entity by UUID."""
        if not _db:
            raise HTTPException(500, "Entity management requires database")

        tenant_id = int(claims.get("tenant_id"))
        em = BusinessEntityManagement(_db)
        entity = await em.get_entity_by_uuid(entity_uuid)
        if not entity:
            raise HTTPException(404, f"Entity '{entity_uuid}' not found")

        enriched_entity = await _enrich_entity_with_emails(entity, tenant_id)
        # Fetch parent name if parent_id exists
        if enriched_entity.get('parent_id'):
            parent = await em.get_entity_by_id(enriched_entity['parent_id'])
            if parent:
                enriched_entity['parent_name'] = parent['name']
                enriched_entity['parent_uuid'] = parent['uuid']

        # Return both IDs and human-readable names
        clean_entity = {
            'id': enriched_entity.get('id'),
            'uuid': enriched_entity.get('uuid'),
            'name': enriched_entity.get('name'),
            'level_name': enriched_entity.get('level_name'),
            'parent_id': enriched_entity.get('parent_id'),
            'parent_uuid': enriched_entity.get('parent_uuid'),
            'parent_name': enriched_entity.get('parent_name'),
            'description': enriched_entity.get('description'),
            'metadata': enriched_entity.get('metadata'),
            'is_active': enriched_entity.get('is_active'),
            'created_at': enriched_entity.get('created_at'),
            'updated_at': enriched_entity.get('updated_at'),
            'created_by': enriched_entity.get('created_by'),
            'updated_by': enriched_entity.get('updated_by'),
            'created_by_email': enriched_entity.get('created_by_email'),
            'updated_by_email': enriched_entity.get('updated_by_email'),
        }
        return clean_entity

    @router.get("/entities/{entity_uuid}/children", response_model=List[dict])
    async def get_entity_children(
        entity_uuid: str,
        recursive: bool = False,
        claims: dict = Depends(_auth_dep)
    ):
        """Get direct children (or entire subtree if recursive=true)."""
        if not _db:
            raise HTTPException(500, "Entity management requires database")

        tenant_id = int(claims.get("tenant_id"))
        em = BusinessEntityManagement(_db)
        entity = await em.get_entity_by_uuid(entity_uuid)
        if not entity:
            raise HTTPException(404, f"Entity '{entity_uuid}' not found")

        children = await em.list_children(entity["id"], recursive=recursive)

        enriched = []
        for child in children:
            enriched_child = await _enrich_entity_with_emails(child, tenant_id)
            enriched.append(enriched_child)
        return enriched

    @router.get("/entities/{entity_uuid}/parent-chain", response_model=List[dict])
    async def get_entity_parent_chain(
        entity_uuid: str,
        claims: dict = Depends(_auth_dep)
    ):
        """Get all ancestors (parents, grandparents, ...) from root to immediate parent."""
        if not _db:
            raise HTTPException(500, "Entity management requires database")

        em = BusinessEntityManagement(_db)
        entity = await em.get_entity_by_uuid(entity_uuid)
        if not entity:
            raise HTTPException(404, f"Entity '{entity_uuid}' not found")

        parent_chain = await em.get_parent_chain(entity["id"])
        return parent_chain

    @router.post("/entities", response_model=dict)
    async def create_entity(
        req: ScopeEntityCreate,
        claims: dict = Depends(_auth_dep)
    ):
        """Create a new scope entity."""
        if not _db:
            raise HTTPException(500, "Entity management requires database")

        tenant_id = int(claims.get("tenant_id"))
        em = BusinessEntityManagement(_db)
        scope_mgmt = ScopeManagement(_db)

        try:
            created_by = None
            if claims.get("sub"):
                try:
                    created_by = int(claims.get("sub"))
                except (ValueError, TypeError):
                    pass  # If can't convert, leave as None

            # Pre-flight: check if a scope with this name already exists
            existing_scope = await scope_mgmt.get_scope_by_name(tenant_id, req.name)
            if existing_scope:
                raise HTTPException(409, f"A scope named '{req.name}' already exists in this tenant")

            entity = await em.create_entity(
                tenant_id=tenant_id,
                name=req.name,
                level_name=req.level_name,
                parent_uuid=req.parent_uuid,
                description=req.description,
                metadata=req.metadata,
                created_by=created_by
            )

            # Auto-create scope for this entity
            try:
                await scope_mgmt.create_scope(
                    tenant_id=tenant_id,
                    name=entity['name'],
                    entity_id=entity['id'],
                    description=entity.get('description'),
                    created_by=created_by,
                )
            except Exception as scope_err:
                # Log the error but don't fail entity creation
                import logging
                logging.error(f"Failed to create scope for entity {entity['id']}: {str(scope_err)}")

            return entity
        except HTTPException:
            raise
        except ValueError as e:
            raise HTTPException(400, str(e))
        except Exception as e:
            raise HTTPException(500, f"Failed to create entity: {str(e)}")

    @router.put("/entities/{entity_uuid}", response_model=dict)
    async def update_entity(
        entity_uuid: str,
        req: ScopeEntityUpdate,
        claims: dict = Depends(_auth_dep)
    ):
        """Update an entity."""
        if not _db:
            raise HTTPException(500, "Entity management requires database")

        tenant_id = int(claims.get("tenant_id"))
        em = BusinessEntityManagement(_db)
        scope_mgmt = ScopeManagement(_db)
        entity = await em.get_entity_by_uuid(entity_uuid)
        if not entity:
            raise HTTPException(404, f"Entity '{entity_uuid}' not found")

        updated_by = None
        if claims.get("sub"):
            try:
                updated_by = int(claims.get("sub"))
            except (ValueError, TypeError):
                pass  # If can't convert, leave as None

        updated = await em.update_entity(
            entity["id"],
            name=req.name,
            description=req.description,
            metadata=req.metadata,
            updated_by=updated_by
        )
        if not updated:
            raise HTTPException(500, "Failed to update entity")

        # Cascade rename to linked scope if entity name changed
        if req.name:
            scope = await scope_mgmt.get_scope_by_entity_id(updated['id'])
            if scope:
                # Check new name isn't taken by a different scope
                conflict = await scope_mgmt.get_scope_by_name(tenant_id, req.name)
                if conflict and conflict.id != scope.id:
                    raise HTTPException(409, f"A scope named '{req.name}' already exists in this tenant")
                try:
                    await scope_mgmt.update_scope(scope_id=scope.id, name=req.name, updated_by=updated_by)
                except Exception as scope_err:
                    import logging
                    logging.error(f"Failed to rename scope {scope.id}: {str(scope_err)}")

        return updated

    @router.delete("/entities/{entity_uuid}")
    async def delete_entity(
        entity_uuid: str,
        claims: dict = Depends(_auth_dep)
    ):
        """Delete (soft-delete) an entity."""
        if not _db:
            raise HTTPException(500, "Entity management requires database")

        em = BusinessEntityManagement(_db)
        scope_mgmt = ScopeManagement(_db)
        entity = await em.get_entity_by_uuid(entity_uuid)
        if not entity:
            raise HTTPException(404, f"Entity '{entity_uuid}' not found")

        # Cascade delete: hard-delete linked scope first (DB cascades to group_scopes automatically)
        scope = await scope_mgmt.get_scope_by_entity_id(entity["id"])
        if scope:
            try:
                await scope_mgmt.delete_scope(scope.id)
            except Exception as scope_err:
                import logging
                logging.error(f"Failed to delete scope {scope.id}: {str(scope_err)}")

        # Then soft-delete entity
        success = await em.delete_entity(entity["id"])
        if not success:
            raise HTTPException(500, "Failed to delete entity")
        return {"message": f"Entity '{entity_uuid}' deleted"}

    return router
