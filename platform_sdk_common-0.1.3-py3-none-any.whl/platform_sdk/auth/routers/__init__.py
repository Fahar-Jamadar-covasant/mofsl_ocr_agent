"""
Modular routers for authentication and user management.

Available routers:
- create_auth_router: OAuth login, callback, logout, refresh, profile, scope/context
- create_users_router: User CRUD operations
- create_groups_router: Group CRUD operations with scope assignment endpoints
- create_roles_router: Role CRUD operations
- create_user_assignments_router: User-group and group-role assignments
- create_app_providers_router: App-provider relationship management
- create_sessions_router: Session management for tenant admins
- create_rbac_resources_router: RBAC resource management
- create_rbac_policies_router: RBAC policy management
- create_rbac_analytics_router: RBAC analytics and reporting
- create_rbac_scopes_router: RBAC scope CRUD management
- create_entity_router: Generic scope entity CRUD (N-level hierarchy, replaces system/org/project routers)
"""

from .auth_router import create_auth_router
from .users_router import create_users_router
from .groups_router import create_groups_router
from .roles_router import create_roles_router
from .user_assignments_router import create_user_assignments_router
from .app_providers_router import create_app_providers_router
from .sessions_router import create_sessions_router
from .rbac_resources_router import create_rbac_resources_router
from .rbac_policies_router import create_rbac_policies_router
from .rbac_analytics_router import create_rbac_analytics_router
from .rbac_scopes_router import create_rbac_scopes_router
from .entity_router import create_entity_router

__all__ = [
    "create_auth_router",
    "create_users_router",
    "create_groups_router",
    "create_roles_router",
    "create_user_assignments_router",
    "create_app_providers_router",
    "create_sessions_router",
    "create_rbac_resources_router",
    "create_rbac_policies_router",
    "create_rbac_analytics_router",
    "create_rbac_scopes_router",
    "create_entity_router",
]
