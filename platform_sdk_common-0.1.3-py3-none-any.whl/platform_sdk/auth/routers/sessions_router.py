"""
Session management endpoints for tenant administrators.

Provides operations for:
- List active sessions in tenant
- Revoke specific sessions
- Bulk revoke user sessions

Supports both STANDALONE and PLATFORM modes with proper delegation.
"""

from typing import List, Optional, Dict, Any
import httpx
from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel

from ..database import AuthDatabase
from ..interfaces import (
    SessionRecord,
    OAuthConfig,
    OAuthMode,
)


class EnhancedSessionRecord(BaseModel):
    session_id: str
    tenant_name: str
    app_name: str
    provider_name: str
    user_id: int
    user_attributes: Dict[str, Any]
    tokens: Dict[str, Any]
    issued_at: str
    expires_at: str
    is_revoked: bool
    created_at: str
    updated_at: str
    created_by_email: str
    updated_by_email: Optional[str]


def create_sessions_router(
    config: OAuthConfig,
    db: Optional[AuthDatabase] = None,
    auth_dependency = None,
) -> APIRouter:
    """
    Create sessions router that works in both STANDALONE and PLATFORM modes.
    
    - STANDALONE mode: Uses database directly for session management
    - PLATFORM mode: Delegates to Platform Service via HTTP with updated endpoints
    """
    router = APIRouter(tags=["sessions"])
    
    if config.mode == OAuthMode.STANDALONE and db is None:
        raise ValueError("db (AuthDatabase) is required for STANDALONE mode")
    
    is_platform_mode = config.mode == OAuthMode.PLATFORM

    def _get_platform_client(claims: dict, timeout: float = 30.0):
        """Create httpx client with Authorization header for platform delegation."""
        return httpx.AsyncClient(
            base_url=config.platform_oauth_url.rstrip("/"),
            headers={"Authorization": f"Bearer {claims.get('_raw_token', '')}"},
            timeout=timeout
        )

    # Create default auth dependency if none provided
    if auth_dependency is None:
        from ..dependencies import require_auth
        auth_dependency = require_auth(config)

    def _rbac(resource_path: str, action: str):
        async def _dep(claims: dict = Depends(auth_dependency)):
            if is_platform_mode:
                return claims
            # For standalone mode, basic JWT validation is sufficient for now
            # Full RBAC can be added later if needed
            return claims
        return _dep
    
    # ──────────────────────────────────────────────
    # SESSION MANAGEMENT ENDPOINTS
    # ──────────────────────────────────────────────
    
    @router.get("/sessions")
    async def list_sessions(
        claims: dict = Depends(_rbac("/api/auth/sessions", "read")),
    ):
        """List all active sessions for current tenant."""
        tenant_id = claims.get("tenant_id")
        if not tenant_id:
            raise HTTPException(status_code=401, detail="tenant_id not found in JWT")
        
        if is_platform_mode:
            async with _get_platform_client(claims) as client:
                # Updated delegation URL to match platform service structure
                response = await client.get(
                    f"/api/v1/admin/tenants/{tenant_id}/sessions",
                )
                response.raise_for_status()
                return response.json()
        else:
            # STANDALONE mode: use local database
            if not db:
                raise HTTPException(
                    status_code=500,
                    detail="Database not configured for standalone mode"
                )
            
            sessions = await db.list_active_sessions(int(tenant_id))
            enhanced_sessions = await _enhance_sessions(sessions, db)
            return {"sessions": enhanced_sessions}
    
    @router.get("/sessions/{session_id}")
    async def get_session(
        session_id: str,
        claims: dict = Depends(_rbac("/api/auth/sessions/*", "read")),
    ):
        """Get details of a specific session."""
        tenant_id = claims.get("tenant_id")
        if not tenant_id:
            raise HTTPException(status_code=401, detail="tenant_id not found in JWT")
        
        if is_platform_mode:
            async with _get_platform_client(claims) as client:
                # Updated delegation URL to match platform service structure
                response = await client.get(
                    f"/api/v1/admin/tenants/{tenant_id}/sessions/{session_id}",
                )
                if response.status_code == 404:
                    raise HTTPException(status_code=404, detail="Session not found or does not belong to this tenant")
                response.raise_for_status()
                return response.json()
        else:
            # STANDALONE mode: use local database
            if not db:
                raise HTTPException(
                    status_code=500,
                    detail="Database not configured for standalone mode"
                )
            
            session = await db.get_session(session_id)
            if not session or session.tenant_id != int(tenant_id):
                raise HTTPException(status_code=404, detail="Session not found or does not belong to this tenant")
            
            enhanced_session = await _enhance_session(session, db)
            return {"session": enhanced_session}
    
    @router.post("/sessions/{session_id}/revoke", status_code=200)
    async def revoke_session(
        session_id: str,
        claims: dict = Depends(_rbac("/api/auth/sessions/*", "delete")),
    ):
        """Revoke a specific session by ID."""
        tenant_id = claims.get("tenant_id")
        if not tenant_id:
            raise HTTPException(status_code=401, detail="tenant_id not found in JWT")
        
        if is_platform_mode:
            async with _get_platform_client(claims) as client:
                # Updated delegation URL to match platform service structure
                response = await client.post(
                    f"/api/v1/admin/tenants/{tenant_id}/sessions/{session_id}/revoke",
                )
                if response.status_code == 404:
                    raise HTTPException(status_code=404, detail="Session not found or does not belong to this tenant")
                response.raise_for_status()
                return response.json()
        else:
            # STANDALONE mode: use local database
            if not db:
                raise HTTPException(
                    status_code=500,
                    detail="Database not configured for standalone mode"
                )
            
            # Validate session belongs to tenant
            session = await db.get_session(session_id)
            if not session or session.tenant_id != int(tenant_id):
                raise HTTPException(status_code=404, detail="Session not found or does not belong to this tenant")
            
            actor_id = claims.get("sub")
            success = await db.revoke_session(
                session_id,
                updated_by=int(actor_id) if actor_id else None
            )
            
            if not success:
                raise HTTPException(status_code=404, detail="Session not found or already revoked")
            
            return {"success": True, "message": "Session revoked successfully"}
    
    @router.post("/sessions/revoke-user", status_code=200)
    async def revoke_user_sessions(
        user_id: str,
        claims: dict = Depends(_rbac("/api/auth/sessions", "delete")),
    ):
        """Revoke all sessions for a specific user in current tenant."""
        tenant_id = claims.get("tenant_id")
        if not tenant_id:
            raise HTTPException(status_code=401, detail="tenant_id not found in JWT")
        
        if is_platform_mode:
            async with _get_platform_client(claims) as client:
                # Updated delegation URL to match platform service structure
                response = await client.post(
                    f"/api/v1/admin/tenants/{tenant_id}/sessions/revoke-user",
                    json={"user_id": user_id}
                )
                response.raise_for_status()
                return response.json()
        else:
            # STANDALONE mode: use local database
            if not db:
                raise HTTPException(
                    status_code=500,
                    detail="Database not configured for standalone mode"
                )
            
            actor_id = claims.get("sub")
            revoked_count = await db.revoke_user_sessions(
                user_id,
                int(tenant_id),
                updated_by=int(actor_id) if actor_id else None
            )
            
            return {
                "success": True,
                "message": f"Revoked {revoked_count} sessions for user {user_id}",
                "revoked_count": revoked_count
            }

    # Helper functions for session enhancement
    async def _enhance_sessions(sessions: List[SessionRecord], db: AuthDatabase) -> List[EnhancedSessionRecord]:
        """Enhance sessions with names instead of IDs and proper timestamps."""
        enhanced = []
        for session in sessions:
            enhanced_session = await _enhance_session(session, db)
            enhanced.append(enhanced_session)
        return enhanced

    async def _enhance_session(session: SessionRecord, db: AuthDatabase) -> EnhancedSessionRecord:
        """Enhance a single session with names instead of IDs and proper timestamps."""
        pool = db._need_pool()
        async with pool.acquire() as conn:
            # Get names for all IDs
            names = await conn.fetchrow("""
                SELECT
                    t.tenant_name,
                    a.name as app_name,
                    p.provider_name,
                    creator.email as created_by_email,
                    updater.email as updated_by_email
                FROM tenants t
                JOIN apps a ON a.id = $2
                JOIN providers p ON p.id = $3
                LEFT JOIN users creator ON creator.id = $4
                LEFT JOIN users updater ON updater.id = $5
                WHERE t.id = $1
            """, session.tenant_id, session.app_id, session.provider_id, session.created_by, session.updated_by)

            return EnhancedSessionRecord(
                session_id=session.session_id,
                tenant_name=names['tenant_name'] if names else 'Unknown',
                app_name=names['app_name'] if names else 'Unknown',
                provider_name=names['provider_name'] if names else 'Unknown',
                user_id=session.user_id,
                user_attributes=session.user_attributes,
                tokens=session.tokens,
                issued_at=_format_timestamp(session.issued_at),
                expires_at=_format_timestamp(session.expires_at),
                is_revoked=session.is_revoked,
                created_at=session.created_at.isoformat() if session.created_at else '',
                updated_at=session.updated_at.isoformat() if session.updated_at else '',
                created_by_email=names['created_by_email'] if names and names['created_by_email'] else 'System',
                updated_by_email=names['updated_by_email'] if names and names['updated_by_email'] else None
            )

    def _format_timestamp(timestamp: float) -> str:
        """Convert Unix timestamp to ISO format."""
        import datetime
        return datetime.datetime.fromtimestamp(timestamp, tz=datetime.timezone.utc).isoformat()

    return router
