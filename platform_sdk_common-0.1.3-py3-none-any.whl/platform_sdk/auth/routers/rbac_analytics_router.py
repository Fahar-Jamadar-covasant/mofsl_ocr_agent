"""
RBAC Analytics and Reporting endpoints.

Provides comprehensive views of RBAC configuration including:
- Role details with policies, resource groups, and actions
- User-group-role assignments
- Group membership statistics
- User group-role mappings
"""

from typing import List, Optional, Dict, Any
from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel
from datetime import datetime, timezone

from ..database import AuthDatabase
from ..interfaces import OAuthConfig, OAuthMode


# Response Models
class PolicyDetail(BaseModel):
    """Detailed policy information with names instead of IDs."""
    policy_id: int
    role_name: str
    resource_group_name: Optional[str]
    resource_name: Optional[str]
    action_name: str
    is_allowed: bool
    metadata: Optional[Dict[str, Any]]


class RoleDetail(BaseModel):
    """Comprehensive role details with all policies."""
    role_id: int
    role_name: str
    role_description: Optional[str]
    policies: List[PolicyDetail]
    total_policies: int


class UserGroupRoleAssignment(BaseModel):
    """User's group and role assignments."""
    user_id: int
    email: str
    display_name: str
    groups: List[Dict[str, Any]]  # group_name, group_id, roles assigned to group


class GroupMemberStats(BaseModel):
    """Group membership statistics."""
    group_id: int
    group_name: str
    group_description: Optional[str]
    member_count: int
    is_default: bool


class UserGroupRoleMapping(BaseModel):
    """User's groups with their assigned roles."""
    user_id: int
    email: str
    display_name: str
    group_roles: List[Dict[str, Any]]  # group_name, role_names[]


class RoleAnalytics(BaseModel):
    """Role analytics with creator information."""
    role_id: int
    role_name: str
    description: Optional[str]
    is_active: bool
    created_at: str
    created_by_email: str
    updated_at: str
    updated_by_email: Optional[str]
    total_policies: int
    assigned_to_groups: int


class GroupAnalytics(BaseModel):
    """Group analytics with creator information."""
    group_id: int
    group_name: str
    description: Optional[str]
    is_active: bool
    is_default: bool
    parent_group_name: Optional[str]
    created_at: str
    created_by_email: str
    updated_at: str
    updated_by_email: Optional[str]
    member_count: int
    assigned_roles: List[str]


class ResourceAnalytics(BaseModel):
    """Resource analytics with creator information."""
    resource_id: int
    resource_name: str
    pattern: Optional[str]
    is_pattern: bool
    resource_group_name: Optional[str]
    is_active: bool
    created_at: str
    created_by_email: str
    updated_at: str
    updated_by_email: Optional[str]
    metadata: Optional[Dict[str, Any]]


class ResourceGroupAnalytics(BaseModel):
    """Resource group analytics with creator information."""
    resource_group_id: int
    resource_group_name: str
    display_name: Optional[str]
    description: Optional[str]
    is_active: bool
    created_at: str
    created_by_email: str
    updated_at: str
    updated_by_email: Optional[str]
    resource_count: int
    policy_count: int


class PolicyAnalytics(BaseModel):
    """Policy analytics with creator information."""
    policy_id: int
    role_name: str
    resource_group_name: Optional[str]
    resource_name: Optional[str]
    action_name: str
    is_allowed: bool
    created_at: str
    created_by_email: str
    metadata: Optional[Dict[str, Any]]


class ScopeAnalytics(BaseModel):
    """Scope analytics with creator information."""
    scope_id: int
    scope_name: str
    level_name: str
    description: Optional[str]
    is_active: bool
    created_at: str
    created_by_email: str
    updated_at: str
    updated_by_email: Optional[str]
    assigned_groups: int


class UserAnalytics(BaseModel):
    """Comprehensive user analytics with groups and roles."""
    user_id: int
    email: str
    display_name: str
    is_active: bool
    created_at: str
    created_by_email: str
    groups: List[Dict[str, Any]]  # group_name, assigned_at, assigned_by_email, roles[]
    total_groups: int
    total_roles: int


class GroupUserDetails(BaseModel):
    """User details within a group."""
    user_id: int
    email: str
    display_name: Optional[str]
    is_active: bool
    assigned_at: str
    assigned_by_email: str


class GroupWithUsersAnalytics(BaseModel):
    """Group details with all users in the group."""
    group_id: int
    group_name: str
    description: Optional[str]
    is_active: bool
    is_default: bool
    parent_group_name: Optional[str]
    created_at: str
    created_by_email: str
    updated_at: str
    updated_by_email: Optional[str]
    member_count: int
    assigned_roles: List[str]
    users: List[GroupUserDetails]


class RolePolicyDetails(BaseModel):
    """Policy details for a role."""
    policy_id: int
    resource_group_name: Optional[str]
    resource_name: Optional[str]
    action_name: str
    is_allowed: bool
    created_at: str
    created_by_email: str
    metadata: Optional[Dict[str, Any]]


class RoleDetailsAnalytics(BaseModel):
    """Comprehensive role details with all policies and groups."""
    role_id: int
    role_name: str
    description: Optional[str]
    is_active: bool
    created_at: str
    created_by_email: str
    updated_at: str
    updated_by_email: Optional[str]
    total_policies: int
    assigned_to_groups: int
    group_names: List[str]
    policies: List[RolePolicyDetails]


class ResourcePolicyDetails(BaseModel):
    """Policy details for a resource."""
    policy_id: int
    role_name: str
    action_name: str
    is_allowed: bool
    created_at: str
    created_by_email: str
    metadata: Optional[Dict[str, Any]]


class ResourceDetailsAnalytics(BaseModel):
    """Comprehensive resource details with all policies."""
    resource_id: int
    resource_name: str
    pattern: Optional[str]
    is_pattern: bool
    resource_group_id: int
    resource_group_name: str
    is_active: bool
    created_at: str
    created_by_email: str
    updated_at: str
    updated_by_email: Optional[str]
    metadata: Optional[Dict[str, Any]]
    total_policies: int
    policies: List[ResourcePolicyDetails]


class ResourceGroupPolicyDetails(BaseModel):
    """Policy details for a resource group."""
    policy_id: int
    role_name: str
    action_name: str
    is_allowed: bool
    created_at: str
    created_by_email: str
    metadata: Optional[Dict[str, Any]]


class ResourceGroupResourceDetails(BaseModel):
    """Resource details within a resource group."""
    resource_id: int
    resource_name: str
    pattern: Optional[str]
    is_pattern: bool
    is_active: bool
    created_at: str


class ResourceGroupDetailsAnalytics(BaseModel):
    """Comprehensive resource group details with resources and policies."""
    resource_group_id: int
    resource_group_name: str
    display_name: Optional[str]
    description: Optional[str]
    is_active: bool
    created_at: str
    created_by_email: str
    updated_at: str
    updated_by_email: Optional[str]
    metadata: Optional[Dict[str, Any]]
    resource_count: int
    policy_count: int
    resources: List[ResourceGroupResourceDetails]
    policies: List[ResourceGroupPolicyDetails]


class SessionAnalytics(BaseModel):
    """Session analytics with resolved names and formatted timestamps."""
    session_id: str
    tenant_name: str
    app_name: str
    provider_name: str
    user_id: int
    user_email: str
    user_display_name: Optional[str]
    user_attributes: Dict[str, Any]
    tokens: Dict[str, Any]
    issued_at: str
    expires_at: str
    is_revoked: bool
    created_at: str
    updated_at: str
    created_by_email: str
    updated_by_email: Optional[str]


class UserGroupDetail(BaseModel):
    """Detailed user group information."""
    group_id: int
    group_name: str
    description: Optional[str]
    is_default: bool
    parent_group_name: Optional[str]
    assigned_at: str
    assigned_by_email: str
    roles: List[str]


class UserGroupsAnalytics(BaseModel):
    """All groups a user belongs to with metadata."""
    user_id: int
    email: str
    display_name: Optional[str]
    groups: List[UserGroupDetail]
    total_groups: int


def create_rbac_analytics_router(
    config: OAuthConfig,
    db: Optional[AuthDatabase] = None,
    auth_dependency=None,
) -> APIRouter:
    """
    Create RBAC analytics router for comprehensive RBAC reporting.

    - STANDALONE mode: Uses db to access local database directly
    - PLATFORM mode: Not supported (returns 501)
    """
    router = APIRouter(tags=["rbac-analytics"])

    if config.mode == OAuthMode.STANDALONE and db is None:
        raise ValueError("db is required for STANDALONE mode")

    is_platform_mode = config.mode == OAuthMode.PLATFORM

    if auth_dependency is None:
        from ..dependencies import require_auth
        auth_dependency = require_auth(config)

    def _format_unix_timestamp(timestamp: float) -> str:
        return datetime.fromtimestamp(timestamp, tz=timezone.utc).isoformat()

    @router.get("/rbac/roles", response_model=List[RoleDetail])
    async def get_role_details(
        claims: dict = Depends(auth_dependency),
    ):
        """
        Get all roles with their policies, resource groups, and actions.
        Returns role names, resource group names, action names (not IDs).
        """
        if is_platform_mode:
            raise HTTPException(status_code=501, detail="RBAC analytics not supported in PLATFORM mode")

        tenant_id = claims.get("tenant_id")
        if not tenant_id:
            raise HTTPException(status_code=401, detail="tenant_id not found in JWT")

        pool = db._need_pool()
        async with pool.acquire() as conn:
            roles = await conn.fetch(
                """
                SELECT id, name, description
                FROM roles
                WHERE tenant_id = $1
                ORDER BY name
                """,
                tenant_id
            )

            result = []
            for role in roles:
                policies = await conn.fetch(
                    """
                    SELECT
                        p.id as policy_id,
                        r.name as role_name,
                        rg.name as resource_group_name,
                        res.name as resource_name,
                        a.name as action_name,
                        p.is_allowed,
                        p.metadata
                    FROM rbac_policies p
                    JOIN roles r ON r.id = p.role_id
                    LEFT JOIN resource_groups rg ON rg.id = p.resource_group_id
                    JOIN actions a ON a.id = p.action_id
                    LEFT JOIN resources res ON res.id = p.resource_id
                    WHERE p.role_id = $1 AND p.tenant_id = $2
                    ORDER BY rg.name, a.name
                    """,
                    role['id'],
                    tenant_id
                )

                policy_details = [
                    PolicyDetail(
                        policy_id=p['policy_id'],
                        role_name=p['role_name'],
                        resource_group_name=p['resource_group_name'],
                        resource_name=p['resource_name'],
                        action_name=p['action_name'],
                        is_allowed=p['is_allowed'],
                        metadata=p['metadata'] if isinstance(p['metadata'], dict) else {}
                    )
                    for p in policies
                ]

                result.append(RoleDetail(
                    role_id=role['id'],
                    role_name=role['name'],
                    role_description=role['description'],
                    policies=policy_details,
                    total_policies=len(policy_details)
                ))

            return result

    @router.get("/rbac/users/{user_id}/assignments", response_model=UserGroupRoleAssignment)
    async def get_user_group_role_assignments(
        user_id: int,
        claims: dict = Depends(auth_dependency),
    ):
        """
        Get user's groups and the roles assigned to those groups.
        Returns all names (not IDs).
        """
        if is_platform_mode:
            raise HTTPException(status_code=501, detail="RBAC analytics not supported in PLATFORM mode")

        tenant_id = claims.get("tenant_id")
        if not tenant_id:
            raise HTTPException(status_code=401, detail="tenant_id not found in JWT")

        pool = db._need_pool()
        async with pool.acquire() as conn:
            user = await conn.fetchrow(
                """
                SELECT id, email, display_name
                FROM users
                WHERE id = $1 AND tenant_id = $2
                """,
                user_id,
                tenant_id
            )

            if not user:
                raise HTTPException(status_code=404, detail=f"User {user_id} not found")

            groups_data = await conn.fetch(
                """
                SELECT DISTINCT
                    g.id as group_id,
                    g.name as group_name,
                    g.description as group_description,
                    r.id as role_id,
                    r.name as role_name,
                    r.description as role_description
                FROM user_groups ug
                JOIN u_groups g ON g.id = ug.group_id
                LEFT JOIN group_roles gr ON gr.group_id = g.id
                LEFT JOIN roles r ON r.id = gr.role_id
                WHERE ug.user_id = $1 AND ug.tenant_id = $2
                ORDER BY g.name, r.name
                """,
                user_id,
                tenant_id
            )

            groups_dict = {}
            for row in groups_data:
                group_id = row['group_id']
                if group_id not in groups_dict:
                    groups_dict[group_id] = {
                        'group_id': group_id,
                        'group_name': row['group_name'],
                        'group_description': row['group_description'],
                        'roles': []
                    }

                if row['role_id']:
                    groups_dict[group_id]['roles'].append({
                        'role_id': row['role_id'],
                        'role_name': row['role_name'],
                        'role_description': row['role_description']
                    })

            return UserGroupRoleAssignment(
                user_id=user['id'],
                email=user['email'],
                display_name=user['display_name'],
                groups=list(groups_dict.values())
            )

    @router.get("/rbac/groups/stats", response_model=List[GroupMemberStats])
    async def get_group_member_statistics(
        claims: dict = Depends(auth_dependency),
    ):
        """Get statistics for all groups including member counts."""
        if is_platform_mode:
            raise HTTPException(status_code=501, detail="RBAC analytics not supported in PLATFORM mode")

        tenant_id = claims.get("tenant_id")
        if not tenant_id:
            raise HTTPException(status_code=401, detail="tenant_id not found in JWT")

        pool = db._need_pool()
        async with pool.acquire() as conn:
            groups = await conn.fetch(
                """
                SELECT
                    g.id,
                    g.name,
                    g.description,
                    g.is_default,
                    COUNT(ug.user_id) as member_count
                FROM u_groups g
                LEFT JOIN user_groups ug ON ug.group_id = g.id AND ug.tenant_id = g.tenant_id
                WHERE g.tenant_id = $1
                GROUP BY g.id, g.name, g.description, g.is_default
                ORDER BY g.name
                """,
                tenant_id
            )

            return [
                GroupMemberStats(
                    group_id=g['id'],
                    group_name=g['name'],
                    group_description=g['description'],
                    member_count=g['member_count'],
                    is_default=g['is_default']
                )
                for g in groups
            ]

    @router.get("/rbac/users/{user_id}/group-roles", response_model=UserGroupRoleMapping)
    async def get_user_group_role_mapping(
        user_id: int,
        claims: dict = Depends(auth_dependency),
    ):
        """Get user's groups with all roles assigned to each group."""
        if is_platform_mode:
            raise HTTPException(status_code=501, detail="RBAC analytics not supported in PLATFORM mode")

        tenant_id = claims.get("tenant_id")
        if not tenant_id:
            raise HTTPException(status_code=401, detail="tenant_id not found in JWT")

        pool = db._need_pool()
        async with pool.acquire() as conn:
            user = await conn.fetchrow(
                """
                SELECT id, email, display_name
                FROM users
                WHERE id = $1 AND tenant_id = $2
                """,
                user_id,
                tenant_id
            )

            if not user:
                raise HTTPException(status_code=404, detail=f"User {user_id} not found")

            groups_data = await conn.fetch(
                """
                SELECT DISTINCT
                    g.id as group_id,
                    g.name as group_name,
                    r.name as role_name
                FROM user_groups ug
                JOIN u_groups g ON g.id = ug.group_id
                LEFT JOIN group_roles gr ON gr.group_id = g.id
                LEFT JOIN roles r ON r.id = gr.role_id
                WHERE ug.user_id = $1 AND ug.tenant_id = $2
                ORDER BY g.name, r.name
                """,
                user_id,
                tenant_id
            )

            groups_dict = {}
            for row in groups_data:
                group_name = row['group_name']
                if group_name not in groups_dict:
                    groups_dict[group_name] = {
                        'group_id': row['group_id'],
                        'group_name': group_name,
                        'role_names': []
                    }

                if row['role_name']:
                    groups_dict[group_name]['role_names'].append(row['role_name'])

            return UserGroupRoleMapping(
                user_id=user['id'],
                email=user['email'],
                display_name=user['display_name'],
                group_roles=list(groups_dict.values())
            )

    # ========================================
    # COMPREHENSIVE ANALYTICS ENDPOINTS
    # ========================================

    @router.get("/analytics/roles", response_model=List[RoleAnalytics])
    async def get_roles_analytics(
        claims: dict = Depends(auth_dependency),
    ):
        """Get all roles with creator information and statistics."""
        if is_platform_mode:
            raise HTTPException(status_code=501, detail="RBAC analytics not supported in PLATFORM mode")

        tenant_id = claims.get("tenant_id")
        if not tenant_id:
            raise HTTPException(status_code=401, detail="tenant_id not found in JWT")

        pool = db._need_pool()
        async with pool.acquire() as conn:
            roles = await conn.fetch("""
                SELECT
                    r.id,
                    r.name,
                    r.description,
                    r.is_active,
                    r.created_at,
                    r.updated_at,
                    COALESCE(creator.email, 'System') as created_by_email,
                    COALESCE(updater.email, 'System') as updated_by_email,
                    COUNT(DISTINCT p.id) as total_policies,
                    COUNT(DISTINCT gr.group_id) as assigned_to_groups
                FROM roles r
                LEFT JOIN users creator ON creator.id = r.created_by
                LEFT JOIN users updater ON updater.id = r.updated_by
                LEFT JOIN rbac_policies p ON p.role_id = r.id
                LEFT JOIN group_roles gr ON gr.role_id = r.id
                WHERE r.tenant_id = $1
                GROUP BY r.id, r.name, r.description, r.is_active, r.created_at, r.updated_at, creator.email, updater.email
                ORDER BY r.name
            """, tenant_id)

            return [
                RoleAnalytics(
                    role_id=r['id'],
                    role_name=r['name'],
                    description=r['description'],
                    is_active=r['is_active'],
                    created_at=r['created_at'].isoformat(),
                    created_by_email=r['created_by_email'],
                    updated_at=r['updated_at'].isoformat(),
                    updated_by_email=r['updated_by_email'],
                    total_policies=r['total_policies'],
                    assigned_to_groups=r['assigned_to_groups']
                )
                for r in roles
            ]

    @router.get("/analytics/groups", response_model=List[GroupAnalytics])
    async def get_groups_analytics(
        claims: dict = Depends(auth_dependency),
    ):
        """Get all groups with creator information and statistics."""
        if is_platform_mode:
            raise HTTPException(status_code=501, detail="RBAC analytics not supported in PLATFORM mode")

        tenant_id = claims.get("tenant_id")
        if not tenant_id:
            raise HTTPException(status_code=401, detail="tenant_id not found in JWT")

        pool = db._need_pool()
        async with pool.acquire() as conn:
            groups = await conn.fetch("""
                SELECT
                    g.id,
                    g.name,
                    g.description,
                    g.is_active,
                    g.is_default,
                    g.created_at,
                    g.updated_at,
                    parent.name as parent_group_name,
                    COALESCE(creator.email, 'System') as created_by_email,
                    COALESCE(updater.email, 'System') as updated_by_email,
                    COUNT(DISTINCT ug.user_id) as member_count,
                    ARRAY_AGG(DISTINCT r.name) FILTER (WHERE r.name IS NOT NULL) as assigned_roles
                FROM u_groups g
                LEFT JOIN u_groups parent ON parent.id = g.parent_group_id
                LEFT JOIN users creator ON creator.id = g.created_by
                LEFT JOIN users updater ON updater.id = g.updated_by
                LEFT JOIN user_groups ug ON ug.group_id = g.id
                LEFT JOIN group_roles gr ON gr.group_id = g.id
                LEFT JOIN roles r ON r.id = gr.role_id
                WHERE g.tenant_id = $1
                GROUP BY g.id, g.name, g.description, g.is_active, g.is_default, g.created_at, g.updated_at, parent.name, creator.email, updater.email
                ORDER BY g.name
            """, tenant_id)

            return [
                GroupAnalytics(
                    group_id=g['id'],
                    group_name=g['name'],
                    description=g['description'],
                    is_active=g['is_active'],
                    is_default=g['is_default'],
                    parent_group_name=g['parent_group_name'],
                    created_at=g['created_at'].isoformat(),
                    created_by_email=g['created_by_email'],
                    updated_at=g['updated_at'].isoformat(),
                    updated_by_email=g['updated_by_email'],
                    member_count=g['member_count'],
                    assigned_roles=g['assigned_roles'] if g['assigned_roles'] else []
                )
                for g in groups
            ]

    @router.get("/analytics/resources", response_model=List[ResourceAnalytics])
    async def get_resources_analytics(
        claims: dict = Depends(auth_dependency),
    ):
        """Get all resources with creator information."""
        if is_platform_mode:
            raise HTTPException(status_code=501, detail="RBAC analytics not supported in PLATFORM mode")

        tenant_id = claims.get("tenant_id")
        if not tenant_id:
            raise HTTPException(status_code=401, detail="tenant_id not found in JWT")

        pool = db._need_pool()
        async with pool.acquire() as conn:
            resources = await conn.fetch("""
                SELECT
                    res.id,
                    res.name,
                    res.pattern,
                    res.is_pattern,
                    res.is_active,
                    res.created_at,
                    res.updated_at,
                    res.metadata,
                    rg.name as resource_group_name,
                    COALESCE(creator.email, 'System') as created_by_email,
                    COALESCE(updater.email, 'System') as updated_by_email
                FROM resources res
                JOIN apps a ON a.id = res.app_id
                LEFT JOIN resource_groups rg ON rg.id = res.resource_group_id
                LEFT JOIN users creator ON creator.id = res.created_by
                LEFT JOIN users updater ON updater.id = res.updated_by
                WHERE a.tenant_id = $1
                ORDER BY res.name
            """, tenant_id)

            return [
                ResourceAnalytics(
                    resource_id=r['id'],
                    resource_name=r['name'],
                    pattern=r['pattern'],
                    is_pattern=r['is_pattern'],
                    resource_group_name=r['resource_group_name'],
                    is_active=r['is_active'],
                    created_at=r['created_at'].isoformat(),
                    created_by_email=r['created_by_email'],
                    updated_at=r['updated_at'].isoformat(),
                    updated_by_email=r['updated_by_email'],
                    metadata=r['metadata'] if isinstance(r['metadata'], dict) else {}
                )
                for r in resources
            ]

    @router.get("/analytics/resource-groups", response_model=List[ResourceGroupAnalytics])
    async def get_resource_groups_analytics(
        claims: dict = Depends(auth_dependency),
    ):
        """Get all resource groups with creator information and statistics."""
        if is_platform_mode:
            raise HTTPException(status_code=501, detail="RBAC analytics not supported in PLATFORM mode")

        tenant_id = claims.get("tenant_id")
        if not tenant_id:
            raise HTTPException(status_code=401, detail="tenant_id not found in JWT")

        pool = db._need_pool()
        async with pool.acquire() as conn:
            resource_groups = await conn.fetch("""
                SELECT
                    rg.id,
                    rg.name,
                    rg.display_name,
                    rg.description,
                    rg.is_active,
                    rg.created_at,
                    rg.updated_at,
                    COALESCE(creator.email, 'System') as created_by_email,
                    COALESCE(updater.email, 'System') as updated_by_email,
                    COUNT(DISTINCT res.id) as resource_count,
                    COUNT(DISTINCT p.id) as policy_count
                FROM resource_groups rg
                JOIN apps a ON a.id = rg.app_id
                LEFT JOIN users creator ON creator.id = rg.created_by
                LEFT JOIN users updater ON updater.id = rg.updated_by
                LEFT JOIN resources res ON res.resource_group_id = rg.id
                LEFT JOIN rbac_policies p ON p.resource_group_id = rg.id
                WHERE a.tenant_id = $1
                GROUP BY rg.id, rg.name, rg.display_name, rg.description, rg.is_active, rg.created_at, rg.updated_at, creator.email, updater.email
                ORDER BY rg.name
            """, tenant_id)

            return [
                ResourceGroupAnalytics(
                    resource_group_id=rg['id'],
                    resource_group_name=rg['name'],
                    display_name=rg['display_name'],
                    description=rg['description'],
                    is_active=rg['is_active'],
                    created_at=rg['created_at'].isoformat(),
                    created_by_email=rg['created_by_email'],
                    updated_at=rg['updated_at'].isoformat(),
                    updated_by_email=rg['updated_by_email'],
                    resource_count=rg['resource_count'],
                    policy_count=rg['policy_count']
                )
                for rg in resource_groups
            ]

    @router.get("/analytics/policies", response_model=List[PolicyAnalytics])
    async def get_policies_analytics(
        claims: dict = Depends(auth_dependency),
    ):
        """Get all policies with creator information."""
        if is_platform_mode:
            raise HTTPException(status_code=501, detail="RBAC analytics not supported in PLATFORM mode")

        tenant_id = claims.get("tenant_id")
        if not tenant_id:
            raise HTTPException(status_code=401, detail="tenant_id not found in JWT")

        pool = db._need_pool()
        async with pool.acquire() as conn:
            policies = await conn.fetch("""
                SELECT
                    p.id,
                    p.is_allowed,
                    p.created_at,
                    p.metadata,
                    r.name as role_name,
                    rg.name as resource_group_name,
                    res.name as resource_name,
                    a.name as action_name,
                    COALESCE(creator.email, 'System') as created_by_email
                FROM rbac_policies p
                JOIN roles r ON r.id = p.role_id
                JOIN actions a ON a.id = p.action_id
                LEFT JOIN resource_groups rg ON rg.id = p.resource_group_id
                LEFT JOIN resources res ON res.id = p.resource_id
                LEFT JOIN users creator ON creator.id = p.created_by
                WHERE p.tenant_id = $1
                ORDER BY r.name, rg.name, res.name, a.name
            """, tenant_id)

            return [
                PolicyAnalytics(
                    policy_id=p['id'],
                    role_name=p['role_name'],
                    resource_group_name=p['resource_group_name'],
                    resource_name=p['resource_name'],
                    action_name=p['action_name'],
                    is_allowed=p['is_allowed'],
                    created_at=p['created_at'].isoformat(),
                    created_by_email=p['created_by_email'],
                    metadata=p['metadata'] if isinstance(p['metadata'], dict) else {}
                )
                for p in policies
            ]

    @router.get("/analytics/scopes", response_model=List[ScopeAnalytics])
    async def get_scopes_analytics(
        claims: dict = Depends(auth_dependency),
    ):
        """Get all scopes with creator information and group assignment counts."""
        if is_platform_mode:
            raise HTTPException(status_code=501, detail="RBAC analytics not supported in PLATFORM mode")

        tenant_id = claims.get("tenant_id")
        if not tenant_id:
            raise HTTPException(status_code=401, detail="tenant_id not found in JWT")

        pool = db._need_pool()
        async with pool.acquire() as conn:
            scopes = await conn.fetch("""
                SELECT
                    s.id,
                    s.name,
                    sel.name as level_name,
                    s.description,
                    s.is_active,
                    s.created_at,
                    s.updated_at,
                    COALESCE(creator.email, 'System') as created_by_email,
                    COALESCE(updater.email, 'System') as updated_by_email,
                    COUNT(DISTINCT gs.group_id) as assigned_groups
                FROM scopes s
                JOIN scope_entities se ON se.id = s.entity_id
                JOIN scope_entity_levels sel ON sel.id = se.level_id
                LEFT JOIN users creator ON creator.id = s.created_by
                LEFT JOIN users updater ON updater.id = s.updated_by
                LEFT JOIN group_scopes gs ON gs.scope_id = s.id AND gs.tenant_id = $1
                WHERE s.tenant_id = $1
                GROUP BY s.id, s.name, sel.name, s.description, s.is_active, s.created_at, s.updated_at, creator.email, updater.email
                ORDER BY sel.name, s.name
            """, tenant_id)

            return [
                ScopeAnalytics(
                    scope_id=s['id'],
                    scope_name=s['name'],
                    level_name=s['level_name'],
                    description=s['description'],
                    is_active=s['is_active'],
                    created_at=s['created_at'].isoformat(),
                    created_by_email=s['created_by_email'],
                    updated_at=s['updated_at'].isoformat(),
                    updated_by_email=s['updated_by_email'],
                    assigned_groups=s['assigned_groups']
                )
                for s in scopes
            ]

    @router.get("/analytics/users", response_model=List[UserAnalytics])
    async def get_users_analytics(
        claims: dict = Depends(auth_dependency),
    ):
        """Get all users with comprehensive group and role information."""
        if is_platform_mode:
            raise HTTPException(status_code=501, detail="RBAC analytics not supported in PLATFORM mode")

        tenant_id = claims.get("tenant_id")
        if not tenant_id:
            raise HTTPException(status_code=401, detail="tenant_id not found in JWT")

        pool = db._need_pool()
        async with pool.acquire() as conn:
            users = await conn.fetch("""
                SELECT
                    u.id,
                    u.email,
                    u.display_name,
                    u.is_active,
                    u.created_at,
                    COALESCE(creator.email, 'System') as created_by_email
                FROM users u
                LEFT JOIN users creator ON creator.id = u.created_by
                WHERE u.tenant_id = $1
                ORDER BY u.email
            """, tenant_id)

            result = []
            for user in users:
                group_data = await conn.fetch("""
                    SELECT
                        g.name as group_name,
                        ug.assigned_at as assigned_at,
                        COALESCE(assigner.email, 'System') as assigned_by_email,
                        ARRAY_AGG(DISTINCT r.name) FILTER (WHERE r.name IS NOT NULL) as roles
                    FROM user_groups ug
                    JOIN u_groups g ON g.id = ug.group_id
                    LEFT JOIN users assigner ON assigner.id = ug.assigned_by
                    LEFT JOIN group_roles gr ON gr.group_id = g.id
                    LEFT JOIN roles r ON r.id = gr.role_id
                    WHERE ug.user_id = $1 AND ug.tenant_id = $2
                    GROUP BY g.name, ug.assigned_at, assigner.email
                    ORDER BY g.name
                """, user['id'], tenant_id)

                groups = [
                    {
                        "group_name": gd['group_name'],
                        "assigned_at": gd['assigned_at'].isoformat(),
                        "assigned_by_email": gd['assigned_by_email'],
                        "roles": gd['roles'] if gd['roles'] else []
                    }
                    for gd in group_data
                ]

                all_roles = set()
                for g in groups:
                    all_roles.update(g['roles'])

                result.append(UserAnalytics(
                    user_id=user['id'],
                    email=user['email'],
                    display_name=user['display_name'],
                    is_active=user['is_active'],
                    created_at=user['created_at'].isoformat(),
                    created_by_email=user['created_by_email'],
                    groups=groups,
                    total_groups=len(groups),
                    total_roles=len(all_roles)
                ))

            return result

    @router.get("/analytics/my-groups", response_model=UserGroupsAnalytics)
    async def get_current_user_groups_analytics(
        claims: dict = Depends(auth_dependency),
    ):
        """Get all groups the current authenticated user belongs to, with roles and metadata."""
        if is_platform_mode:
            raise HTTPException(status_code=501, detail="RBAC analytics not supported in PLATFORM mode")

        tenant_id = claims.get("tenant_id")
        user_id = claims.get("sub")
        if not tenant_id or not user_id:
            raise HTTPException(status_code=401, detail="tenant_id and sub not found in JWT")

        pool = db._need_pool()
        async with pool.acquire() as conn:
            user = await conn.fetchrow(
                "SELECT id, email, display_name FROM users WHERE id = $1 AND tenant_id = $2",
                int(user_id) if isinstance(user_id, str) else user_id, tenant_id
            )
            if not user:
                raise HTTPException(status_code=404, detail=f"User {user_id} not found")

            groups_data = await conn.fetch("""
                SELECT
                    g.id               AS group_id,
                    g.name             AS group_name,
                    g.description,
                    g.is_default,
                    parent.name        AS parent_group_name,
                    ug.assigned_at,
                    COALESCE(assigner.email, 'System') AS assigned_by_email,
                    ARRAY_AGG(DISTINCT r.name) FILTER (WHERE r.name IS NOT NULL) AS roles
                FROM user_groups ug
                JOIN u_groups g        ON g.id = ug.group_id
                LEFT JOIN u_groups parent ON parent.id = g.parent_group_id
                LEFT JOIN users assigner  ON assigner.id = ug.assigned_by
                LEFT JOIN group_roles gr  ON gr.group_id = g.id
                LEFT JOIN roles r         ON r.id = gr.role_id AND r.is_active = TRUE
                WHERE ug.user_id = $1 AND ug.tenant_id = $2
                GROUP BY g.id, g.name, g.description, g.is_default,
                         parent.name, ug.assigned_at, assigner.email
                ORDER BY g.name
            """, int(user_id) if isinstance(user_id, str) else user_id, tenant_id)

        return UserGroupsAnalytics(
            user_id=user['id'],
            email=user['email'],
            display_name=user['display_name'],
            groups=[
                UserGroupDetail(
                    group_id=g['group_id'],
                    group_name=g['group_name'],
                    description=g['description'],
                    is_default=g['is_default'],
                    parent_group_name=g['parent_group_name'],
                    assigned_at=g['assigned_at'].isoformat(),
                    assigned_by_email=g['assigned_by_email'],
                    roles=g['roles'] if g['roles'] else [],
                )
                for g in groups_data
            ],
            total_groups=len(groups_data),
        )

    @router.get("/analytics/users/{user_id}/groups", response_model=UserGroupsAnalytics)
    async def get_user_groups_analytics(
        user_id: int,
        claims: dict = Depends(auth_dependency),
    ):
        """Get all groups a specific user belongs to, with roles and metadata."""
        if is_platform_mode:
            raise HTTPException(status_code=501, detail="RBAC analytics not supported in PLATFORM mode")

        tenant_id = claims.get("tenant_id")
        if not tenant_id:
            raise HTTPException(status_code=401, detail="tenant_id not found in JWT")

        pool = db._need_pool()
        async with pool.acquire() as conn:
            user = await conn.fetchrow(
                "SELECT id, email, display_name FROM users WHERE id = $1 AND tenant_id = $2",
                user_id, tenant_id
            )
            if not user:
                raise HTTPException(status_code=404, detail=f"User {user_id} not found")

            groups_data = await conn.fetch("""
                SELECT
                    g.id               AS group_id,
                    g.name             AS group_name,
                    g.description,
                    g.is_default,
                    parent.name        AS parent_group_name,
                    ug.assigned_at,
                    COALESCE(assigner.email, 'System') AS assigned_by_email,
                    ARRAY_AGG(DISTINCT r.name) FILTER (WHERE r.name IS NOT NULL) AS roles
                FROM user_groups ug
                JOIN u_groups g        ON g.id = ug.group_id
                LEFT JOIN u_groups parent ON parent.id = g.parent_group_id
                LEFT JOIN users assigner  ON assigner.id = ug.assigned_by
                LEFT JOIN group_roles gr  ON gr.group_id = g.id
                LEFT JOIN roles r         ON r.id = gr.role_id AND r.is_active = TRUE
                WHERE ug.user_id = $1 AND ug.tenant_id = $2
                GROUP BY g.id, g.name, g.description, g.is_default,
                         parent.name, ug.assigned_at, assigner.email
                ORDER BY g.name
            """, user_id, tenant_id)

        return UserGroupsAnalytics(
            user_id=user['id'],
            email=user['email'],
            display_name=user['display_name'],
            groups=[
                UserGroupDetail(
                    group_id=g['group_id'],
                    group_name=g['group_name'],
                    description=g['description'],
                    is_default=g['is_default'],
                    parent_group_name=g['parent_group_name'],
                    assigned_at=g['assigned_at'].isoformat(),
                    assigned_by_email=g['assigned_by_email'],
                    roles=g['roles'] if g['roles'] else [],
                )
                for g in groups_data
            ],
            total_groups=len(groups_data),
        )

    @router.get("/analytics/sessions", response_model=List[SessionAnalytics])
    async def get_sessions_analytics(
        claims: dict = Depends(auth_dependency),
    ):
        """Get all tenant sessions with resolved names and formatted timestamps."""
        if is_platform_mode:
            raise HTTPException(status_code=501, detail="RBAC analytics not supported in PLATFORM mode")

        tenant_id = claims.get("tenant_id")
        if not tenant_id:
            raise HTTPException(status_code=401, detail="tenant_id not found in JWT")

        pool = db._need_pool()
        async with pool.acquire() as conn:
            sessions = await conn.fetch(
                """
                SELECT
                    sess.id as session_id,
                    t.tenant_name,
                    a.app_name,
                    p.provider_name,
                    sess.user_id,
                    u.email as user_email,
                    u.display_name as user_display_name,
                    sess.user_attributes,
                    sess.tokens,
                    sess.issued_at,
                    sess.expires_at,
                    sess.is_revoked,
                    sess.created_at,
                    sess.updated_at,
                    COALESCE(creator.email, 'System') as created_by_email,
                    COALESCE(updater.email, 'System') as updated_by_email
                FROM sessions sess
                JOIN tenants t ON t.id = sess.tenant_id
                JOIN apps a ON a.id = sess.app_id
                JOIN providers p ON p.id = sess.provider_id
                JOIN users u ON u.id = sess.user_id
                LEFT JOIN users creator ON creator.id = sess.created_by
                LEFT JOIN users updater ON updater.id = sess.updated_by
                WHERE sess.tenant_id = $1
                ORDER BY sess.issued_at DESC
                """,
                tenant_id
            )

            return [
                SessionAnalytics(
                    session_id=row["session_id"],
                    tenant_name=row["tenant_name"],
                    app_name=row["app_name"],
                    provider_name=row["provider_name"],
                    user_id=row["user_id"],
                    user_email=row["user_email"],
                    user_display_name=row["user_display_name"],
                    user_attributes=row["user_attributes"] if isinstance(row["user_attributes"], dict) else {},
                    tokens=row["tokens"] if isinstance(row["tokens"], dict) else {},
                    issued_at=_format_unix_timestamp(row["issued_at"]),
                    expires_at=_format_unix_timestamp(row["expires_at"]),
                    is_revoked=row["is_revoked"],
                    created_at=row["created_at"].isoformat(),
                    updated_at=row["updated_at"].isoformat(),
                    created_by_email=row["created_by_email"],
                    updated_by_email=row["updated_by_email"]
                )
                for row in sessions
            ]

    @router.get("/analytics/groups-with-users", response_model=List[GroupWithUsersAnalytics])
    async def get_groups_with_users_analytics(
        claims: dict = Depends(auth_dependency),
    ):
        """Get all groups with their details and all users in each group."""
        if is_platform_mode:
            raise HTTPException(status_code=501, detail="RBAC analytics not supported in PLATFORM mode")

        tenant_id = claims.get("tenant_id")
        if not tenant_id:
            raise HTTPException(status_code=401, detail="tenant_id not found in JWT")

        pool = db._need_pool()
        async with pool.acquire() as conn:
            groups = await conn.fetch("""
                SELECT
                    g.id,
                    g.name,
                    g.description,
                    g.is_active,
                    g.is_default,
                    g.created_at,
                    g.updated_at,
                    COALESCE(creator.email, 'System') as created_by_email,
                    COALESCE(updater.email, 'System') as updated_by_email,
                    parent.name as parent_group_name,
                    ARRAY_AGG(DISTINCT r.name) FILTER (WHERE r.name IS NOT NULL) as assigned_roles
                FROM u_groups g
                LEFT JOIN users creator ON creator.id = g.created_by
                LEFT JOIN users updater ON updater.id = g.updated_by
                LEFT JOIN u_groups parent ON parent.id = g.parent_group_id
                LEFT JOIN group_roles gr ON gr.group_id = g.id
                LEFT JOIN roles r ON r.id = gr.role_id
                WHERE g.tenant_id = $1
                GROUP BY g.id, g.name, g.description, g.is_active, g.is_default,
                         g.created_at, g.updated_at, creator.email, updater.email, parent.name
                ORDER BY g.name
            """, tenant_id)

            result = []
            for group in groups:
                users = await conn.fetch("""
                    SELECT
                        u.id,
                        u.email,
                        u.display_name,
                        u.is_active,
                        ug.assigned_at,
                        COALESCE(assigner.email, 'System') as assigned_by_email
                    FROM user_groups ug
                    JOIN users u ON u.id = ug.user_id
                    LEFT JOIN users assigner ON assigner.id = ug.assigned_by
                    WHERE ug.group_id = $1 AND ug.tenant_id = $2
                    ORDER BY u.email
                """, group['id'], tenant_id)

                user_details = [
                    GroupUserDetails(
                        user_id=user['id'],
                        email=user['email'],
                        display_name=user['display_name'],
                        is_active=user['is_active'],
                        assigned_at=user['assigned_at'].isoformat(),
                        assigned_by_email=user['assigned_by_email']
                    )
                    for user in users
                ]

                result.append(GroupWithUsersAnalytics(
                    group_id=group['id'],
                    group_name=group['name'],
                    description=group['description'],
                    is_active=group['is_active'],
                    is_default=group['is_default'],
                    parent_group_name=group['parent_group_name'],
                    created_at=group['created_at'].isoformat(),
                    created_by_email=group['created_by_email'],
                    updated_at=group['updated_at'].isoformat(),
                    updated_by_email=group['updated_by_email'],
                    member_count=len(user_details),
                    assigned_roles=group['assigned_roles'] if group['assigned_roles'] else [],
                    users=user_details
                ))

            return result

    @router.get("/analytics/groups-with-users/{group_id}", response_model=GroupWithUsersAnalytics)
    async def get_group_with_users_analytics(
        group_id: int,
        claims: dict = Depends(auth_dependency),
    ):
        """Get specific group details with all users in the group by group ID."""
        if is_platform_mode:
            raise HTTPException(status_code=501, detail="RBAC analytics not supported in PLATFORM mode")

        tenant_id = claims.get("tenant_id")
        if not tenant_id:
            raise HTTPException(status_code=401, detail="tenant_id not found in JWT")

        pool = db._need_pool()
        async with pool.acquire() as conn:
            group = await conn.fetchrow("""
                SELECT
                    g.id,
                    g.name,
                    g.description,
                    g.is_active,
                    g.is_default,
                    g.created_at,
                    g.updated_at,
                    COALESCE(creator.email, 'System') as created_by_email,
                    COALESCE(updater.email, 'System') as updated_by_email,
                    parent.name as parent_group_name,
                    ARRAY_AGG(DISTINCT r.name) FILTER (WHERE r.name IS NOT NULL) as assigned_roles
                FROM u_groups g
                LEFT JOIN users creator ON creator.id = g.created_by
                LEFT JOIN users updater ON updater.id = g.updated_by
                LEFT JOIN u_groups parent ON parent.id = g.parent_group_id
                LEFT JOIN group_roles gr ON gr.group_id = g.id
                LEFT JOIN roles r ON r.id = gr.role_id
                WHERE g.id = $1 AND g.tenant_id = $2
                GROUP BY g.id, g.name, g.description, g.is_active, g.is_default,
                         g.created_at, g.updated_at, creator.email, updater.email, parent.name
            """, group_id, tenant_id)

            if not group:
                raise HTTPException(status_code=404, detail="Group not found")

            users = await conn.fetch("""
                SELECT
                    u.id,
                    u.email,
                    u.display_name,
                    u.is_active,
                    ug.assigned_at,
                    COALESCE(assigner.email, 'System') as assigned_by_email
                FROM user_groups ug
                JOIN users u ON u.id = ug.user_id
                LEFT JOIN users assigner ON assigner.id = ug.assigned_by
                WHERE ug.group_id = $1 AND ug.tenant_id = $2
                ORDER BY u.email
            """, group_id, tenant_id)

            user_details = [
                GroupUserDetails(
                    user_id=user['id'],
                    email=user['email'],
                    display_name=user['display_name'],
                    is_active=user['is_active'],
                    assigned_at=user['assigned_at'].isoformat(),
                    assigned_by_email=user['assigned_by_email']
                )
                for user in users
            ]

            return GroupWithUsersAnalytics(
                group_id=group['id'],
                group_name=group['name'],
                description=group['description'],
                is_active=group['is_active'],
                is_default=group['is_default'],
                parent_group_name=group['parent_group_name'],
                created_at=group['created_at'].isoformat(),
                created_by_email=group['created_by_email'],
                updated_at=group['updated_at'].isoformat(),
                updated_by_email=group['updated_by_email'],
                member_count=len(user_details),
                assigned_roles=group['assigned_roles'] if group['assigned_roles'] else [],
                users=user_details
            )

    @router.get("/analytics/roles/{role_id}", response_model=RoleDetailsAnalytics)
    async def get_role_details_analytics(
        role_id: int,
        claims: dict = Depends(auth_dependency),
    ):
        """Get comprehensive role details by role ID including policies and groups."""
        if is_platform_mode:
            raise HTTPException(status_code=501, detail="RBAC analytics not supported in PLATFORM mode")

        tenant_id = claims.get("tenant_id")
        if not tenant_id:
            raise HTTPException(status_code=401, detail="tenant_id not found in JWT")

        pool = db._need_pool()
        async with pool.acquire() as conn:
            role = await conn.fetchrow("""
                SELECT
                    r.id,
                    r.name,
                    r.description,
                    r.is_active,
                    r.created_at,
                    r.updated_at,
                    COALESCE(creator.email, 'System') as created_by_email,
                    COALESCE(updater.email, 'System') as updated_by_email,
                    COUNT(DISTINCT p.id) as total_policies,
                    COUNT(DISTINCT gr.group_id) as assigned_to_groups
                FROM roles r
                LEFT JOIN users creator ON creator.id = r.created_by
                LEFT JOIN users updater ON updater.id = r.updated_by
                LEFT JOIN rbac_policies p ON p.role_id = r.id
                LEFT JOIN group_roles gr ON gr.role_id = r.id
                WHERE r.id = $1 AND r.tenant_id = $2
                GROUP BY r.id, r.name, r.description, r.is_active, r.created_at, r.updated_at,
                         creator.email, updater.email
            """, role_id, tenant_id)

            if not role:
                raise HTTPException(status_code=404, detail="Role not found")

            groups = await conn.fetch("""
                SELECT g.name
                FROM group_roles gr
                JOIN u_groups g ON g.id = gr.group_id
                WHERE gr.role_id = $1 AND g.tenant_id = $2
                ORDER BY g.name
            """, role_id, tenant_id)

            group_names = [g['name'] for g in groups]

            policies = await conn.fetch("""
                SELECT
                    p.id as policy_id,
                    rg.name as resource_group_name,
                    res.name as resource_name,
                    a.name as action_name,
                    p.is_allowed,
                    p.created_at,
                    p.metadata,
                    COALESCE(creator.email, 'System') as created_by_email
                FROM rbac_policies p
                LEFT JOIN resource_groups rg ON rg.id = p.resource_group_id
                LEFT JOIN resources res ON res.id = p.resource_id
                JOIN actions a ON a.id = p.action_id
                LEFT JOIN users creator ON creator.id = p.created_by
                WHERE p.role_id = $1 AND p.tenant_id = $2
                ORDER BY rg.name, res.name, a.name
            """, role_id, tenant_id)

            policy_details = [
                RolePolicyDetails(
                    policy_id=pol['policy_id'],
                    resource_group_name=pol['resource_group_name'],
                    resource_name=pol['resource_name'],
                    action_name=pol['action_name'],
                    is_allowed=pol['is_allowed'],
                    created_at=pol['created_at'].isoformat(),
                    created_by_email=pol['created_by_email'],
                    metadata=pol['metadata']
                )
                for pol in policies
            ]

            return RoleDetailsAnalytics(
                role_id=role['id'],
                role_name=role['name'],
                description=role['description'],
                is_active=role['is_active'],
                created_at=role['created_at'].isoformat(),
                created_by_email=role['created_by_email'],
                updated_at=role['updated_at'].isoformat(),
                updated_by_email=role['updated_by_email'],
                total_policies=role['total_policies'],
                assigned_to_groups=role['assigned_to_groups'],
                group_names=group_names,
                policies=policy_details
            )

    @router.get("/analytics/resources/{resource_id}", response_model=ResourceDetailsAnalytics)
    async def get_resource_details_analytics(
        resource_id: int,
        claims: dict = Depends(auth_dependency),
    ):
        """Get comprehensive resource details by resource ID including policies."""
        if is_platform_mode:
            raise HTTPException(status_code=501, detail="RBAC analytics not supported in PLATFORM mode")

        tenant_id = claims.get("tenant_id")
        if not tenant_id:
            raise HTTPException(status_code=401, detail="tenant_id not found in JWT")

        pool = db._need_pool()
        async with pool.acquire() as conn:
            resource = await conn.fetchrow("""
                SELECT
                    res.id,
                    res.name,
                    res.pattern,
                    res.is_pattern,
                    res.resource_group_id,
                    rg.name as resource_group_name,
                    res.is_active,
                    res.created_at,
                    res.updated_at,
                    res.metadata,
                    COALESCE(creator.email, 'System') as created_by_email,
                    COALESCE(updater.email, 'System') as updated_by_email,
                    COUNT(DISTINCT p.id) as total_policies
                FROM resources res
                JOIN resource_groups rg ON rg.id = res.resource_group_id
                JOIN apps a ON a.id = res.app_id
                LEFT JOIN users creator ON creator.id = res.created_by
                LEFT JOIN users updater ON updater.id = res.updated_by
                LEFT JOIN rbac_policies p ON p.resource_id = res.id
                WHERE res.id = $1 AND a.tenant_id = $2
                GROUP BY res.id, res.name, res.pattern, res.is_pattern, res.resource_group_id,
                         rg.name, res.is_active, res.created_at, res.updated_at, res.metadata,
                         creator.email, updater.email
            """, resource_id, tenant_id)

            if not resource:
                raise HTTPException(status_code=404, detail="Resource not found")

            policies = await conn.fetch("""
                SELECT
                    p.id as policy_id,
                    r.name as role_name,
                    a.name as action_name,
                    p.is_allowed,
                    p.created_at,
                    p.metadata,
                    COALESCE(creator.email, 'System') as created_by_email
                FROM rbac_policies p
                JOIN roles r ON r.id = p.role_id
                JOIN actions a ON a.id = p.action_id
                LEFT JOIN users creator ON creator.id = p.created_by
                WHERE p.resource_id = $1 AND p.tenant_id = $2
                ORDER BY r.name, a.name
            """, resource_id, tenant_id)

            policy_details = [
                ResourcePolicyDetails(
                    policy_id=pol['policy_id'],
                    role_name=pol['role_name'],
                    action_name=pol['action_name'],
                    is_allowed=pol['is_allowed'],
                    created_at=pol['created_at'].isoformat(),
                    created_by_email=pol['created_by_email'],
                    metadata=pol['metadata']
                )
                for pol in policies
            ]

            return ResourceDetailsAnalytics(
                resource_id=resource['id'],
                resource_name=resource['name'],
                pattern=resource['pattern'],
                is_pattern=resource['is_pattern'],
                resource_group_id=resource['resource_group_id'],
                resource_group_name=resource['resource_group_name'],
                is_active=resource['is_active'],
                created_at=resource['created_at'].isoformat(),
                created_by_email=resource['created_by_email'],
                updated_at=resource['updated_at'].isoformat(),
                updated_by_email=resource['updated_by_email'],
                metadata=resource['metadata'],
                total_policies=resource['total_policies'],
                policies=policy_details
            )

    @router.get("/analytics/resource-groups/{resource_group_id}", response_model=ResourceGroupDetailsAnalytics)
    async def get_resource_group_details_analytics(
        resource_group_id: int,
        claims: dict = Depends(auth_dependency),
    ):
        """Get comprehensive resource group details including resources and policies."""
        if is_platform_mode:
            raise HTTPException(status_code=501, detail="RBAC analytics not supported in PLATFORM mode")

        tenant_id = claims.get("tenant_id")
        if not tenant_id:
            raise HTTPException(status_code=401, detail="tenant_id not found in JWT")

        pool = db._need_pool()
        async with pool.acquire() as conn:
            rg = await conn.fetchrow("""
                SELECT
                    rg.id,
                    rg.name,
                    rg.display_name,
                    rg.description,
                    rg.is_active,
                    rg.created_at,
                    rg.updated_at,
                    rg.metadata,
                    COALESCE(creator.email, 'System') as created_by_email,
                    COALESCE(updater.email, 'System') as updated_by_email,
                    COUNT(DISTINCT res.id) as resource_count,
                    COUNT(DISTINCT p.id) as policy_count
                FROM resource_groups rg
                JOIN apps a ON a.id = rg.app_id
                LEFT JOIN users creator ON creator.id = rg.created_by
                LEFT JOIN users updater ON updater.id = rg.updated_by
                LEFT JOIN resources res ON res.resource_group_id = rg.id
                LEFT JOIN rbac_policies p ON p.resource_group_id = rg.id
                WHERE rg.id = $1 AND a.tenant_id = $2
                GROUP BY rg.id, rg.name, rg.display_name, rg.description, rg.is_active,
                         rg.created_at, rg.updated_at, rg.metadata, creator.email, updater.email
            """, resource_group_id, tenant_id)

            if not rg:
                raise HTTPException(status_code=404, detail="Resource group not found")

            resources = await conn.fetch("""
                SELECT
                    res.id,
                    res.name,
                    res.pattern,
                    res.is_pattern,
                    res.is_active,
                    res.created_at
                FROM resources res
                WHERE res.resource_group_id = $1
                ORDER BY res.name
            """, resource_group_id)

            resource_details = [
                ResourceGroupResourceDetails(
                    resource_id=res['id'],
                    resource_name=res['name'],
                    pattern=res['pattern'],
                    is_pattern=res['is_pattern'],
                    is_active=res['is_active'],
                    created_at=res['created_at'].isoformat()
                )
                for res in resources
            ]

            policies = await conn.fetch("""
                SELECT
                    p.id as policy_id,
                    r.name as role_name,
                    a.name as action_name,
                    p.is_allowed,
                    p.created_at,
                    p.metadata,
                    COALESCE(creator.email, 'System') as created_by_email
                FROM rbac_policies p
                JOIN roles r ON r.id = p.role_id
                JOIN actions a ON a.id = p.action_id
                LEFT JOIN users creator ON creator.id = p.created_by
                WHERE p.resource_group_id = $1 AND p.tenant_id = $2
                ORDER BY r.name, a.name
            """, resource_group_id, tenant_id)

            policy_details = [
                ResourceGroupPolicyDetails(
                    policy_id=pol['policy_id'],
                    role_name=pol['role_name'],
                    action_name=pol['action_name'],
                    is_allowed=pol['is_allowed'],
                    created_at=pol['created_at'].isoformat(),
                    created_by_email=pol['created_by_email'],
                    metadata=pol['metadata']
                )
                for pol in policies
            ]

            return ResourceGroupDetailsAnalytics(
                resource_group_id=rg['id'],
                resource_group_name=rg['name'],
                display_name=rg['display_name'],
                description=rg['description'],
                is_active=rg['is_active'],
                created_at=rg['created_at'].isoformat(),
                created_by_email=rg['created_by_email'],
                updated_at=rg['updated_at'].isoformat(),
                updated_by_email=rg['updated_by_email'],
                metadata=rg['metadata'],
                resource_count=rg['resource_count'],
                policy_count=rg['policy_count'],
                resources=resource_details,
                policies=policy_details
            )

    return router
