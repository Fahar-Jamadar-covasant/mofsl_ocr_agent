

"""
User management endpoints.

Provides CRUD operations for users including:
- Create, read, update, deactivate users
- Get user identities (IdP links)
- Get user groups and roles
"""

from typing import List, Optional
import httpx
from fastapi import APIRouter, HTTPException, Query, Depends

from ..user_management import UserManagement, UserNotFoundError
from ..authorization import AuthorizationEngine
from ..interfaces import (
    UserRecord,
    UserCreateRequest,
    UserUpdateRequest,
    UserIdentityRecord,
    GroupRecord,
    RoleRecord,
    UserDetailsResponse,
    OAuthConfig,
    OAuthMode,
)


def create_users_router(
    config: OAuthConfig,
    user_mgmt: Optional[UserManagement] = None,
    auth_dependency = None,
) -> APIRouter:
    """
    Create users router that works in both STANDALONE and PLATFORM modes.
    
    - STANDALONE mode: Uses user_mgmt to access local database directly
    - PLATFORM mode: Delegates to Platform Service via HTTP
    """
    router = APIRouter(tags=["users"])
    
    # Validate configuration
    if config.mode == OAuthMode.STANDALONE and user_mgmt is None:
        raise ValueError("user_mgmt is required for STANDALONE mode")
    
    is_platform_mode = config.mode == OAuthMode.PLATFORM

    def _get_platform_client(claims: dict, timeout: float = 30.0):
        """Create httpx client with Authorization header for platform delegation."""
        return httpx.AsyncClient(
            base_url=config.platform_oauth_url.rstrip("/"),
            headers={"Authorization": f"Bearer {claims.get('_raw_token', '')}"},
            timeout=timeout
        )

    # Create default auth dependency if none provided
    if auth_dependency is None:
        from ..dependencies import require_auth
        auth_dependency = require_auth(config)

    auth_engine = AuthorizationEngine(user_mgmt._db) if not is_platform_mode and user_mgmt else None

    def _rbac(resource_path: str, action: str):
        async def _dep(claims: dict = Depends(auth_dependency)):
            if is_platform_mode:
                return claims

            user_id = claims.get("sub")
            tenant_id = claims.get("tenant_id")
            app_id = claims.get("app_id")
            if not all([user_id, tenant_id, app_id]):
                raise HTTPException(
                    status_code=403,
                    detail="Missing required claims in JWT (user_id, tenant_id, app_id)",
                )

            allowed, reason, policy = await auth_engine.can_user_perform(
                user_id=int(user_id) if isinstance(user_id, str) else user_id,
                tenant_id=int(tenant_id) if isinstance(tenant_id, str) else tenant_id,
                app_id=int(app_id) if isinstance(app_id, str) else app_id,
                resource_path=resource_path,
                action_name=action,
            )
            if not allowed:
                raise HTTPException(status_code=403, detail=f"Permission denied: {reason}")

            claims["_rbac_check"] = {
                "resource": resource_path,
                "action": action,
                "allowed": True,
                "reason": reason,
                "policy_id": policy.get("id") if policy else None,
            }
            return claims

        return _dep
    
    @router.post("/users", response_model=UserRecord, status_code=201)
    async def create_user(
        user: UserCreateRequest,
        claims: dict = Depends(_rbac("/api/auth/users", "create")),
    ):
        """Create a new user."""
        tenant_id = claims.get("tenant_id")
        actor_id = claims.get("sub")
        if not tenant_id:
            raise HTTPException(status_code=401, detail="tenant_id not found in JWT")
        if not actor_id:
            raise HTTPException(status_code=401, detail="User ID not found in JWT")
        
        if is_platform_mode:
            # PLATFORM mode: Delegate to Platform Service
            async with _get_platform_client(claims) as client:
                response = await client.post(
                    f"/api/v1/admin/tenants/{tenant_id}/users",
                    json=user.model_dump(),
                )
                response.raise_for_status()
                return UserRecord(**response.json())
        else:
            # STANDALONE mode: Direct database access
            try:
                # Check for duplicate email in tenant
                existing_user = await user_mgmt.get_user_by_email(int(tenant_id), user.email)
                if existing_user:
                    raise HTTPException(status_code=409, detail=f"A user with email '{user.email}' already exists")

                # If password is provided, hash it and create user with password
                if user.password:
                    from platform_sdk.auth.password_utils import hash_password
                    password_hash = hash_password(user.password)
                    return await user_mgmt.create_user_with_password(
                        tenant_id=tenant_id,
                        email=user.email,
                        password_hash=password_hash,
                        first_name=user.first_name,
                        last_name=user.last_name,
                        display_name=user.display_name,
                        is_active=user.is_active,
                        created_by=int(actor_id) if isinstance(actor_id, str) else actor_id,
                    )
                else:
                    # No password provided, create user without password (OAuth users)
                    return await user_mgmt.create_user(
                        tenant_id=tenant_id,
                        email=user.email,
                        first_name=user.first_name,
                        last_name=user.last_name,
                        display_name=user.display_name,
                        is_active=user.is_active,
                        created_by=int(actor_id) if isinstance(actor_id, str) else actor_id,
                    )
            except HTTPException:
                raise
            except Exception as exc:
                raise HTTPException(status_code=400, detail=str(exc))

    @router.get("/users/me", response_model=UserRecord)
    async def get_my_profile(
        claims: dict = Depends(_rbac("/api/auth/users/me", "read")),
    ):
        """Get current user's profile."""
        user_id = claims.get("sub")
        tenant_id = claims.get("tenant_id")
        
        if not user_id:
            raise HTTPException(status_code=401, detail="User ID not found in JWT")
        if not tenant_id:
            raise HTTPException(status_code=401, detail="Tenant ID not found in JWT")
        
        user_id = int(user_id) if isinstance(user_id, str) else user_id
        tenant_id = int(tenant_id) if isinstance(tenant_id, str) else tenant_id
        
        if is_platform_mode:
            async with _get_platform_client(claims) as client:
                response = await client.get(
                    f"/api/v1/admin/tenants/{tenant_id}/users/{user_id}",
                                    )
                if response.status_code == 404:
                    raise HTTPException(status_code=404, detail="User not found")
                response.raise_for_status()
                return UserRecord(**response.json())
        else:
            try:
                user = await user_mgmt.get_user_by_id(tenant_id, user_id)
                if not user:
                    raise HTTPException(status_code=404, detail="User not found")
                return user
            except UserNotFoundError as exc:
                raise HTTPException(status_code=404, detail=str(exc))

    @router.get("/users/{user_id}", response_model=UserRecord)
    async def get_user(
        user_id: int,
        claims: dict = Depends(_rbac("/api/auth/users/*", "read")),
    ):
        """Get user by ID."""
        tenant_id = claims.get("tenant_id")
        if not tenant_id:
            raise HTTPException(status_code=401, detail="tenant_id not found in JWT")
        
        if is_platform_mode:
            async with _get_platform_client(claims) as client:
                response = await client.get(
                    f"/api/v1/admin/tenants/{tenant_id}/users/{user_id}",
                                    )
                if response.status_code == 404:
                    raise HTTPException(status_code=404, detail=f"User {user_id} not found")
                response.raise_for_status()
                return UserRecord(**response.json())
        else:
            user = await user_mgmt.get_user_by_id(tenant_id, user_id)
            if not user:
                raise HTTPException(status_code=404, detail=f"User {user_id} not found")
            return user
    
    @router.get("/users/email/{email}", response_model=UserRecord)
    async def get_user_by_email(
        email: str,
        claims: dict = Depends(_rbac("/api/auth/users/*", "read")),
    ):
        """Get user by email."""
        tenant_id = claims.get("tenant_id")
        if not tenant_id:
            raise HTTPException(status_code=401, detail="tenant_id not found in JWT")
        user = await user_mgmt.get_user_by_email(tenant_id, email)
        if not user:
            raise HTTPException(status_code=404, detail=f"User with email {email} not found")
        return user
    
    @router.get("/users", response_model=List[dict])
    async def list_users(
        is_active: Optional[bool] = Query(None, description="Filter by active status"),
        limit: int = Query(100, ge=1, le=1000),
        offset: int = Query(0, ge=0),
        claims: dict = Depends(_rbac("/api/auth/users", "read")),
    ):
        """List users with their group memberships."""
        tenant_id = claims.get("tenant_id")
        if not tenant_id:
            raise HTTPException(status_code=401, detail="tenant_id not found in JWT")

        if is_platform_mode:
            params = {"limit": limit, "offset": offset}
            if is_active is not None:
                params["is_active"] = is_active
            async with _get_platform_client(claims) as client:
                response = await client.get(
                    f"/api/v1/admin/tenants/{tenant_id}/users",
                    params=params,
                )
                response.raise_for_status()
                return response.json()
        else:
            users = await user_mgmt.list_users(
                tenant_id=tenant_id,
                is_active=is_active,
                limit=limit,
                offset=offset
            )
            result = []
            for user in users:
                user_dict = user.model_dump(exclude={"password_hash"})
                try:
                    groups = await user_mgmt.get_user_groups(int(tenant_id), user.id)
                    user_dict["groups"] = [{"id": g.id, "group_name": g.group_name} for g in groups]
                except Exception:
                    user_dict["groups"] = []
                result.append(user_dict)
            return result
    
    @router.patch("/users/me", response_model=UserRecord)
    async def update_my_profile(
        update: UserUpdateRequest,
        claims: dict = Depends(_rbac("/api/auth/users/me", "update")),
    ):
        """Update current user's profile."""
        user_id = claims.get("sub")
        tenant_id = claims.get("tenant_id")
        actor_id = claims.get("sub")
        if not user_id or not tenant_id:
            raise HTTPException(status_code=401, detail="Missing required claims")
        if not actor_id:
            raise HTTPException(status_code=401, detail="User ID not found in JWT")
        
        user_id = int(user_id) if isinstance(user_id, str) else user_id
        tenant_id = int(tenant_id) if isinstance(tenant_id, str) else tenant_id
        actor_id = int(actor_id) if isinstance(actor_id, str) else actor_id
        
        if is_platform_mode:
            async with _get_platform_client(claims) as client:
                response = await client.patch(
                    f"/api/v1/admin/tenants/{tenant_id}/users/{user_id}",
                    json=update.model_dump(exclude_none=True),
                                    )
                if response.status_code == 404:
                    raise HTTPException(status_code=404, detail="User not found")
                response.raise_for_status()
                return UserRecord(**response.json())
        else:
            try:
                return await user_mgmt.update_user(
                    tenant_id=tenant_id,
                    user_id=user_id,
                    first_name=update.first_name,
                    last_name=update.last_name,
                    display_name=update.display_name,
                    is_active=update.is_active,
                    updated_by=int(actor_id) if isinstance(actor_id, str) else actor_id,
                )
            except UserNotFoundError as exc:
                raise HTTPException(status_code=404, detail=str(exc))

    @router.patch("/users/{user_id}", response_model=UserRecord)
    async def update_user(
        user_id: int,
        update: UserUpdateRequest,
        claims: dict = Depends(_rbac("/api/auth/users/*", "update")),
    ):
        """Update user."""
        tenant_id = claims.get("tenant_id")
        actor_id = claims.get("sub")
        if not tenant_id:
            raise HTTPException(status_code=401, detail="tenant_id not found in JWT")
        if not actor_id:
            raise HTTPException(status_code=401, detail="User ID not found in JWT")
        
        if is_platform_mode:
            async with _get_platform_client(claims) as client:
                response = await client.patch(
                    f"/api/v1/admin/tenants/{tenant_id}/users/{user_id}",
                    json=update.model_dump(exclude_none=True),
                                    )
                if response.status_code == 404:
                    raise HTTPException(status_code=404, detail=f"User {user_id} not found")
                response.raise_for_status()
                return UserRecord(**response.json())
        else:
            try:
                return await user_mgmt.update_user(
                    tenant_id=tenant_id,
                    user_id=user_id,
                    first_name=update.first_name,
                    last_name=update.last_name,
                    display_name=update.display_name,
                    is_active=update.is_active,
                    updated_by=int(actor_id) if isinstance(actor_id, str) else actor_id,
                )
            except UserNotFoundError as exc:
                raise HTTPException(status_code=404, detail=str(exc))
            except Exception as exc:
                raise HTTPException(status_code=400, detail=str(exc))
    
    @router.delete("/users/{user_id}", status_code=204)
    async def deactivate_user(
        user_id: int,
        claims: dict = Depends(_rbac("/api/auth/users/*", "delete")),
    ):
        """Deactivate user and revoke all sessions."""
        tenant_id = claims.get("tenant_id")
        actor_id = claims.get("sub")
        if not tenant_id:
            raise HTTPException(status_code=401, detail="tenant_id not found in JWT")
        if not actor_id:
            raise HTTPException(status_code=401, detail="User ID not found in JWT")
        
        if is_platform_mode:
            async with _get_platform_client(claims) as client:
                response = await client.delete(
                    f"/api/v1/admin/tenants/{tenant_id}/users/{user_id}",
                                    )
                if response.status_code == 404:
                    raise HTTPException(status_code=404, detail=f"User {user_id} not found")
                response.raise_for_status()
        else:
            try:
                await user_mgmt.deactivate_user(
                    tenant_id=tenant_id,
                    user_id=user_id,
                    updated_by=int(actor_id) if isinstance(actor_id, str) else actor_id,
                )
            except UserNotFoundError as exc:
                raise HTTPException(status_code=404, detail=str(exc))
    
    @router.get("/users/me/identities", response_model=List[UserIdentityRecord])
    async def get_my_identities(
        claims: dict = Depends(_rbac("/api/auth/users/me", "read")),
    ):
        """Get current user's IdP identities."""
        user_id = claims.get("sub")
        tenant_id = claims.get("tenant_id")
        
        if not user_id or not tenant_id:
            raise HTTPException(status_code=401, detail="Missing required claims")
        
        user_id = int(user_id) if isinstance(user_id, str) else user_id
        tenant_id = int(tenant_id) if isinstance(tenant_id, str) else tenant_id
        
        if is_platform_mode:
            async with _get_platform_client(claims) as client:
                response = await client.get(
                    f"/api/v1/admin/tenants/{tenant_id}/users/{user_id}/identities",
                                    )
                response.raise_for_status()
                return [UserIdentityRecord(**i) for i in response.json()]
        else:
            try:
                return await user_mgmt.get_user_identities(tenant_id, user_id)
            except UserNotFoundError as exc:
                raise HTTPException(status_code=404, detail=str(exc))

    @router.get("/users/{user_id}/identities", response_model=List[UserIdentityRecord])
    async def get_user_identities(
        user_id: int,
        claims: dict = Depends(_rbac("/api/auth/users/*", "read")),
    ):
        """Get all IdP identities for a user."""
        tenant_id = claims.get("tenant_id")
        if not tenant_id:
            raise HTTPException(status_code=401, detail="tenant_id not found in JWT")
        
        if is_platform_mode:
            async with _get_platform_client(claims) as client:
                response = await client.get(
                    f"/api/v1/admin/tenants/{tenant_id}/users/{user_id}/identities",
                                    )
                if response.status_code == 404:
                    raise HTTPException(status_code=404, detail=f"User {user_id} not found")
                response.raise_for_status()
                return [UserIdentityRecord(**i) for i in response.json()]
        else:
            try:
                return await user_mgmt.get_user_identities(tenant_id, user_id)
            except UserNotFoundError as exc:
                raise HTTPException(status_code=404, detail=str(exc))
    
    @router.get("/users/me/groups", response_model=List[GroupRecord])
    async def get_my_groups(
        claims: dict = Depends(_rbac("/api/auth/users/me", "read")),
    ):
        """Get groups current user belongs to."""
        user_id = claims.get("sub")
        tenant_id = claims.get("tenant_id")
        
        if not user_id or not tenant_id:
            raise HTTPException(status_code=401, detail="Missing required claims")
        
        user_id = int(user_id) if isinstance(user_id, str) else user_id
        tenant_id = int(tenant_id) if isinstance(tenant_id, str) else tenant_id
        
        if is_platform_mode:
            async with _get_platform_client(claims) as client:
                response = await client.get(
                    f"/api/v1/admin/tenants/{tenant_id}/users/{user_id}/groups",
                                    )
                response.raise_for_status()
                return [GroupRecord(**g) for g in response.json()]
        else:
            try:
                return await user_mgmt.get_user_groups(tenant_id, user_id)
            except UserNotFoundError as exc:
                raise HTTPException(status_code=404, detail=str(exc))

    @router.get("/users/{user_id}/groups", response_model=List[GroupRecord])
    async def get_user_groups(
        user_id: int,
        claims: dict = Depends(_rbac("/api/auth/users/*", "read")),
    ):
        """Get all groups for a user."""
        tenant_id = claims.get("tenant_id")
        if not tenant_id:
            raise HTTPException(status_code=401, detail="tenant_id not found in JWT")
        
        if is_platform_mode:
            async with _get_platform_client(claims) as client:
                response = await client.get(
                    f"/api/v1/admin/tenants/{tenant_id}/users/{user_id}/groups",
                                    )
                if response.status_code == 404:
                    raise HTTPException(status_code=404, detail=f"User {user_id} not found")
                response.raise_for_status()
                return [GroupRecord(**g) for g in response.json()]
        else:
            try:
                return await user_mgmt.get_user_groups(tenant_id, user_id)
            except UserNotFoundError as exc:
                raise HTTPException(status_code=404, detail=str(exc))
    
    @router.get("/users/me/roles", response_model=List[RoleRecord])
    async def get_my_roles(
        claims: dict = Depends(_rbac("/api/auth/users/me", "read")),
    ):
        """Get roles current user has."""
        user_id = claims.get("sub")
        tenant_id = claims.get("tenant_id")
        
        if not user_id or not tenant_id:
            raise HTTPException(status_code=401, detail="Missing required claims")
        
        user_id = int(user_id) if isinstance(user_id, str) else user_id
        tenant_id = int(tenant_id) if isinstance(tenant_id, str) else tenant_id
        
        if is_platform_mode:
            async with _get_platform_client(claims) as client:
                response = await client.get(
                    f"/api/v1/admin/tenants/{tenant_id}/users/{user_id}/roles",
                                    )
                if response.status_code == 404:
                    raise HTTPException(status_code=404, detail="User not found")
                response.raise_for_status()
                return [RoleRecord(**r) for r in response.json()]
        else:
            try:
                return await user_mgmt.get_user_roles(tenant_id, user_id)
            except UserNotFoundError as exc:
                raise HTTPException(status_code=404, detail=str(exc))

    @router.get("/users/{user_id}/roles", response_model=List[RoleRecord])
    async def get_user_roles(
        user_id: int,
        claims: dict = Depends(_rbac("/api/auth/users/*", "read")),
    ):
        """Get all roles for a user (including inherited from parent groups)."""
        tenant_id = claims.get("tenant_id")
        if not tenant_id:
            raise HTTPException(status_code=401, detail="tenant_id not found in JWT")
        
        if is_platform_mode:
            async with _get_platform_client(claims) as client:
                response = await client.get(
                    f"/api/v1/admin/tenants/{tenant_id}/users/{user_id}/roles",
                                    )
                if response.status_code == 404:
                    raise HTTPException(status_code=404, detail=f"User {user_id} not found")
                response.raise_for_status()
                return [RoleRecord(**r) for r in response.json()]
        else:
            try:
                return await user_mgmt.get_user_roles(tenant_id, user_id)
            except UserNotFoundError as exc:
                raise HTTPException(status_code=404, detail=str(exc))

    @router.get("/users/{user_id}/details", response_model=UserDetailsResponse)
    async def get_user_details(
        user_id: int,
        claims: dict = Depends(_rbac("/api/auth/users/*", "read")),
    ):
        """
        Get comprehensive user details including:
        - User profile information
        - User groups and memberships
        - User roles and permissions
        - User identities (OAuth providers)
        """
        if config.mode == OAuthMode.PLATFORM:
            # PLATFORM mode: delegate to platform service
            import httpx
            
            tenant_id = claims.get("tenant_id")
            app_id = claims.get("app_id")
            if not tenant_id or not app_id:
                raise HTTPException(status_code=401, detail="Invalid JWT: missing tenant_id/app_id")
            
            try:
                async with httpx.AsyncClient(
                    base_url=config.platform_oauth_url.rstrip("/"),
                    headers={
                        "Content-Type": "application/json",
                        "Authorization": f"Bearer {claims.get('_raw_token', '')}"
                    },
                    timeout=30.0,
                ) as client:
                    # Get user details
                    user_response = await client.get(f"/api/v1/admin/tenants/{tenant_id}/users/{user_id}")
                    user_response.raise_for_status()
                    user_data = user_response.json()
                    
                    # Get user groups
                    groups_response = await client.get(f"/api/v1/admin/tenants/{tenant_id}/users/{user_id}/groups")
                    groups_response.raise_for_status()
                    groups_data = groups_response.json()
                    
                    # Get user roles
                    roles_response = await client.get(f"/api/v1/admin/tenants/{tenant_id}/users/{user_id}/roles")
                    roles_response.raise_for_status()
                    roles_data = roles_response.json()
                    
                    # Get user identities
                    identities_response = await client.get(f"/api/v1/admin/tenants/{tenant_id}/users/{user_id}/identities")
                    identities_response.raise_for_status()
                    identities_data = identities_response.json()
                    
                    return UserDetailsResponse(
                        user=UserRecord(**user_data),
                        groups=[GroupRecord(**g) for g in groups_data],
                        roles=[RoleRecord(**r) for r in roles_data],
                        identities=[UserIdentityRecord(**i) for i in identities_data]
                    )
                    
            except httpx.HTTPStatusError as exc:
                if exc.response.status_code == 404:
                    raise HTTPException(status_code=404, detail=f"User {user_id} not found")
                raise HTTPException(status_code=exc.response.status_code, detail=exc.response.text)
            except Exception as exc:
                raise HTTPException(status_code=500, detail=f"Failed to fetch user details: {str(exc)}")
        
        # STANDALONE mode: use local database
        _db = user_mgmt._db if user_mgmt else None
        if not _db:
            raise HTTPException(
                status_code=500,
                detail="Database not configured. User details require AuthDatabase.",
            )
        
        tenant_id = claims.get("tenant_id")
        if not tenant_id:
            raise HTTPException(status_code=401, detail="Invalid JWT: missing tenant_id")
        
        try:
            # Get user profile
            user = await user_mgmt.get_user_by_id(int(tenant_id), user_id)
            if not user:
                raise HTTPException(status_code=404, detail=f"User {user_id} not found")
            
            # Get user groups
            groups = await user_mgmt.get_user_groups(int(tenant_id), user_id)
            
            # Get user roles
            roles = await user_mgmt.get_user_roles(int(tenant_id), user_id)
            
            # Get user identities
            identities = await user_mgmt.get_user_identities(int(tenant_id), user_id)
            
            return UserDetailsResponse(
                user=user,
                groups=groups,
                roles=roles,
                identities=identities
            )
            
        except UserNotFoundError as exc:
            raise HTTPException(status_code=404, detail=str(exc))
        except Exception as exc:
            raise HTTPException(status_code=500, detail=f"Failed to fetch user details: {str(exc)}")

    return router