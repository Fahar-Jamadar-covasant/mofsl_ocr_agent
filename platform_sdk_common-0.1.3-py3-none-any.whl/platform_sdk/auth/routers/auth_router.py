"""
Pre-built FastAPI router. Users bind it with one line:

    app.include_router(create_auth_router(oauth_config, database=db))

Provides:
    GET  /auth/login                                              → STANDALONE shortcut (uses config defaults)
    GET  /auth/login/{tenant_name}/{app_name}/{provider_name}     → explicit login (both modes)
    GET  /auth/callback  → exchange code → OAuthResult (jwt_token + refresh_token)
    POST /auth/refresh   → STANDALONE: {jwt_token} / PLATFORM: {refresh_token}
    POST /auth/logout    → revoke session
    GET  /auth/profile   → user profile (protected)

All path params are business names (strings), never integer IDs.
"""

from datetime import datetime, timezone
import os
import logging
import secrets
import time
from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field
from fastapi.security import HTTPAuthorizationCredentials

from ..interfaces import (
    OAuthConfig, OAuthError, OAuthResult, OAuthMode,
    InitializeStandaloneRequest, InitializeStandaloneResponse, InitializationError,
    JWTAlgorithm,
    CreateProviderRequest, CreateProviderResponse,
    LinkAppProviderRequest, LinkAppProviderResponse,
    UpdateProviderRequest, UpdateProviderResponse,
    DeleteProviderResponse,
    UpdateAppProviderRequest, UpdateAppProviderResponse,
    DeleteAppProviderResponse,
    SwitchScopeRequest, SwitchScopeResponse,
    ScopeContext,
)
from ..business_entity_management import BusinessEntityManagement
from platform_sdk.common import ValidationError
logger = logging.getLogger(__name__)
from ..oauth2_client import OAuth2Client
from ..state_store import StateStore, InMemoryStateStore
from ..database import AuthDatabase
from ..dependencies import _AuthDependency, require_auth
from ..authorization import AuthorizationEngine


# Request body models for Swagger UI - mode-specific
class StandaloneRefreshRequest(BaseModel):
    """Request body for token refresh in STANDALONE mode."""
    jwt_token: str = Field(..., description="JWT token to refresh")


class PlatformRefreshRequest(BaseModel):
    """Request body for token refresh in PLATFORM mode."""
    refresh_token: str = Field(..., description="Platform refresh token (opaque)")


class LogoutRequest(BaseModel):
    """Request body for logout."""
    jwt_token: str = Field(..., description="JWT token to revoke")


class IdpTokensRequest(BaseModel):
    """Request body for retrieving IDP tokens."""
    jwt_token: str = Field(..., description="JWT token containing session_id")
    json_path: Optional[str] = Field(None, description="Optional JSONPath to extract specific field (e.g., 'access_token')")


class PasswordLoginRequest(BaseModel):
    """Request body for password-based login."""
    tenant_name: Optional[str] = Field(None, description="Tenant name (optional, uses .env default)")
    app_name: Optional[str] = Field(None, description="App name (optional, uses .env default)")
    email: str = Field(..., description="User email address")
    password: str = Field(..., description="User password")


class RegisterProviderRequest(BaseModel):
    """Request body for registering an IDP provider for the current tenant/app."""

    provider_name: str = Field(..., description="Provider name (e.g. 'google', 'microsoft')")
    issuer_url: str = Field(..., description="OIDC issuer URL")
    client_id: str = Field(..., description="OIDC client_id")
    client_secret: str = Field(..., description="OIDC client_secret")
    redirect_uri: str = Field(..., description="Redirect URI registered with the IDP")


class RegisterProviderResponse(BaseModel):
    """Response for provider registration/linking."""

    success: bool
    tenant_id: int
    app_id: int
    provider_id: int
    provider_name: str
    scopes: List[str]
    message: str


def _is_valid_frontend_url(url: str) -> bool:
    """
    Validate frontend callback URL against allowed domains.
    
    Args:
        url: Frontend callback URL to validate
        
    Returns:
        True if URL is valid, False otherwise
    """
    if not url:
        return False
    
    # Must be HTTP or HTTPS
    if not url.startswith(("http://", "https://")):
        return False
    
    # Get allowed domains from environment variable
    allowed_domains_str = os.getenv("ALLOWED_FRONTEND_DOMAINS", "http://localhost:3000,https://localhost:3000")
    allowed_domains = [domain.strip() for domain in allowed_domains_str.split(",")]
    
    # Check if URL starts with any allowed domain
    for domain in allowed_domains:
        if url.startswith(domain):
            return True
    
    return False


def _generate_rsa_keys() -> tuple:
    """Generate RSA 2048-bit key pair. Returns (private_pem, public_pem)."""
    from cryptography.hazmat.primitives.asymmetric import rsa
    from cryptography.hazmat.primitives import serialization
    
    private_key = rsa.generate_private_key(
        public_exponent=65537,
        key_size=2048,
    )
    private_pem = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    ).decode()
    
    public_pem = private_key.public_key().public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    ).decode()
    
    return private_pem, public_pem


def create_auth_router(
    config: OAuthConfig,
    state_store: Optional[StateStore] = None,
    database: Optional[AuthDatabase] = None,
    prefix: str = "",
    tags: Optional[list] = None,
):
    """
    Build and return a ready-to-use FastAPI APIRouter.

    Parameters
    ----------
    config      : OAuthConfig – fully populated config (STANDALONE or PLATFORM).
    state_store : StateStore  – pluggable state store. If database is provided and
                                state_store is not, the database is used as the store.
    database    : AuthDatabase – optional Postgres backend for sessions.
    prefix      : str         – URL prefix for all auth routes (set by application, e.g., "/api/auth").
    tags        : list        – OpenAPI tags.

    Returns
    -------
    fastapi.APIRouter
    """
    from fastapi import APIRouter, Request, HTTPException, Depends, Query
    from fastapi.responses import RedirectResponse

    router = APIRouter(prefix=prefix, tags=tags or ["auth"])

    # Prefer a persistent store to survive reloads / multi-worker deployments.
    # AuthDatabase implements the state methods used by OAuth2Client.
    _db = database
    _store = state_store or (_db if _db is not None else InMemoryStateStore())
    _client: Optional[OAuth2Client] = None
    _auth_dep = _AuthDependency(config, database=database)
    _auth_engine = AuthorizationEngine(_db) if _db is not None else None

    def _rbac(resource_path: str, action: str):
        async def _dep(claims: dict = Depends(_auth_dep)):
            # In PLATFORM mode, still validate session but skip RBAC (handled by platform service)
            if config.mode != OAuthMode.STANDALONE:
                return claims
            if _auth_engine is None:
                raise HTTPException(status_code=500, detail="Authorization engine not configured")

            user_id = claims.get("sub")
            tenant_id = claims.get("tenant_id")
            app_id = claims.get("app_id")
            if not all([user_id, tenant_id, app_id]):
                raise HTTPException(
                    status_code=403,
                    detail="Missing required claims in JWT (user_id, tenant_id, app_id)",
                )

            allowed, reason, policy = await _auth_engine.can_user_perform(
                user_id=int(user_id) if isinstance(user_id, str) else user_id,
                tenant_id=int(tenant_id) if isinstance(tenant_id, str) else tenant_id,
                app_id=int(app_id) if isinstance(app_id, str) else app_id,
                resource_path=resource_path,
                action_name=action,
            )
            if not allowed:
                raise HTTPException(status_code=403, detail=f"Permission denied: {reason}")

            claims["_rbac_check"] = {
                "resource": resource_path,
                "action": action,
                "allowed": True,
                "reason": reason,
                "policy_id": policy.get("id") if policy else None,
            }
            return claims

        return _dep

    def _format_timestamp(ts: Optional[float]) -> Optional[str]:
        if ts is None:
            return None
        if isinstance(ts, datetime):
            return ts.astimezone(timezone.utc).isoformat()
        return datetime.fromtimestamp(float(ts), tz=timezone.utc).isoformat()

    def _serialize_result(result: OAuthResult) -> dict:
        expires_at_iso = _format_timestamp(result.expires_at)

        if config.mode == OAuthMode.STANDALONE:
            return {
                "jwt_token": result.jwt_token,
                "session_id": result.session_id,
                "user_id": result.user_id,
                "email": result.email,
                "name": result.name,
                # "roles": result.roles,
                # "groups": result.groups,
                "provider": result.provider,
                "tenant_id": result.tenant_id,
                "expires_at": expires_at_iso,
            }

        data = result.model_dump()
        data["expires_at"] = expires_at_iso
        return data

    async def _get_client() -> OAuth2Client:
        nonlocal _client
        if _client is None or not _client._initialized:
            _client = OAuth2Client(config, state_store=_store, database=_db)
            await _client.initialize()
        return _client

    # ── routes ────────────────────────────────

    if config.mode == OAuthMode.STANDALONE:
        # Password-based login (standalone mode)
        @router.post("/login/password")
        async def password_login(body: PasswordLoginRequest):
            """
            Password-based authentication for users.
            
            Used in standalone mode for users with password_hash set in the database.
            Access control is enforced via RBAC policies, not hardcoded roles.
            
            Returns JWT token with user claims (roles, groups, tenant info).
            """
            if not _db:
                raise HTTPException(
                    status_code=500,
                    detail="Database not configured. Password login requires AuthDatabase."
                )
            
            try:
                from ..user_management import UserManagement
                
                user_mgmt = UserManagement(_db)
                
                # Use defaults from .env if not provided
                tenant_name = body.tenant_name or config.default_tenant_name
                app_name = body.app_name or config.default_app_name
                
                if not tenant_name or not app_name:
                    raise HTTPException(
                        status_code=400,
                        detail="tenant_name and app_name must be provided or set in .env as defaults"
                    )
                
                # Get tenant
                pool = _db._need_pool()
                async with pool.acquire() as conn:
                    tenant = await conn.fetchrow(
                        "SELECT id FROM tenants WHERE tenant_name = $1",
                        tenant_name
                    )
                    if not tenant:
                        raise HTTPException(status_code=401, detail=f"Tenant '{tenant_name}' not found")
                    
                    tenant_id = tenant['id']
                    
                    # Authenticate user with password (using shared SDK method)
                    user_row = await user_mgmt.authenticate_with_password(
                        tenant_id=tenant_id,
                        email=body.email,
                        password=body.password
                    )
                    if not user_row:
                        raise HTTPException(status_code=401, detail="Invalid credentials")

                    user_id = user_row["id"]

                    # Ensure password user has a default group (mirrors OAuth upsert_user_on_login)
                    active_group_count = await conn.fetchval("""
                        SELECT COUNT(*)
                        FROM user_groups ug
                        JOIN u_groups g ON g.id = ug.group_id
                        WHERE ug.user_id = $1 AND g.tenant_id = $2 AND g.is_active = TRUE
                    """, user_id, tenant_id)
                    if active_group_count == 0:
                        default_group = await conn.fetchrow("""
                            SELECT id FROM u_groups
                            WHERE tenant_id = $1 AND is_default = TRUE AND is_active = TRUE
                            LIMIT 1
                        """, tenant_id)
                        if default_group:
                            await conn.execute("""
                                INSERT INTO user_groups (tenant_id, user_id, group_id)
                                VALUES ($1, $2, $3)
                                ON CONFLICT (user_id, group_id) DO NOTHING
                            """, tenant_id, user_id, default_group['id'])
                            logger.info(f"Password user {user_id} assigned to default group on login")

                    # Get user groups
                    groups = await user_mgmt.get_user_groups(tenant_id, user_id)
                    
                    # Get app_id and password provider_id for session creation
                    app_provider = await conn.fetchrow("""
                        SELECT ap.app_id, ap.provider_id
                        FROM app_providers ap
                        JOIN apps a ON a.id = ap.app_id
                        JOIN providers p ON p.id = ap.provider_id
                        WHERE a.tenant_id = $1 
                          AND a.app_name = $2
                          AND p.provider_name = 'password'
                          AND ap.is_active = TRUE
                    """, tenant_id, app_name)
                    
                    if not app_provider:
                        raise HTTPException(
                            status_code=500, 
                            detail=f"Password provider not configured for app '{app_name}'. Run seed script first."
                        )
                    
                    app_id = app_provider['app_id']
                    provider_id = app_provider['provider_id']

                    # Update last login
                    await conn.execute(
                        "UPDATE users SET last_login_at = NOW() WHERE id = $1",
                        user_id
                    )
                
                display_name = user_row["display_name"] or f"{user_row['first_name']} {user_row['last_name']}".strip()
                group_names = [g.group_name for g in groups]

                # Initialize auth engine for scope resolution
                auth_engine = AuthorizationEngine(_db)

                # Fetch user scopes via group-scope mappings and auto-select first scope
                active_scope_id = None
                active_scope_name = None
                try:
                    # Get available scopes and auto-select first one
                    available_scopes = await auth_engine.get_user_available_scopes(user_id, tenant_id)
                    if available_scopes:
                        first_scope = available_scopes[0]
                        active_scope_id = first_scope["id"]
                        active_scope_name = first_scope["name"]
                        logger.info(f"Auto-selected first scope for password login user {user_id}: scope_id={active_scope_id}, name={active_scope_name}")
                except Exception as e:
                    logger.warning(f"Failed to resolve scopes for password login user {user_id}: {e}")

                user_attributes = {
                    "email": user_row["email"],
                    "name": display_name,
                    "provider": "password",
                }

                # Generate custom refresh token for password-based auth (90-day expiry like OAuth)
                refresh_token = secrets.token_urlsafe(32)
                refresh_token_expiry_seconds = 90 * 24 * 3600  # 90 days
                now = time.time()

                # Store refresh token in idp_tokens (similar to OAuth flow)
                idp_tokens = {
                    "refresh_token": refresh_token,
                    "expires_at": now + refresh_token_expiry_seconds,
                    "issued_at": now,
                }

                # Create session in database with auto-selected scope (STANDALONE mode, no platform tokens)
                session = await _db.create_session(
                    app_id=app_id,
                    provider_id=provider_id,
                    tenant_id=tenant_id,
                    user_id=user_id,
                    user_attributes=user_attributes,
                    idp_tokens=idp_tokens,
                    ttl_seconds=config.jwt_expiry_seconds,
                    created_by=user_id,
                    include_platform_tokens=False,
                    active_scope_id=active_scope_id,
                )

                # Generate JWT using helper (handles scoped vs global based on active_scope_id)
                client = await _get_client()
                jwt_token = await client._refresh_jwt_from_session(session)

                # Decode JWT to extract scoped roles for response
                import jwt as pyjwt
                decoded = pyjwt.decode(jwt_token, options={"verify_signature": False})
                response_roles = decoded.get("roles", [])
                response_scopes = decoded.get("scopes", [])

                return {
                    "jwt_token": jwt_token,
                    "refresh_token": refresh_token,
                    "user_id": user_id,
                    "email": user_row["email"],
                    "name": display_name,
                    "roles": response_roles,
                    "scopes": response_scopes,
                    "groups": group_names,
                    "active_scope_id": active_scope_id,
                    "active_scope_name": active_scope_name,
                    "tenant_id": tenant_id,
                    "app_id": app_id,
                    "tenant_name": tenant_name,
                }
                    
            except HTTPException:
                raise
            except Exception as exc:
                raise HTTPException(status_code=500, detail=f"Login failed: {str(exc)}")

    else:
        # Password-based login for platform mode - delegates to Platform Service
        @router.post("/login/password")
        async def password_login(body: PasswordLoginRequest):
            """
            Password-based authentication for platform tenants.
            
            Delegates to Platform Service which validates credentials against the central database.
            Returns JWT token with user claims (roles, groups, tenant info).
            """
            import httpx
            
            try:
                async with httpx.AsyncClient(base_url=config.platform_oauth_url.rstrip("/"), timeout=30.0) as client:
                    response = await client.post("/api/v1/auth/token/password", json={
                        "tenant_name": body.tenant_name,
                        "app_name": body.app_name,
                        "email": body.email,
                        "password": body.password
                    })
                    response.raise_for_status()
                    return response.json()
            except httpx.HTTPStatusError as exc:
                if exc.response.status_code == 401:
                    raise HTTPException(status_code=401, detail="Invalid credentials")
                elif exc.response.status_code == 404:
                    raise HTTPException(status_code=404, detail="Tenant or app not found")
                else:
                    raise HTTPException(status_code=exc.response.status_code, detail=exc.response.text)
            except Exception as exc:
                logger.error(f"Platform password login failed: {exc}", exc_info=True)
                raise HTTPException(status_code=500, detail=f"Login failed: {str(exc)}")

    # STANDALONE mode: default login using config defaults
    if config.mode == OAuthMode.STANDALONE:
        @router.get("/login")
        async def login_default(
            request: Request,
            provider_name: Optional[str] = Query(None, description="Provider name (e.g., 'google', 'azure'). Uses .env default if not provided."),
            tenant_name: Optional[str] = Query(None, description="Tenant name. Uses .env default if not provided."),
            app_name: Optional[str] = Query(None, description="App name. Uses .env default if not provided."),
            frontend_callback_url: Optional[str] = Query(None, description="Optional frontend callback URL for token redirect"),
        ):
            """
            Flexible OAuth login endpoint with optional query parameters.
            STANDALONE mode only - falls back to .env defaults for any missing parameters.

            Falls back to .env defaults: STANDALONE_TENANT_NAME, STANDALONE_APP_NAME, STANDALONE_PROVIDER_NAME.
            With frontend_callback_url the tokens are redirected to that URL after login.
            """
            tenant = tenant_name or config.default_tenant_name
            app = app_name or config.default_app_name
            provider = provider_name or config.default_provider_name

            if not all([tenant, app, provider]):
                raise HTTPException(
                    status_code=400,
                    detail="tenant_name, app_name, and provider_name must be provided or set in .env defaults"
                )

            if frontend_callback_url and not _is_valid_frontend_url(frontend_callback_url):
                raise HTTPException(
                    status_code=400,
                    detail="Invalid frontend callback URL. URL must start with one of the allowed domains configured in ALLOWED_FRONTEND_DOMAINS."
                )

            try:
                client = await _get_client()
                auth_url, _ = await client.get_auth_url(
                    tenant_name=tenant,
                    app_name=app,
                    provider_name=provider,
                    frontend_callback_url=frontend_callback_url,
                    base_url=str(request.base_url),
                )
                return RedirectResponse(url=auth_url)
            except OAuthError as exc:
                raise HTTPException(status_code=500, detail=exc.message)

    # Both modes: explicit tenant/app/provider by name in path
    @router.get("/login/{tenant_name}/{app_name}/{provider_name}")
    async def login_explicit(
        request: Request,
        tenant_name: str,
        app_name: str,
        provider_name: str,
        frontend_callback_url: Optional[str] = Query(None, description="Optional frontend callback URL for token redirect"),
    ):
        """
        Login with explicit tenant, app, and provider names in path.
        Example: /auth/login/acme/etlopt/google
        Works in both STANDALONE and PLATFORM modes.
        """
        if frontend_callback_url and not _is_valid_frontend_url(frontend_callback_url):
            raise HTTPException(
                status_code=400,
                detail="Invalid frontend callback URL. URL must start with one of the allowed domains configured in ALLOWED_FRONTEND_DOMAINS."
            )

        try:
            client = await _get_client()
            auth_url, _ = await client.get_auth_url(
                tenant_name=tenant_name,
                app_name=app_name,
                provider_name=provider_name,
                frontend_callback_url=frontend_callback_url,
                base_url=str(request.base_url),
            )
            return RedirectResponse(url=auth_url)
        except OAuthError as exc:
            raise HTTPException(status_code=500, detail=exc.message)

    @router.get("/callback")
    async def callback(request: Request):
        """
        Handle the redirect back from the IDP / Platform.
        Exchange the authorization code for a wrapper JWT.
        
        If frontend_callback_url was provided during login, redirects to frontend with tokens.
        Otherwise, returns JSON response (backward compatible).
        """
        code = request.query_params.get("code")
        state = request.query_params.get("state")

        if not code:
            raise HTTPException(status_code=400, detail="Missing 'code' parameter")
        if not state:
            raise HTTPException(status_code=400, detail="Missing 'state' parameter")

        # PLATFORM mode: delegate to platform service token exchange endpoint
        if config.mode == OAuthMode.PLATFORM:
            import httpx
            
            try:
                # Platform Service uses saved OAuth state (by state parameter) to get app_id/provider_id
                # Then looks up app-provider config using get_app_with_provider_by_id(app_id, provider_id)
                # No need to send tenant_name/app_name/provider_name - Platform gets them from IDs
                async with httpx.AsyncClient(
                    base_url=config.platform_oauth_url.rstrip("/"),
                    timeout=30.0,
                ) as client:
                    response = await client.post(
                        "/api/v1/auth/token",
                        json={
                            "code": code,
                            "state": state,
                        }
                    )
                    response.raise_for_status()
                    return response.json()
            except httpx.HTTPStatusError as exc:
                raise HTTPException(status_code=exc.response.status_code, detail=exc.response.text)
            except Exception as exc:
                raise HTTPException(status_code=500, detail=f"Callback token exchange failed: {str(exc)}")

        # STANDALONE mode: handle locally
        try:
            client = await _get_client()
            
            # Get saved state to check for frontend_callback_url
            saved_state = await client._state_store.get_state(state)
            frontend_callback_url = saved_state.frontend_callback_url if saved_state else None
            
            # Exchange code for tokens
            result: OAuthResult = await client.do_login(auth_code=code, state=state)
            
            # If frontend_callback_url provided, redirect to frontend with tokens
            if frontend_callback_url:
                from urllib.parse import urlencode
                params = {
                    "token": result.jwt_token,
                }
                if result.refresh_token:
                    params["refresh"] = result.refresh_token
                
                redirect_url = f"{frontend_callback_url}?{urlencode(params)}"
                return RedirectResponse(url=redirect_url)
            
            # Fallback: return JSON response (backward compatible)
            return _serialize_result(result)
        except OAuthError as exc:
            raise HTTPException(status_code=401, detail=exc.message)

    # Mode-specific refresh endpoints
    if config.mode == OAuthMode.STANDALONE:
        @router.post("/refresh")
        async def refresh(body: StandaloneRefreshRequest):
            """
            Refresh tokens (STANDALONE mode).
            
            Provide JWT token - extracts session_id to retrieve stored IDP refresh_token,
            refreshes at IDP, and returns new JWT with same session_id.
            """
            try:
                client = await _get_client()
                result: OAuthResult = await client.do_refresh(body.jwt_token)
                return _serialize_result(result)
            except OAuthError as exc:
                raise HTTPException(status_code=401, detail=exc.message)
    else:
        @router.post("/refresh")
        async def refresh(body: PlatformRefreshRequest):
            """
            Refresh tokens (PLATFORM mode).
            
            Provide platform refresh_token (opaque) - platform service looks up session,
            refreshes at IDP, rotates platform tokens, and returns new JWT + refresh_token.
            """
            try:
                client = await _get_client()
                result: OAuthResult = await client.do_refresh(body.refresh_token)
                return _serialize_result(result)
            except OAuthError as exc:
                raise HTTPException(status_code=401, detail=exc.message)

    @router.post("/logout")
    async def logout(body: LogoutRequest):
        """
        Revoke the inner OAuth tokens and invalidate the session.

        Provide the JWT token to logout and revoke the session.
        """
        try:
            client = await _get_client()
            success = await client.do_logout(body.jwt_token)
            return {"success": success}
        except OAuthError as exc:
            raise HTTPException(status_code=500, detail=exc.message)
        except ValidationError as exc:
            raise HTTPException(status_code=400, detail="Invalid token")

    @router.post("/switch-scope", response_model=SwitchScopeResponse)
    async def switch_scope(
        body: SwitchScopeRequest,
        claims: dict = Depends(_auth_dep),
    ):
        """
        Switch user's active scope context (GCP project-switcher style).

        Validates the requested scope against the user's available scopes (via JWT),
        updates session, and reissues JWT via refresh helper.

        Protected: Requires valid JWT in Authorization header.
        """
        try:
            if not _db:
                raise HTTPException(status_code=500, detail="Switch-scope requires database (STANDALONE mode only)")

            client = await _get_client()
            auth_engine = AuthorizationEngine(_db)
            user_id = int(claims.get("sub"))
            tenant_id = int(claims.get("tenant_id"))
            session_id = claims.get("session_id")

            if not all([user_id, tenant_id, session_id]):
                raise HTTPException(status_code=401, detail="Missing required JWT fields")

            # Get current session
            session = await _db.get_session(session_id)
            if not session or session.is_revoked:
                raise HTTPException(status_code=401, detail="Session not found or revoked")

            # Convert scope_uuid to scope_id
            scope_id = None
            scope_uuid = None
            if body.scope_uuid is not None:
                # Lookup scope by UUID to get ID
                pool = _db._need_pool()
                async with pool.acquire() as conn:
                    scope_row = await conn.fetchrow(
                        "SELECT id, uuid FROM scopes WHERE uuid = $1 AND tenant_id = $2",
                        body.scope_uuid, tenant_id
                    )
                if not scope_row:
                    raise HTTPException(status_code=404, detail=f"Scope '{body.scope_uuid}' not found")
                scope_id = scope_row["id"]
                scope_uuid = str(scope_row["uuid"])

            # Validate scope access if switching to a specific scope
            if scope_id is not None:
                available_scopes = await auth_engine.get_user_available_scopes(user_id, tenant_id)
                if scope_id not in {s["id"] for s in available_scopes}:
                    raise HTTPException(status_code=403, detail="Scope not accessible")
                scope_info = next(s for s in available_scopes if s["id"] == scope_id)
                scope_name = scope_info["name"]
                entity_level = scope_info.get("entity_level")
            else:
                scope_name = None
                entity_level = None
                scope_uuid = None

            # Update session.active_scope_id and add audit log entry
            pool = _db._need_pool()
            async with pool.acquire() as conn:
                # Create audit log entry for scope switch
                import json
                audit_entry = {
                    "action": "scope_switch",
                    "from_scope_id": session.active_scope_id,
                    "to_scope_id": scope_id,
                    "timestamp": time.time(),
                    "user_id": user_id
                }

                await conn.execute(
                    """UPDATE sessions
                       SET active_scope_id = $1,
                           audit_log = audit_log || $2::jsonb,
                           updated_at = NOW(),
                           updated_by = $3
                       WHERE id = $4""",
                    scope_id,
                    json.dumps([audit_entry]),
                    user_id,
                    session_id
                )
                logger.info(
                    f"Scope switch: user={user_id} "
                    f"from={session.active_scope_id} to={scope_id}"
                )

            # Reload session (now has updated active_scope_id) and generate new JWT
            session = await _db.get_session(session_id)
            new_jwt = await client._refresh_jwt_from_session(session)

            # Decode JWT to extract roles and perms for response
            import jwt as pyjwt
            decoded = pyjwt.decode(new_jwt, options={"verify_signature": False})
            roles = decoded.get("roles", [])
            perms = decoded.get("perms")

            return SwitchScopeResponse(
                jwt_token=new_jwt,
                active_scope_id=scope_id,
                active_scope_uuid=scope_uuid,
                active_scope_name=scope_name,
                entity_level=entity_level,
                roles=roles,
                perms=perms
            )

        except HTTPException:
            raise
        except Exception as exc:
            logger.error(f"Switch scope failed: {str(exc)}")
            raise HTTPException(status_code=500, detail=f"Switch scope failed: {str(exc)}")

    async def _build_scope_context(scope_id: int, tenant_id: int) -> Optional[ScopeContext]:
        """
        Build generic scope context from scope_id.

        Returns enriched hierarchy with parent_chain and children (recursive tree).
        Works for any number of hierarchy levels (not hardcoded to 3).
        """
        pool = _db._need_pool()
        async with pool.acquire() as conn:
            scope_row = await conn.fetchrow("""
                SELECT s.id AS scope_id, s.uuid AS scope_uuid, s.name AS scope_name,
                       se.id AS entity_id, se.uuid AS entity_uuid, se.name AS entity_name,
                       se.parent_id, sel.name AS entity_level, sel.depth
                FROM scopes s
                JOIN scope_entities se ON se.id = s.entity_id
                JOIN scope_entity_levels sel ON sel.id = se.level_id
                WHERE s.id = $1 AND s.tenant_id = $2 AND s.is_active = TRUE
            """, scope_id, tenant_id)

        if not scope_row:
            return None

        em = BusinessEntityManagement(_db)

        # Get parent chain (ancestors) — breadcrumb only, no children field
        parent_chain_raw = await em.get_parent_chain(scope_row["entity_id"])
        parent_chain = [
            {
                "id": p["id"],
                "uuid": str(p["uuid"]) if p.get("uuid") else None,
                "name": p["name"],
                "level": p["level_name"],
            }
            for p in parent_chain_raw
        ]

        # Get children (direct children with full subtree)
        children_raw = await em.list_children(scope_row["entity_id"], recursive=True)

        # Build nested tree for children
        def build_tree(entity_list):
            if not entity_list:
                return []

            by_id = {}
            for e in entity_list:
                by_id[e["id"]] = {
                    "id": e["id"],
                    "uuid": str(e["uuid"]) if e.get("uuid") else None,
                    "name": e["name"],
                    "level": e["level_name"],
                    "children": []
                }

            roots = []
            for e in entity_list:
                node = by_id[e["id"]]
                if e["parent_id"] in by_id:
                    by_id[e["parent_id"]]["children"].append(node)
                else:
                    roots.append(node)

            return roots

        children = build_tree(children_raw)

        return ScopeContext(
            scope_id=scope_row["scope_id"],
            scope_uuid=str(scope_row["scope_uuid"]) if scope_row["scope_uuid"] else None,
            scope_name=scope_row["scope_name"],
            entity_id=scope_row["entity_id"],
            entity_uuid=str(scope_row["entity_uuid"]) if scope_row["entity_uuid"] else None,
            entity_name=scope_row["entity_name"],
            entity_level=scope_row["entity_level"],
            entity_depth=scope_row["depth"],
            parent_chain=parent_chain,
            children=children,
        )

    @router.get("/scope/context", response_model=ScopeContext)
    async def get_scope_context(claims: dict = Depends(_auth_dep)):
        """
        Return enriched hierarchy context for the user's active scope (generic N-level).

        Returns parent_chain (ancestors) and children (recursive tree) for any hierarchy depth.
        Works for any scope level configured in the application (system, organization, project,
        or custom level names like company, team, division, etc.).

        Frontend extracts UUIDs from parent_chain + entity_uuid and uses them to filter data APIs.
        """
        if not _db:
            raise HTTPException(status_code=500, detail="scope/context requires database (STANDALONE mode only)")

        scope_id = claims.get("active_scope_id")
        if not scope_id:
            raise HTTPException(status_code=404, detail="No active scope in JWT. Call switch-scope first.")

        tenant_id = int(claims.get("tenant_id"))
        context = await _build_scope_context(int(scope_id), tenant_id)
        if not context:
            raise HTTPException(status_code=404, detail=f"Active scope {scope_id} not found or inactive")
        return context

    @router.get("/me")
    async def me(claims: dict = Depends(_auth_dep)):
        """Return user profile from JWT claims."""
        return {
            "user_id": claims.get("sub"),
            "email": claims.get("email"),
            "name": claims.get("name"),
            "roles": claims.get("roles", []),
            "groups": claims.get("groups", []),
            "provider": claims.get("provider"),
            "tenant_id": claims.get("tenant_id"),
            "app_id": claims.get("app_id"),
            "session_id": claims.get("session_id"),
        }

    @router.post(
        "/providers",
        response_model=CreateProviderResponse,
        summary="Create IDP Provider (Protected)",
        description="""Create an OIDC provider for a tenant (no app linkage).

        STANDALONE mode: Uses local database.
        PLATFORM mode: Delegates to platform service admin endpoint.
        """,
    )
    async def create_provider(
        body: CreateProviderRequest,
        claims: dict = Depends(_rbac("/api/auth/providers", "create")),
    ):
        # PLATFORM mode: delegate to platform service
        if config.mode == OAuthMode.PLATFORM:
            import httpx
            
            tenant_id = claims.get("tenant_id")
            app_id = claims.get("app_id")
            if not tenant_id or not app_id:
                raise HTTPException(status_code=401, detail="Invalid JWT: missing tenant_id/app_id")
            
            try:
                async with httpx.AsyncClient(
                    base_url=config.platform_oauth_url.rstrip("/"),
                    headers={
                        "Content-Type": "application/json",
                        "Authorization": f"Bearer {claims.get('_raw_token', '')}"
                    },
                    timeout=30.0,
                ) as client:
                    response = await client.post(
                        f"/api/v1/admin/tenants/{tenant_id}/providers",
                        json={
                            "provider_name": body.provider_name,
                            "issuer_url": body.issuer_url,
                            "idp_config": {
                                "client_id": body.client_id,
                                "client_secret": body.client_secret,
                                "redirect_uris": [body.redirect_uri],
                                "allowed_scopes": ["openid", "profile", "email"],
                            },
                            "config": {},
                        }
                    )
                    response.raise_for_status()
                    result = response.json()

                    provider = result.get("provider") or {}
                    provider_id = provider.get("id")
                    if not provider_id:
                        raise HTTPException(status_code=500, detail=f"Unexpected platform response: {result}")

                    scopes = []
                    idp_cfg = provider.get("idp_config") or {}
                    if isinstance(idp_cfg, dict):
                        scopes = idp_cfg.get("allowed_scopes") or []
                    if not scopes:
                        scopes = ["openid", "profile", "email"]

                    return CreateProviderResponse(
                        success=True,
                        tenant_id=int(tenant_id),
                        provider_id=int(provider_id),
                        provider_name=body.provider_name,
                        scopes=scopes,
                        message="Provider created successfully. Use app-providers endpoint to link to apps.",
                    )
            except httpx.HTTPStatusError as exc:
                raise HTTPException(status_code=exc.response.status_code, detail=exc.response.text)
            except Exception as exc:
                raise HTTPException(status_code=500, detail=f"Provider registration failed: {str(exc)}")
        
        # STANDALONE mode: use local database
        if not _db:
            raise HTTPException(
                status_code=500,
                detail="Database not configured. Provider creation requires AuthDatabase.",
            )

        tenant_id = claims.get("tenant_id")
        session_id = claims.get("session_id")
        actor_id = claims.get("sub")
        actor_id_int = int(actor_id) if actor_id is not None and str(actor_id).isdigit() else None
        if not tenant_id or not session_id:
            raise HTTPException(status_code=401, detail="Invalid JWT: missing tenant_id/session_id")

        # RBAC check is handled by the _rbac dependency - no hardcoded role checks
        session = await _db.get_session(session_id)
        if not session:
            raise HTTPException(status_code=404, detail="Session not found")
        if session.is_revoked:
            raise HTTPException(status_code=401, detail="Session has been revoked")

        from ..interfaces import ProviderConfig

        existing = await _db.get_provider_by_name(int(tenant_id), body.provider_name)
        if existing:
            provider_id = existing.id
            idp_cfg = dict(existing.idp_config or {})
            scopes = idp_cfg.get("allowed_scopes") or []
        else:
            provider_lower = body.provider_name.lower()
            issuer_lower = body.issuer_url.lower()
            is_microsoft = (
                "microsoft" in provider_lower
                or "azure" in provider_lower
                or "microsoft" in issuer_lower
                or "microsoftonline" in issuer_lower
            )
            scopes = ["openid", "profile", "email"]
            if is_microsoft:
                scopes.append("offline_access")

            created = await _db.create_provider(
                ProviderConfig(
                    tenant_id=int(tenant_id),
                    provider_name=body.provider_name,
                    issuer_url=body.issuer_url,
                    idp_config={
                        "client_id": body.client_id,
                        "client_secret": body.client_secret,
                        "redirect_uris": [body.redirect_uri],
                        "allowed_scopes": scopes,
                    },
                    config={},
                    created_by=actor_id_int,
                )
            )
            provider_id = created.id

        refreshed = await _db.refresh_provider_discovery(int(provider_id))
        refreshed_scopes = []
        if refreshed and refreshed.idp_config:
            refreshed_scopes = refreshed.idp_config.get("allowed_scopes") or scopes
        else:
            refreshed_scopes = scopes

        return CreateProviderResponse(
            success=True,
            tenant_id=int(tenant_id),
            provider_id=int(provider_id),
            provider_name=body.provider_name,
            scopes=refreshed_scopes,
            message="Provider created successfully",
        )

    # ──────────────────────────────────────
    # PROVIDER CRUD ENDPOINTS
    # ──────────────────────────────────────

    @router.get(
        "/providers",
        summary="List Providers (Protected)",
        description="""List all providers for the tenant."""
    )
    async def list_providers(
        claims: dict = Depends(_rbac("/api/auth/providers", "read")),
    ):
        # PLATFORM mode: delegate to platform service
        if config.mode == OAuthMode.PLATFORM:
            import httpx
            
            tenant_id = claims.get("tenant_id")
            if not tenant_id:
                raise HTTPException(status_code=401, detail="Invalid JWT: missing tenant_id")
            
            try:
                async with httpx.AsyncClient(
                    base_url=config.platform_oauth_url.rstrip("/"),
                    headers={"Authorization": f"Bearer {claims.get('_raw_token', '')}"},
                    timeout=30.0,
                ) as client:
                    response = await client.get(
                        f"/api/v1/admin/tenants/{tenant_id}/providers"
                    )
                    response.raise_for_status()
                    return response.json()
            except httpx.HTTPStatusError as exc:
                raise HTTPException(status_code=exc.response.status_code, detail=exc.response.text)
            except Exception as exc:
                raise HTTPException(status_code=500, detail=f"Provider listing failed: {str(exc)}")

        # STANDALONE mode: use local database
        if not _db:
            raise HTTPException(
                status_code=500,
                detail="Database not configured. Provider listing requires AuthDatabase.",
            )

        tenant_id = claims.get("tenant_id")
        if not tenant_id:
            raise HTTPException(status_code=401, detail="Invalid JWT: missing tenant_id")

        providers = await _db.list_providers(int(tenant_id))
        return {"providers": providers}

    @router.get(
        "/providers/{provider_id}",
        summary="Get Provider (Protected)",
        description="""Get provider details by ID.""",
    )
    async def get_provider(
        provider_id: int,
        claims: dict = Depends(_rbac("/api/auth/providers/.+", "read")),
    ):
        # PLATFORM mode: delegate to platform service
        if config.mode == OAuthMode.PLATFORM:
            import httpx
            
            tenant_id = claims.get("tenant_id")
            if not tenant_id:
                raise HTTPException(status_code=401, detail="Invalid JWT: missing tenant_id")
            
            try:
                async with httpx.AsyncClient(
                    base_url=config.platform_oauth_url.rstrip("/"),
                    timeout=30.0,
                ) as client:
                    response = await client.get(
                        f"/api/v1/admin/tenants/{tenant_id}/providers/{provider_id}"
                    )
                    response.raise_for_status()
                    return response.json()
            except httpx.HTTPStatusError as exc:
                raise HTTPException(status_code=exc.response.status_code, detail=exc.response.text)
            except Exception as exc:
                raise HTTPException(status_code=500, detail=f"Provider retrieval failed: {str(exc)}")

        # STANDALONE mode: use local database
        if not _db:
            raise HTTPException(
                status_code=500,
                detail="Database not configured. Provider retrieval requires AuthDatabase.",
            )

        tenant_id = claims.get("tenant_id")
        if not tenant_id:
            raise HTTPException(status_code=401, detail="Invalid JWT: missing tenant_id")

        provider = await _db.get_provider(provider_id)
        if not provider or provider.tenant_id != int(tenant_id):
            raise HTTPException(status_code=404, detail="Provider not found")

        return provider

    @router.patch(
        "/providers/{provider_id}",
        response_model=UpdateProviderResponse,
        summary="Update Provider (Protected)",
        description="""Update provider configuration.""",
    )
    async def update_provider(
        provider_id: int,
        body: UpdateProviderRequest,
        claims: dict = Depends(_rbac("/api/auth/providers/.+", "update")),
    ):
        # PLATFORM mode: delegate to platform service
        if config.mode == OAuthMode.PLATFORM:
            import httpx
            
            tenant_id = claims.get("tenant_id")
            if not tenant_id:
                raise HTTPException(status_code=401, detail="Invalid JWT: missing tenant_id")
            
            try:
                async with httpx.AsyncClient(
                    base_url=config.platform_oauth_url.rstrip("/"),
                    headers={
                        "Content-Type": "application/json",
                        "Authorization": f"Bearer {claims.get('_raw_token', '')}"
                    },
                    timeout=30.0,
                ) as client:
                    response = await client.patch(
                        f"/api/v1/admin/tenants/{tenant_id}/providers/{provider_id}",
                        json=body.model_dump(exclude_unset=True)
                    )
                    response.raise_for_status()
                    return response.json()
            except httpx.HTTPStatusError as exc:
                raise HTTPException(status_code=exc.response.status_code, detail=exc.response.text)
            except Exception as exc:
                raise HTTPException(status_code=500, detail=f"Provider update failed: {str(exc)}")

        # STANDALONE mode: use local database
        if not _db:
            raise HTTPException(
                status_code=500,
                detail="Database not configured. Provider update requires AuthDatabase.",
            )

        tenant_id = claims.get("tenant_id")
        actor_id = claims.get("sub")
        actor_id_int = int(actor_id) if actor_id is not None and str(actor_id).isdigit() else None
        if not tenant_id:
            raise HTTPException(status_code=401, detail="Invalid JWT: missing tenant_id")

        # Verify provider exists and belongs to tenant
        existing = await _db.get_provider(provider_id)
        if not existing or existing.tenant_id != int(tenant_id):
            raise HTTPException(status_code=404, detail="Provider not found")

        # Update provider
        from ..interfaces import ProviderConfig
        update_data = ProviderConfig(
            tenant_id=int(tenant_id),
            provider_name=existing.provider_name,
            issuer_url=body.issuer_url if body.issuer_url is not None else existing.issuer_url,
            idp_config=dict(existing.idp_config or {}),
            config=dict(existing.config or {}),
            created_by=existing.created_by,
        )

        # Run OIDC discovery whenever issuer_url is explicitly provided on update.
        # This covers retries where issuer_url may already be updated but endpoints are stale.
        if body.issuer_url is not None:
            logger.info("Issuer URL provided on update, running OIDC discovery for %s", body.issuer_url)
            discovered = await _db._discover_endpoints(body.issuer_url)
            if discovered:
                # Update discovered endpoints in idp_config
                idp_config = update_data.idp_config
                idp_config["authorize_url"] = discovered.get("authorization_endpoint")
                idp_config["token_url"] = discovered.get("token_endpoint")
                idp_config["userinfo_url"] = discovered.get("userinfo_endpoint")
                idp_config["revoke_url"] = discovered.get("revocation_endpoint")
                
                # Update provider metadata in config
                provider_config = update_data.config
                provider_config.update({
                    "jwks_url": discovered.get("jwks_uri"),
                    "scopes_supported": discovered.get("scopes_supported", []),
                })
                
                # Detect provider type and set default scopes
                issuer_lower = body.issuer_url.lower()
                is_google = "google" in issuer_lower or "googleapis" in issuer_lower
                is_microsoft = "microsoft" in issuer_lower or "microsoftonline" in issuer_lower
                default_scopes = ["openid", "profile", "email"]
                if is_microsoft:
                    default_scopes.append("offline_access")
                provider_config["default_scopes"] = default_scopes
                provider_config["provider_type"] = "google" if is_google else "microsoft" if is_microsoft else "generic"
                
                logger.info("OIDC discovery successful for updated provider")
            else:
                logger.warning("OIDC discovery failed for updated issuer %s", body.issuer_url)

        # Update IDP config if provided
        if body.client_id is not None or body.client_secret is not None or body.redirect_uri is not None:
            idp_config = update_data.idp_config
            if body.client_id is not None:
                idp_config["client_id"] = body.client_id
            if body.client_secret is not None:
                idp_config["client_secret"] = body.client_secret
            if body.redirect_uri is not None:
                idp_config["redirect_uris"] = [body.redirect_uri]
            # Ensure we have allowed_scopes
            if "allowed_scopes" not in idp_config:
                idp_config["allowed_scopes"] = update_data.config.get("default_scopes", ["openid", "profile", "email"])

        await _db.update_provider(provider_id, update_data, updated_by=actor_id_int)

        return UpdateProviderResponse(
            success=True,
            provider_id=provider_id,
            provider_name=existing.provider_name,
            message="Provider updated successfully",
        )

    @router.delete(
        "/providers/{provider_id}",
        response_model=DeleteProviderResponse,
        summary="Delete Provider (Protected)",
        description="""Delete a provider.""",
    )
    async def delete_provider(
        provider_id: int,
        claims: dict = Depends(_rbac("/api/auth/providers/.+", "delete")),
    ):
        # PLATFORM mode: delegate to platform service
        if config.mode == OAuthMode.PLATFORM:
            import httpx
            
            tenant_id = claims.get("tenant_id")
            if not tenant_id:
                raise HTTPException(status_code=401, detail="Invalid JWT: missing tenant_id")
            
            try:
                async with httpx.AsyncClient(
                    base_url=config.platform_oauth_url.rstrip("/"),
                    timeout=30.0,
                ) as client:
                    response = await client.delete(
                        f"/api/v1/admin/tenants/{tenant_id}/providers/{provider_id}"
                    )
                    response.raise_for_status()
                    return response.json()
            except httpx.HTTPStatusError as exc:
                raise HTTPException(status_code=exc.response.status_code, detail=exc.response.text)
            except Exception as exc:
                raise HTTPException(status_code=500, detail=f"Provider deletion failed: {str(exc)}")

        # STANDALONE mode: use local database
        if not _db:
            raise HTTPException(
                status_code=500,
                detail="Database not configured. Provider deletion requires AuthDatabase.",
            )

        tenant_id = claims.get("tenant_id")
        actor_id = claims.get("sub")
        actor_id_int = int(actor_id) if actor_id is not None and str(actor_id).isdigit() else None
        if not tenant_id:
            raise HTTPException(status_code=401, detail="Invalid JWT: missing tenant_id")

        # Verify provider exists and belongs to tenant
        existing = await _db.get_provider(provider_id)
        if not existing or existing.tenant_id != int(tenant_id):
            raise HTTPException(status_code=404, detail="Provider not found")

        await _db.delete_provider(provider_id, updated_by=actor_id_int)

        return DeleteProviderResponse(
            success=True,
            provider_id=provider_id,
            provider_name=existing.provider_name,
            message="Provider deleted successfully",
        )



    @router.post("/idp-tokens")
    async def get_idp_tokens(body: IdpTokensRequest):
        """
        Get IDP tokens from the current session (STANDALONE mode).
        
        This endpoint allows apps to retrieve the raw IDP tokens (access_token, 
        refresh_token, id_token) for making direct API calls to the IDP's services 
        (e.g., Microsoft Graph, Google APIs).
        
        **Security:** 
        - Requires valid JWT token in request body
        - Only returns tokens for the authenticated session
        - Auto-refreshes expired IDP access tokens
        
        **Usage:**
        ```json
        POST /auth/idp-tokens
        {
            "jwt_token": "<your_jwt>",
            "json_path": "access_token"  // optional
        }
        ```
        
        **Response:**
        - Full IDP tokens object: `{access_token, refresh_token, id_token, expires_at, ...}`
        - Or specific field if json_path is provided
        
        **Use Cases:**
        - Call Microsoft Graph API with IDP access_token
        - Call Google APIs (Drive, Calendar, etc.) with IDP access_token
        - Verify user identity with id_token claims
        """
        if config.mode != OAuthMode.STANDALONE:
            raise HTTPException(
                status_code=501,
                detail="IDP tokens endpoint only available in STANDALONE mode. "
                       "In PLATFORM mode, use GET /auth/idp-tokens with Authorization header."
            )
        
        if not _db:
            raise HTTPException(
                status_code=500,
                detail="Database not configured. IDP tokens are stored in the database."
            )
        
        try:
            client = await _get_client()

            # Auto-refresh IDP access token if expiring
            await client.get_idp_access_token(body.jwt_token)

            from ..jwt_wrapper import JWTWrapper
            jwt_wrapper = JWTWrapper(config)
            claims = jwt_wrapper.decode_claims(body.jwt_token)

            if config.mode == OAuthMode.STANDALONE:
                if _auth_engine is None:
                    raise HTTPException(status_code=500, detail="Authorization engine not configured")
                user_id = claims.get("sub")
                tenant_id = claims.get("tenant_id")
                app_id = claims.get("app_id")
                if not all([user_id, tenant_id, app_id]):
                    raise HTTPException(
                        status_code=403,
                        detail="Missing required claims in JWT (user_id, tenant_id, app_id)",
                    )
                allowed, reason, _ = await _auth_engine.can_user_perform(
                    user_id=int(user_id) if isinstance(user_id, str) else user_id,
                    tenant_id=int(tenant_id) if isinstance(tenant_id, str) else tenant_id,
                    app_id=int(app_id) if isinstance(app_id, str) else app_id,
                    resource_path="/api/auth/idp-tokens",
                    action_name="execute",
                )
                if not allowed:
                    raise HTTPException(status_code=403, detail=f"Permission denied: {reason}")

            session_id = claims.get("session_id")
            
            if not session_id:
                raise HTTPException(status_code=400, detail="No session_id in JWT claims")
            
            session = await _db.get_session(session_id)
            if not session:
                raise HTTPException(status_code=404, detail="Session not found")
            
            if session.is_revoked:
                raise HTTPException(status_code=401, detail="Session has been revoked")
            
            idp_tokens = session.tokens.get("idp", {})
            if not idp_tokens:
                raise HTTPException(status_code=401, detail="Invalid email or password")
            
            # Extract specific field if json_path is provided
            result_tokens = idp_tokens
            if body.json_path:
                if body.json_path in idp_tokens:
                    result_tokens = {body.json_path: idp_tokens[body.json_path]}
                else:
                    raise HTTPException(
                        status_code=404,
                        detail=f"Field '{body.json_path}' not found in IDP tokens"
                    )
            
            return {
                "session_id": session_id,
                "tenant_id": session.tenant_id,
                "provider": claims.get("provider", "unknown"),
                "tokens": result_tokens,
                "expires_at": _format_timestamp(idp_tokens.get("expires_at")),
            }
            
        except OAuthError as exc:
            raise HTTPException(status_code=401, detail=exc.message)
        except HTTPException:
            raise
        except Exception as exc:
            raise HTTPException(status_code=500, detail=str(exc))

    @router.post(
        "/initialize",
        response_model=InitializeStandaloneResponse,
        summary="Setup Tenant Configuration",
        description="""Configure tenant, identity provider, and application settings.
        
        This endpoint initializes the authentication infrastructure by:
        - Creating tenant record
        - Registering identity provider (Google/Microsoft) with OIDC auto-discovery
        - Creating application record
        - Linking application to identity provider
        - Generating RSA key pair for JWT signing
        
        All operations are idempotent and safe to call multiple times.
        After successful setup, update your OAuthConfig with the returned tenant/app/provider names.
        
        **Note:** Requires database connection. Only available in STANDALONE mode.
        """,
    )
    async def initialize_standalone(
        body: InitializeStandaloneRequest,
        claims: dict = Depends(_rbac("/api/auth/initialize", "execute")),
    ):
        """
        Initialize standalone deployment programmatically.
        Equivalent to: python seed.py --setup-standalone ...
        """
        if not _db:
            raise HTTPException(
                status_code=500,
                detail="Database not configured. Initialize endpoint requires AuthDatabase."
            )
        
        if config.mode != OAuthMode.STANDALONE:
            raise HTTPException(
                status_code=400,
                detail="Initialize endpoint is only available in STANDALONE mode"
            )
        
        try:
            # Generate RSA keys for tenant signing
            private_pem, public_pem = _generate_rsa_keys()
            
            # Initialize standalone setup
            result = await _db.initialize_standalone(
                tenant_name=body.tenant_name,
                app_name=body.app_name,
                provider_name=body.provider_name,
                issuer_url=body.issuer_url,
                client_id=body.client_id,
                client_secret=body.client_secret,
                redirect_uri=body.redirect_uri,
                public_key_pem=public_pem,
                private_key_pem=private_pem,
                tenant_description=body.tenant_description,
                domain=body.domain,
                details=body.details,
                created_by=body.created_by,
                updated_by=body.updated_by,
            )
            
            return InitializeStandaloneResponse(
                success=True,
                tenant_id=result["tenant_id"],
                tenant_name=result["tenant_name"],
                app_id=result["app_id"],
                app_name=result["app_name"],
                provider_id=result["provider_id"],
                provider_name=result["provider_name"],
                message=result["message"],
                scopes=result["scopes"],
            )
            
        except InitializationError as exc:
            raise HTTPException(status_code=400, detail=exc.message)
        except Exception as exc:
            raise HTTPException(
                status_code=500,
                detail=f"Initialization failed: {str(exc)}"
            )

    return router
