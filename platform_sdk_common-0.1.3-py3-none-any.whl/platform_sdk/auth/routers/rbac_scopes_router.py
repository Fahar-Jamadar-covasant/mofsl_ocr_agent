"""
Scope management router.

Provides CRUD operations for scopes:
- Create, read, update, delete scopes
- List scopes with filtering
"""

from typing import List, Optional
from fastapi import APIRouter, HTTPException, Query, Depends

from ..rbac_management import ScopeManagement
from ..business_entity_management import BusinessEntityManagement
from ..user_management import UserManagement
from ..interfaces import (
    ScopeRecord,
    ScopeHierarchyRecord,
    EntityNode,
    OAuthConfig,
    OAuthMode,
)


def create_rbac_scopes_router(
    config: OAuthConfig,
    scope_mgmt: Optional[ScopeManagement] = None,
    auth_dependency=None,
) -> APIRouter:
    router = APIRouter(tags=["scopes"])

    if config.mode == OAuthMode.STANDALONE and scope_mgmt is None:
        raise ValueError("scope_mgmt is required for STANDALONE mode")

    async def _enrich_scope_with_emails(scope_obj, tenant_id: int):
        """Fetch user emails for created_by and updated_by in scope records."""
        user_mgmt = UserManagement(scope_mgmt._db)
        enriched = dict(scope_obj.__dict__) if hasattr(scope_obj, '__dict__') else dict(scope_obj)

        if enriched.get('created_by'):
            try:
                user = await user_mgmt.get_user_by_id(tenant_id, enriched['created_by'])
                if user:
                    enriched['created_by_email'] = user.email
            except:
                pass

        if enriched.get('updated_by'):
            try:
                user = await user_mgmt.get_user_by_id(tenant_id, enriched['updated_by'])
                if user:
                    enriched['updated_by_email'] = user.email
            except:
                pass

        return enriched

    async def _get_parent_chain_nodes(entity_id: int) -> List[EntityNode]:
        """Fetch parent chain and build EntityNode list (root first)."""
        em = BusinessEntityManagement(scope_mgmt._db)
        parents = await em.get_parent_chain(entity_id)
        return [
            EntityNode(
                id=p['id'],
                uuid=str(p['uuid']) if p.get('uuid') else None,
                name=p['name'],
                level=p['level_name'],
                children=[]
            )
            for p in parents
        ]


    @router.get("/scopes", response_model=None)
    async def list_scopes(
        level_name: Optional[str] = Query(None, description="Filter by entity level name"),
        include_inactive: bool = Query(False),
        claims: dict = Depends(auth_dependency) if auth_dependency else None,
    ):
        """
        List all scopes for the tenant.

        When level_name is provided: returns flat List[ScopeRecord] (no hierarchy).
        Without level_name: returns full List[ScopeHierarchyRecord] with parent_chain and children.
        """
        if not claims:
            raise HTTPException(401, "Authentication required")

        tenant_id = int(claims.get("tenant_id"))

        scopes = await scope_mgmt.list_scopes(
            tenant_id=tenant_id,
            level_name=level_name,
            is_active=None if include_inactive else True
        )

        user_mgmt = UserManagement(scope_mgmt._db)

        # Flat response when level_name is provided
        if level_name:
            result = []
            for scope in scopes:
                scope_dict = {
                    'id': scope.id,
                    'uuid': scope.uuid,
                    'tenant_id': scope.tenant_id,
                    'name': scope.name,
                    'description': scope.description,
                    'entity_id': scope.entity_id,
                    'entity_uuid': scope.entity_uuid,
                    'entity_name': scope.entity_name,
                    'level_name': scope.level_name,
                    'entity_depth': scope.entity_depth,
                    'metadata': scope.metadata,
                    'is_active': scope.is_active,
                    'created_at': scope.created_at,
                    'updated_at': scope.updated_at,
                    'created_by': scope.created_by,
                    'updated_by': scope.updated_by,
                    'created_by_email': None,
                    'updated_by_email': None,
                }

                # Enrich with emails
                if scope.created_by:
                    try:
                        user = await user_mgmt.get_user_by_id(tenant_id, scope.created_by)
                        if user:
                            scope_dict['created_by_email'] = user.email
                    except:
                        pass
                if scope.updated_by:
                    try:
                        user = await user_mgmt.get_user_by_id(tenant_id, scope.updated_by)
                        if user:
                            scope_dict['updated_by_email'] = user.email
                    except:
                        pass

                result.append(ScopeRecord(**scope_dict))
            return result

        # Full hierarchy response when no level_name filter
        em = BusinessEntityManagement(scope_mgmt._db)
        result = []
        for scope in scopes:
            parent_chain = await _get_parent_chain_nodes(scope.entity_id)
            # Get children (direct descendants only, not recursive)
            children_raw = await em.list_children(scope.entity_id, recursive=False)
            children_nodes = [
                EntityNode(
                    id=c['id'],
                    uuid=str(c['uuid']) if c.get('uuid') else None,
                    name=c['name'],
                    level=c['level_name'],
                    children=[]
                )
                for c in children_raw
            ]

            # Fetch user emails
            created_by_email = None
            updated_by_email = None
            if scope.created_by:
                try:
                    user = await user_mgmt.get_user_by_id(tenant_id, scope.created_by)
                    if user:
                        created_by_email = user.email
                except:
                    pass
            if scope.updated_by:
                try:
                    user = await user_mgmt.get_user_by_id(tenant_id, scope.updated_by)
                    if user:
                        updated_by_email = user.email
                except:
                    pass

            result.append(
                ScopeHierarchyRecord(
                    scope_id=scope.id,
                    scope_uuid=scope.uuid,
                    scope_name=scope.name,
                    entity_id=scope.entity_id,
                    entity_uuid=scope.entity_uuid,
                    entity_name=scope.entity_name,
                    entity_level=scope.level_name,
                    entity_depth=scope.entity_depth or 0,
                    parent_chain=parent_chain,
                    children=children_nodes,
                    is_active=scope.is_active,
                    created_at=scope.created_at,
                    updated_at=scope.updated_at,
                    created_by=scope.created_by,
                    updated_by=scope.updated_by,
                    created_by_email=created_by_email,
                    updated_by_email=updated_by_email,
                )
            )

        return result

    @router.get("/scopes/assigned/list", response_model=List[ScopeHierarchyRecord])
    async def list_user_scopes_with_hierarchy(
        claims: dict = Depends(auth_dependency) if auth_dependency else None,
    ):
        """
        Get all scopes assigned to the current user with full hierarchy.

        Returns scopes the user has access to through group assignments,
        with parent_chain (ancestors from root to parent) for breadcrumb rendering.

        Useful for: scope/project switcher UI, listing available contexts.
        """
        if not claims:
            raise HTTPException(401, "Authentication required")

        user_id = int(claims.get("sub"))
        tenant_id = int(claims.get("tenant_id"))

        pool = scope_mgmt._db._need_pool()
        async with pool.acquire() as conn:
            query = """
                SELECT DISTINCT
                    sc.id as scope_id,
                    sc.uuid as scope_uuid,
                    sc.name as scope_name,
                    se.id as entity_id,
                    se.uuid as entity_uuid,
                    se.name as entity_name,
                    sel.name as level_name,
                    sel.depth,
                    sc.is_active,
                    sc.created_at,
                    sc.updated_at,
                    sc.created_by,
                    sc.updated_by
                FROM scopes sc
                JOIN scope_entities se ON se.id = sc.entity_id
                JOIN scope_entity_levels sel ON sel.id = se.level_id
                LEFT JOIN group_scopes gs ON gs.scope_id = sc.id
                LEFT JOIN u_groups g ON g.id = gs.group_id
                LEFT JOIN user_groups ug ON ug.group_id = g.id
                WHERE sc.tenant_id = $1
                  AND ug.user_id = $2
                  AND sc.is_active = TRUE
                ORDER BY sel.depth, se.name
            """
            rows = await conn.fetch(query, tenant_id, user_id)

        if not rows:
            return []

        em = BusinessEntityManagement(scope_mgmt._db)
        user_mgmt = UserManagement(scope_mgmt._db)
        result = []
        for r in rows:
            parent_chain = await _get_parent_chain_nodes(r['entity_id'])
            # Get children (direct descendants only)
            children_raw = await em.list_children(r['entity_id'], recursive=False)
            children_nodes = [
                EntityNode(
                    id=c['id'],
                    uuid=str(c['uuid']) if c.get('uuid') else None,
                    name=c['name'],
                    level=c['level_name'],
                    children=[]
                )
                for c in children_raw
            ]

            # Fetch user emails
            created_by_email = None
            updated_by_email = None
            if r.get('created_by'):
                try:
                    user = await user_mgmt.get_user_by_id(tenant_id, r['created_by'])
                    if user:
                        created_by_email = user.email
                except:
                    pass
            if r.get('updated_by'):
                try:
                    user = await user_mgmt.get_user_by_id(tenant_id, r['updated_by'])
                    if user:
                        updated_by_email = user.email
                except:
                    pass

            result.append(
                ScopeHierarchyRecord(
                    scope_id=r['scope_id'],
                    scope_uuid=r['scope_uuid'],
                    scope_name=r['scope_name'],
                    entity_id=r['entity_id'],
                    entity_uuid=r['entity_uuid'],
                    entity_name=r['entity_name'],
                    entity_level=r['level_name'],
                    entity_depth=r['depth'],
                    parent_chain=parent_chain,
                    children=children_nodes,
                    is_active=r['is_active'],
                    created_at=r['created_at'],
                    updated_at=r['updated_at'],
                    created_by=r.get('created_by'),
                    updated_by=r.get('updated_by'),
                    created_by_email=created_by_email,
                    updated_by_email=updated_by_email,
                )
            )

        return result

    @router.get("/scopes/{scope_id}", response_model=ScopeRecord)
    async def get_scope(
        scope_id: int,
        claims: dict = Depends(auth_dependency) if auth_dependency else None,
    ):
        if not claims:
            raise HTTPException(401, "Authentication required")

        tenant_id = int(claims.get("tenant_id"))
        scope = await scope_mgmt.get_scope(scope_id)
        if not scope:
            raise HTTPException(404, f"Scope {scope_id} not found")

        if scope.tenant_id != tenant_id:
            raise HTTPException(403, "Access denied")

        # Enrich with emails
        user_mgmt = UserManagement(scope_mgmt._db)
        scope_dict = scope.__dict__ if hasattr(scope, '__dict__') else dict(scope)

        if scope_dict.get('created_by'):
            try:
                user = await user_mgmt.get_user_by_id(tenant_id, scope_dict['created_by'])
                if user:
                    scope_dict['created_by_email'] = user.email
            except:
                pass

        if scope_dict.get('updated_by'):
            try:
                user = await user_mgmt.get_user_by_id(tenant_id, scope_dict['updated_by'])
                if user:
                    scope_dict['updated_by_email'] = user.email
            except:
                pass

        return ScopeRecord(**scope_dict)

    @router.get("/scopes/{scope_id}/hierarchy", response_model=ScopeHierarchyRecord)
    async def get_scope_hierarchy(
        scope_id: int,
        claims: dict = Depends(auth_dependency) if auth_dependency else None,
    ):
        """Get scope with full hierarchy (parent_chain with ancestors root → parent)."""
        if not claims:
            raise HTTPException(401, "Authentication required")

        tenant_id = int(claims.get("tenant_id"))
        scope = await scope_mgmt.get_scope(scope_id)
        if not scope:
            raise HTTPException(404, f"Scope {scope_id} not found")

        if scope.tenant_id != tenant_id:
            raise HTTPException(403, "Access denied")

        parent_chain = await _get_parent_chain_nodes(scope.entity_id)

        # Fetch user emails
        user_mgmt = UserManagement(scope_mgmt._db)
        created_by_email = None
        updated_by_email = None
        if scope.created_by:
            try:
                user = await user_mgmt.get_user_by_id(tenant_id, scope.created_by)
                if user:
                    created_by_email = user.email
            except:
                pass
        if scope.updated_by:
            try:
                user = await user_mgmt.get_user_by_id(tenant_id, scope.updated_by)
                if user:
                    updated_by_email = user.email
            except:
                pass

        return ScopeHierarchyRecord(
            scope_id=scope.id,
            scope_uuid=scope.uuid,
            scope_name=scope.name,
            entity_id=scope.entity_id,
            entity_uuid=scope.entity_uuid,
            entity_name=scope.entity_name,
            entity_level=scope.level_name,
            entity_depth=scope.entity_depth or 0,
            parent_chain=parent_chain,
            is_active=scope.is_active,
            created_at=scope.created_at,
            updated_at=scope.updated_at,
            created_by=scope.created_by,
            updated_by=scope.updated_by,
            created_by_email=created_by_email,
            updated_by_email=updated_by_email,
        )


    return router
