"""
Group management endpoints.

Provides CRUD operations for groups including:
- Create, read, update groups
- List groups with filtering
- Support for hierarchical groups (parent-child relationships)
- Assign and manage scopes for groups
"""

from typing import List, Optional
import httpx
from fastapi import APIRouter, HTTPException, Query, Depends

from ..user_management import UserManagement, GroupNotFoundError, UserNotFoundError
from ..authorization import AuthorizationEngine
from ..rbac_management import ScopeManagement, GroupScopeManagement
from ..interfaces import (
    GroupRecord,
    GroupDetailRecord,
    GroupCreateRequest,
    GroupUpdateRequest,
    GroupScopeAssignment,
    GroupScopeAssignRequest,
    ScopeRecord,
    RoleRecord,
    OAuthConfig,
    OAuthMode,
)


def create_groups_router(
    config: OAuthConfig,
    user_mgmt: Optional[UserManagement] = None,
    group_scope_mgmt: Optional[GroupScopeManagement] = None,
    scope_detail_mgmt: Optional[ScopeManagement] = None,
    auth_dependency = None,
) -> APIRouter:
    """
    Create groups router that works in both STANDALONE and PLATFORM modes.

    - STANDALONE mode: Uses user_mgmt to access local database directly
    - PLATFORM mode: Delegates to Platform Service via HTTP

    Args:
        config: OAuthConfig with mode and platform_oauth_url
        user_mgmt: UserManagement instance (required for STANDALONE mode)
        group_scope_mgmt: GroupScopeManagement instance for group-scope assignments (optional)
        scope_detail_mgmt: ScopeManagement instance for fetching scope details (optional)
        auth_dependency: FastAPI dependency that validates JWT and returns claims

    Returns:
        FastAPI router with group and group-scope endpoints
    """
    router = APIRouter(tags=["groups"])
    
    if config.mode == OAuthMode.STANDALONE and user_mgmt is None:
        raise ValueError("user_mgmt is required for STANDALONE mode")
    
    is_platform_mode = config.mode == OAuthMode.PLATFORM

    def _get_platform_client(claims: dict, timeout: float = 30.0):
        """Create httpx client with Authorization header for platform delegation."""
        return httpx.AsyncClient(
            base_url=config.platform_oauth_url.rstrip("/"),
            headers={"Authorization": f"Bearer {claims.get('_raw_token', '')}"},
            timeout=timeout
        )

    # Create default auth dependency if none provided
    if auth_dependency is None:
        from ..dependencies import require_auth
        auth_dependency = require_auth(config)

    auth_engine = AuthorizationEngine(user_mgmt._db) if not is_platform_mode and user_mgmt else None

    def _rbac(resource_path: str, action: str):
        async def _dep(claims: dict = Depends(auth_dependency)):
            if is_platform_mode:
                return claims

            user_id = claims.get("sub")
            tenant_id = claims.get("tenant_id")
            app_id = claims.get("app_id")
            if not all([user_id, tenant_id, app_id]):
                raise HTTPException(
                    status_code=403,
                    detail="Missing required claims in JWT (user_id, tenant_id, app_id)",
                )

            allowed, reason, policy = await auth_engine.can_user_perform(
                user_id=int(user_id) if isinstance(user_id, str) else user_id,
                tenant_id=int(tenant_id) if isinstance(tenant_id, str) else tenant_id,
                app_id=int(app_id) if isinstance(app_id, str) else app_id,
                resource_path=resource_path,
                action_name=action,
            )
            if not allowed:
                raise HTTPException(status_code=403, detail=f"Permission denied: {reason}")

            claims["_rbac_check"] = {
                "resource": resource_path,
                "action": action,
                "allowed": True,
                "reason": reason,
                "policy_id": policy.get("id") if policy else None,
            }
            return claims

        return _dep

    async def _build_group_detail(group_id: int, tenant_id: int) -> GroupDetailRecord:
        """Build enriched group response with assigned scopes and roles."""
        group = await user_mgmt.get_group(tenant_id, group_id)
        if not group:
            return None

        # Fetch assigned scopes
        scopes = []
        if group_scope_mgmt and scope_detail_mgmt:
            scope_assignments = await group_scope_mgmt.list_group_scopes(group_id)
            for sa in scope_assignments:
                scope = await scope_detail_mgmt.get_scope(sa.scope_id)
                if scope:
                    scopes.append(scope)

        # Fetch assigned roles
        roles = []
        role_rows = await user_mgmt.list_group_roles(group_id)
        for r in role_rows:
            roles.append(RoleRecord(**r))

        return GroupDetailRecord(**group.model_dump(), scopes=scopes, roles=roles)

    @router.post("/groups", response_model=GroupDetailRecord, status_code=201)
    async def create_group(
        group: GroupCreateRequest,
        claims: dict = Depends(_rbac("/api/auth/groups", "create")),
    ):
        """Create a new group."""
        tenant_id = claims.get("tenant_id")
        actor_id = claims.get("sub")
        if not tenant_id:
            raise HTTPException(status_code=401, detail="tenant_id not found in JWT")
        if not actor_id:
            raise HTTPException(status_code=401, detail="User ID not found in JWT")
        
        if is_platform_mode:
            async with _get_platform_client(claims) as client:
                response = await client.post(
                    f"/api/v1/admin/tenants/{tenant_id}/groups",
                    json=group.model_dump(),
                                    )
                response.raise_for_status()
                return GroupRecord(**response.json())
        else:
            try:
                # Check for duplicate group name in tenant
                pool = user_mgmt._db._need_pool()
                async with pool.acquire() as conn:
                    existing = await conn.fetchval(
                        "SELECT id FROM u_groups WHERE tenant_id = $1 AND name = $2 AND is_active = TRUE",
                        int(tenant_id), group.group_name
                    )
                if existing:
                    raise HTTPException(status_code=409, detail=f"A group named '{group.group_name}' already exists")

                # Enforce one-role-per-group constraint
                if group.role_ids and len(group.role_ids) > 1:
                    raise HTTPException(status_code=409, detail="A group can only have one role assigned")

                # Create group
                created_group = await user_mgmt.create_group(
                    tenant_id=tenant_id,
                    group_name=group.group_name,
                    parent_group_id=group.parent_group_id,
                    description=group.description,
                    is_default=group.is_default,
                    created_by=int(actor_id) if isinstance(actor_id, str) else actor_id,
                )

                # Assign scopes if provided
                if group.scope_ids and group_scope_mgmt:
                    for scope_id in group.scope_ids:
                        await group_scope_mgmt.assign_scope_to_group(
                            tenant_id=tenant_id,
                            group_id=created_group.id,
                            scope_id=scope_id,
                            assigned_by=int(actor_id) if isinstance(actor_id, str) else actor_id,
                        )

                # Assign roles if provided
                if group.role_ids:
                    for role_id in group.role_ids:
                        await user_mgmt.assign_role_to_group(
                            tenant_id=tenant_id,
                            group_id=created_group.id,
                            role_id=role_id,
                            assigned_by=int(actor_id) if isinstance(actor_id, str) else actor_id,
                        )

                # Return enriched response with scopes and roles
                return await _build_group_detail(created_group.id, tenant_id)
            except HTTPException:
                raise
            except GroupNotFoundError as exc:
                raise HTTPException(status_code=404, detail=str(exc))
            except Exception as exc:
                raise HTTPException(status_code=400, detail=str(exc))
    
    @router.get("/groups/{group_id}", response_model=GroupDetailRecord)
    async def get_group(
        group_id: int,
        claims: dict = Depends(_rbac("/api/auth/groups/*", "read")),
    ):
        """Get group by ID with assigned scopes and roles."""
        tenant_id = claims.get("tenant_id")
        if not tenant_id:
            raise HTTPException(status_code=401, detail="tenant_id not found in JWT")

        if is_platform_mode:
            async with _get_platform_client(claims) as client:
                response = await client.get(
                    f"/api/v1/admin/tenants/{tenant_id}/groups/{group_id}",
                                    )
                if response.status_code == 404:
                    raise HTTPException(status_code=404, detail=f"Group {group_id} not found")
                response.raise_for_status()
                return GroupRecord(**response.json())
        else:
            group = await user_mgmt.get_group(tenant_id, group_id)
            if not group:
                raise HTTPException(status_code=404, detail=f"Group {group_id} not found")
            return await _build_group_detail(group_id, tenant_id)
    
    @router.get("/groups", response_model=List[dict])
    async def list_groups(
        is_active: Optional[bool] = Query(None, description="Filter by active status"),
        parent_group_id: Optional[int] = Query(None, description="Filter by parent group"),
        claims: dict = Depends(_rbac("/api/auth/groups", "read")),
    ):
        """List groups with user count and simplified scope/role details."""
        tenant_id = claims.get("tenant_id")
        if not tenant_id:
            raise HTTPException(status_code=401, detail="tenant_id not found in JWT")

        if is_platform_mode:
            params = {}
            if is_active is not None:
                params["is_active"] = is_active
            if parent_group_id is not None:
                params["parent_group_id"] = parent_group_id
            async with _get_platform_client(claims) as client:
                response = await client.get(
                    f"/api/v1/admin/tenants/{tenant_id}/groups",
                    params=params,
                )
                response.raise_for_status()
                return response.json()
        else:
            groups = await user_mgmt.list_groups(
                tenant_id=tenant_id,
                is_active=is_active,
                parent_group_id=parent_group_id
            )
            if not groups:
                return []

            # Batch fetch user counts for all groups in one query
            group_ids = [g.id for g in groups]
            pool = user_mgmt._db._need_pool()
            async with pool.acquire() as conn:
                count_rows = await conn.fetch(
                    "SELECT group_id, COUNT(*) AS cnt FROM user_groups WHERE group_id = ANY($1::int[]) GROUP BY group_id",
                    group_ids
                )
            user_counts = {r["group_id"]: r["cnt"] for r in count_rows}

            result = []
            for g in groups:
                group_dict = g.model_dump()
                group_dict["user_count"] = user_counts.get(g.id, 0)

                # Slim scopes: id, name, entity_name, level_name only
                scopes_slim = []
                if group_scope_mgmt and scope_detail_mgmt:
                    scope_assignments = await group_scope_mgmt.list_group_scopes(g.id)
                    for sa in scope_assignments:
                        scope = await scope_detail_mgmt.get_scope(sa.scope_id)
                        if scope:
                            scopes_slim.append({
                                "id": scope.id,
                                "name": scope.name,
                                "entity_name": scope.entity_name,
                                "level_name": scope.level_name,
                            })
                group_dict["scopes"] = scopes_slim

                # Slim roles: id, role_name only
                role_rows = await user_mgmt.list_group_roles(g.id)
                group_dict["roles"] = [{"id": r["id"], "role_name": r["role_name"]} for r in role_rows]

                result.append(group_dict)

            return result
    
    @router.patch("/groups/{group_id}", response_model=GroupDetailRecord)
    async def update_group(
        group_id: int,
        update: GroupUpdateRequest,
        claims: dict = Depends(_rbac("/api/auth/groups/*", "update")),
    ):
        """Update group and optionally replace assigned scopes/roles."""
        tenant_id = claims.get("tenant_id")
        actor_id = claims.get("sub")
        if not tenant_id:
            raise HTTPException(status_code=401, detail="tenant_id not found in JWT")
        if not actor_id:
            raise HTTPException(status_code=401, detail="User ID not found in JWT")

        if is_platform_mode:
            async with _get_platform_client(claims) as client:
                response = await client.patch(
                    f"/api/v1/admin/tenants/{tenant_id}/groups/{group_id}",
                    json=update.model_dump(exclude_none=True),
                                    )
                if response.status_code == 404:
                    raise HTTPException(status_code=404, detail=f"Group {group_id} not found")
                response.raise_for_status()
                return GroupRecord(**response.json())
        else:
            try:
                # Update group fields
                updated_group = await user_mgmt.update_group(
                    tenant_id=tenant_id,
                    group_id=group_id,
                    group_name=update.group_name,
                    parent_group_id=update.parent_group_id,
                    description=update.description,
                    is_active=update.is_active,
                    is_default=update.is_default,
                    updated_by=int(actor_id) if isinstance(actor_id, str) else actor_id,
                )

                # Replace scopes if scope_ids is provided (not None)
                if update.scope_ids is not None and group_scope_mgmt:
                    pool = user_mgmt._db._need_pool()
                    async with pool.acquire() as conn:
                        await conn.execute("DELETE FROM group_scopes WHERE group_id = $1", group_id)

                    for scope_id in update.scope_ids:
                        await group_scope_mgmt.assign_scope_to_group(
                            tenant_id=tenant_id,
                            group_id=group_id,
                            scope_id=scope_id,
                            assigned_by=int(actor_id) if isinstance(actor_id, str) else actor_id,
                        )

                # Replace roles if role_ids is provided (not None)
                if update.role_ids is not None:
                    if len(update.role_ids) > 1:
                        raise HTTPException(status_code=409, detail="A group can only have one role assigned")

                    pool = user_mgmt._db._need_pool()
                    async with pool.acquire() as conn:
                        await conn.execute("DELETE FROM group_roles WHERE group_id = $1", group_id)

                    for role_id in update.role_ids:
                        await user_mgmt.assign_role_to_group(
                            tenant_id=tenant_id,
                            group_id=group_id,
                            role_id=role_id,
                            assigned_by=int(actor_id) if isinstance(actor_id, str) else actor_id,
                        )

                # Return enriched response
                return await _build_group_detail(group_id, tenant_id)
            except HTTPException:
                raise
            except GroupNotFoundError as exc:
                raise HTTPException(status_code=404, detail=str(exc))
            except Exception as exc:
                raise HTTPException(status_code=400, detail=str(exc))

    @router.delete("/groups/{group_id}")
    async def delete_group(
        group_id: int,
        claims: dict = Depends(_rbac("/api/auth/groups/*", "delete")),
    ):
        """Delete group with detailed warnings about impact."""
        tenant_id = claims.get("tenant_id")
        actor_id = claims.get("sub")
        if not tenant_id:
            raise HTTPException(status_code=401, detail="tenant_id not found in JWT")
        if not actor_id:
            raise HTTPException(status_code=401, detail="User ID not found in JWT")
        
        if is_platform_mode:
            async with _get_platform_client(claims) as client:
                response = await client.delete(
                    f"/api/v1/admin/tenants/{tenant_id}/groups/{group_id}",
                                    )
                if response.status_code == 404:
                    raise HTTPException(status_code=404, detail=f"Group {group_id} not found")
                response.raise_for_status()
                return response.json()
        else:
            try:
                return await user_mgmt.delete_group(
                    tenant_id=tenant_id,
                    group_id=group_id,
                    updated_by=int(actor_id) if isinstance(actor_id, str) else actor_id,
                )
            except GroupNotFoundError as exc:
                raise HTTPException(status_code=404, detail=str(exc))
            except Exception as exc:
                raise HTTPException(status_code=400, detail=str(exc))
    
    # ========================================
    # SELF-SERVICE ENDPOINTS (/me)
    # ========================================
    
    @router.get("/groups/me", response_model=List[GroupRecord])
    async def get_my_groups(
        claims: dict = Depends(_rbac("/api/auth/groups/me", "read")),
    ):
        """Get groups current user belongs to."""
        user_id = claims.get("sub")
        tenant_id = claims.get("tenant_id")
        
        if not user_id:
            raise HTTPException(status_code=401, detail="User ID not found in JWT")
        if not tenant_id:
            raise HTTPException(status_code=401, detail="Tenant ID not found in JWT")
        
        if is_platform_mode:
            async with _get_platform_client(claims) as client:
                response = await client.get(
                    f"/api/v1/admin/tenants/{tenant_id}/users/{user_id}/groups",
                                    )
                if response.status_code == 404:
                    raise HTTPException(status_code=404, detail="User not found")
                response.raise_for_status()
                return [GroupRecord(**g) for g in response.json()]
        else:
            try:
                return await user_mgmt.get_user_groups(tenant_id, user_id)
            except UserNotFoundError as exc:
                raise HTTPException(status_code=404, detail=str(exc))

    # ========================================
    # GROUP-SCOPE ASSIGNMENT ENDPOINTS
    # ========================================

    @router.post("/groups/{group_id}/scopes", response_model=GroupScopeAssignment, status_code=201)
    async def assign_scope_to_group(
        group_id: int,
        req: GroupScopeAssignRequest,
        claims: dict = Depends(auth_dependency),
    ):
        """Assign a scope to a group."""
        if not claims:
            raise HTTPException(401, "Authentication required")

        if not is_platform_mode and group_scope_mgmt is None:
            raise HTTPException(501, "Scope management not available")

        tenant_id = int(claims.get("tenant_id"))
        user_id = int(claims.get("sub"))

        if is_platform_mode:
            async with _get_platform_client(claims) as client:
                response = await client.post(
                    f"/api/v1/admin/tenants/{tenant_id}/groups/{group_id}/scopes",
                    json=req.model_dump(),
                )
                if response.status_code == 404:
                    raise HTTPException(404, "Group or scope not found")
                response.raise_for_status()
                return GroupScopeAssignment(**response.json())
        else:
            try:
                return await group_scope_mgmt.assign_scope_to_group(
                    tenant_id=tenant_id,
                    group_id=group_id,
                    scope_id=req.scope_id,
                    assigned_by=user_id,
                )
            except Exception as e:
                raise HTTPException(400, str(e))

    @router.get("/groups/{group_id}/scopes", response_model=List[GroupScopeAssignment])
    async def list_group_scopes(
        group_id: int,
        claims: dict = Depends(auth_dependency),
    ):
        """List scopes assigned to a group."""
        if not claims:
            raise HTTPException(401, "Authentication required")

        if not is_platform_mode and group_scope_mgmt is None:
            raise HTTPException(501, "Scope management not available")

        tenant_id = int(claims.get("tenant_id"))

        if is_platform_mode:
            async with _get_platform_client(claims) as client:
                response = await client.get(
                    f"/api/v1/admin/tenants/{tenant_id}/groups/{group_id}/scopes",
                )
                if response.status_code == 404:
                    raise HTTPException(404, "Group not found")
                response.raise_for_status()
                return [GroupScopeAssignment(**item) for item in response.json()]
        else:
            return await group_scope_mgmt.list_group_scopes(group_id=group_id)

    @router.delete("/groups/{group_id}/scopes/{scope_id}", status_code=204)
    async def remove_scope_from_group(
        group_id: int,
        scope_id: int,
        claims: dict = Depends(auth_dependency),
    ):
        """Remove a scope from a group."""
        if not claims:
            raise HTTPException(401, "Authentication required")

        if not is_platform_mode and group_scope_mgmt is None:
            raise HTTPException(501, "Scope management not available")

        if is_platform_mode:
            async with _get_platform_client(claims) as client:
                response = await client.delete(
                    f"/api/v1/admin/tenants/{int(claims.get('tenant_id'))}/groups/{group_id}/scopes/{scope_id}",
                )
                if response.status_code == 404:
                    raise HTTPException(404, "Group or scope assignment not found")
                response.raise_for_status()
                return None
        else:
            deleted = await group_scope_mgmt.remove_scope_from_group(
                group_id=group_id,
                scope_id=scope_id,
            )
            if not deleted:
                raise HTTPException(404, "Group-scope assignment not found")
            return None

    return router
