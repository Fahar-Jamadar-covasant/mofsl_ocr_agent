"""
RBAC Resources and Resource Groups management endpoints.
"""

from typing import List, Optional
from fastapi import APIRouter, HTTPException, Depends
import httpx

from ..rbac_management import ResourceManagement, RBACManagementError
from ..authorization import AuthorizationEngine
from ..interfaces import (
    ResourceRecord,
    ResourceGroupRecord,
    OAuthConfig,
    ResourceGroupCreateRequest,
    ResourceGroupUpdateRequest,
    ResourceCreateRequest,
    ResourceUpdateRequest,
)


def create_rbac_resources_router(
    config: OAuthConfig,
    resource_mgmt: Optional[ResourceManagement] = None,
    auth_dependency = None,
) -> APIRouter:
    """
    Create RBAC resources router.
    
    Provides CRUD operations for:
    - Resource Groups (logical groupings)
    - Resources (exact paths or patterns)
    
    Supports both standalone and platform modes:
    - Standalone: Uses local ResourceManagement
    - Platform: Delegates to platform service via HTTP
    """
    router = APIRouter(tags=["rbac-resources"])
    
    # Determine mode
    is_standalone = resource_mgmt is not None
    # Use unified platform URL format

    def _get_platform_client(claims: dict, timeout: float = 30.0):
        """Create httpx client with Authorization header for platform delegation."""
        return httpx.AsyncClient(
            base_url=config.platform_oauth_url.rstrip("/"),
            headers={"Authorization": f"Bearer {claims.get('_raw_token', '')}"},
            timeout=timeout
        )

    # Create default auth dependency if none provided
    if auth_dependency is None:
        from ..dependencies import require_auth
        auth_dependency = require_auth(config)

    auth_engine = AuthorizationEngine(resource_mgmt._db) if is_standalone and resource_mgmt else None

    def _rbac(resource_path: str, action: str):
        async def _dep(claims: dict = Depends(auth_dependency)):
            if not is_standalone:
                return claims

            user_id = claims.get("sub")
            tenant_id = claims.get("tenant_id")
            app_id = claims.get("app_id")
            if not all([user_id, tenant_id, app_id]):
                raise HTTPException(
                    status_code=403,
                    detail="Missing required claims in JWT (user_id, tenant_id, app_id)",
                )

            allowed, reason, policy = await auth_engine.can_user_perform(
                user_id=int(user_id) if isinstance(user_id, str) else user_id,
                tenant_id=int(tenant_id) if isinstance(tenant_id, str) else tenant_id,
                app_id=int(app_id) if isinstance(app_id, str) else app_id,
                resource_path=resource_path,
                action_name=action,
            )
            if not allowed:
                raise HTTPException(status_code=403, detail=f"Permission denied: {reason}")

            claims["_rbac_check"] = {
                "resource": resource_path,
                "action": action,
                "allowed": True,
                "reason": reason,
                "policy_id": policy.get("id") if policy else None,
            }
            return claims

        return _dep
    
    # ========================================
    # RESOURCE GROUPS
    # ========================================
    
    @router.post("/rbac/resource-groups", response_model=ResourceGroupRecord, status_code=201)
    async def create_resource_group(
        body: ResourceGroupCreateRequest,
        claims: dict = Depends(_rbac("/api/auth/rbac/resource-groups", "create")),
    ):
        """Create a resource group."""
        if is_standalone:
            app_id = claims.get("app_id")
            user_id = claims.get("sub")
            
            if not app_id:
                raise HTTPException(status_code=401, detail="app_id not found in JWT")
            if not user_id:
                raise HTTPException(status_code=401, detail="User ID not found in JWT")
            
            try:
                # Check for duplicate resource group name for this app
                pool = resource_mgmt._db._need_pool()
                async with pool.acquire() as conn:
                    existing = await conn.fetchval(
                        "SELECT id FROM resource_groups WHERE app_id = $1 AND name = $2 AND is_active = TRUE",
                        int(app_id), body.name
                    )
                if existing:
                    raise HTTPException(status_code=409, detail=f"A resource group named '{body.name}' already exists")

                return await resource_mgmt.create_resource_group(
                    app_id=int(app_id),
                    name=body.name,
                    display_name=body.display_name,
                    description=body.description,
                    metadata=body.metadata,
                    created_by=int(user_id) if isinstance(user_id, str) else user_id,
                )
            except HTTPException:
                raise
            except Exception as exc:
                raise HTTPException(status_code=400, detail=str(exc))
        else:
            # Platform mode: delegate to platform service
            async with _get_platform_client(claims) as client:
                resp = await client.post(
                    "/api/v1/admin/rbac/resource-groups",
                    json=body.dict(),
                )
                if resp.status_code != 201:
                    raise HTTPException(status_code=resp.status_code, detail=resp.text)
                return ResourceGroupRecord(**resp.json())
    
    @router.get("/rbac/resource-groups/{group_id}", response_model=ResourceGroupRecord)
    async def get_resource_group(
        group_id: int,
        claims: dict = Depends(_rbac("/api/auth/rbac/resource-groups/*", "read")),
    ):
        """Get resource group by ID."""
        if is_standalone:
            app_id = claims.get("app_id")
            if not app_id:
                raise HTTPException(status_code=401, detail="app_id not found in JWT")
            
            group = await resource_mgmt.get_resource_group(int(app_id), group_id)
            if not group:
                raise HTTPException(status_code=404, detail=f"Resource group {group_id} not found")
            return group
        else:
            async with _get_platform_client(claims) as client:
                resp = await client.get(
                    f"/api/v1/admin/rbac/resource-groups/{group_id}",
                )
                if resp.status_code != 200:
                    raise HTTPException(status_code=resp.status_code, detail=resp.text)
                return ResourceGroupRecord(**resp.json())
    
    @router.get("/rbac/resource-groups", response_model=List[ResourceGroupRecord])
    async def list_resource_groups(
        is_active: Optional[bool] = None,
        claims: dict = Depends(_rbac("/api/auth/rbac/resource-groups", "read")),
    ):
        """List resource groups."""
        if is_standalone:
            app_id = claims.get("app_id")
            if not app_id:
                raise HTTPException(status_code=401, detail="app_id not found in JWT")
            
            return await resource_mgmt.list_resource_groups(
                app_id=int(app_id),
                is_active=is_active
            )
        else:
            params = {}
            if is_active is not None:
                params["is_active"] = is_active
            async with _get_platform_client(claims) as client:
                resp = await client.get(
                    "/api/v1/admin/rbac/resource-groups",
                    params=params,
                )
                if resp.status_code != 200:
                    raise HTTPException(status_code=resp.status_code, detail=resp.text)
                return [ResourceGroupRecord(**item) for item in resp.json()]
    
    @router.patch("/rbac/resource-groups/{group_id}", response_model=ResourceGroupRecord)
    async def update_resource_group(
        group_id: int,
        body: ResourceGroupUpdateRequest,
        claims: dict = Depends(_rbac("/api/auth/rbac/resource-groups/*", "update")),
    ):
        """Update resource group."""
        if is_standalone:
            app_id = claims.get("app_id")
            user_id = claims.get("sub")
            
            if not app_id:
                raise HTTPException(status_code=401, detail="app_id not found in JWT")
            if not user_id:
                raise HTTPException(status_code=401, detail="User ID not found in JWT")
            
            try:
                return await resource_mgmt.update_resource_group(
                    app_id=int(app_id),
                    group_id=group_id,
                    display_name=body.display_name,
                    description=body.description,
                    metadata=body.metadata,
                    is_active=body.is_active,
                    updated_by=int(user_id) if isinstance(user_id, str) else user_id,
                )
            except RBACManagementError as exc:
                raise HTTPException(status_code=404, detail=str(exc))
            except Exception as exc:
                raise HTTPException(status_code=400, detail=str(exc))
        else:
            async with _get_platform_client(claims) as client:
                resp = await client.patch(
                    f"/api/v1/admin/rbac/resource-groups/{group_id}",
                    json=body.dict(exclude_unset=True),
                )
                if resp.status_code != 200:
                    raise HTTPException(status_code=resp.status_code, detail=resp.text)
                return ResourceGroupRecord(**resp.json())
    
    @router.delete("/rbac/resource-groups/{group_id}", status_code=204)
    async def delete_resource_group(
        group_id: int,
        claims: dict = Depends(_rbac("/api/auth/rbac/resource-groups/*", "delete")),
    ):
        """Delete resource group (soft delete)."""
        if is_standalone:
            app_id = claims.get("app_id")
            user_id = claims.get("sub")
            if not app_id:
                raise HTTPException(status_code=401, detail="app_id not found in JWT")
            if not user_id:
                raise HTTPException(status_code=401, detail="User ID not found in JWT")
            
            await resource_mgmt.delete_resource_group(
                int(app_id),
                group_id,
                updated_by=int(user_id) if isinstance(user_id, str) else user_id,
            )
        else:
            async with _get_platform_client(claims) as client:
                resp = await client.delete(
                    f"/api/v1/admin/rbac/resource-groups/{group_id}",
                )
                if resp.status_code != 204:
                    raise HTTPException(status_code=resp.status_code, detail=resp.text)
    
    # ========================================
    # RESOURCES
    # ========================================
    
    @router.post("/rbac/resources", response_model=ResourceRecord, status_code=201)
    async def create_resource(
        body: ResourceCreateRequest,
        claims: dict = Depends(_rbac("/api/auth/rbac/resources", "create")),
    ):
        """Create a resource (exact or pattern-based)."""
        if is_standalone:
            app_id = claims.get("app_id")
            user_id = claims.get("sub")
            
            if not app_id:
                raise HTTPException(status_code=401, detail="app_id not found in JWT")
            if not user_id:
                raise HTTPException(status_code=401, detail="User ID not found in JWT")
            
            try:
                # Check for duplicate resource name for this app
                pool = resource_mgmt._db._need_pool()
                async with pool.acquire() as conn:
                    existing = await conn.fetchval(
                        "SELECT id FROM resources WHERE app_id = $1 AND name = $2 AND is_active = TRUE",
                        int(app_id), body.name
                    )
                if existing:
                    raise HTTPException(status_code=409, detail=f"A resource named '{body.name}' already exists")

                return await resource_mgmt.create_resource(
                    app_id=int(app_id),
                    name=body.name,
                    pattern=body.pattern,
                    is_pattern=body.is_pattern,
                    resource_group_id=body.resource_group_id,
                    display_name=body.display_name,
                    description=body.description,
                    metadata=body.metadata,
                    created_by=int(user_id) if isinstance(user_id, str) else user_id,
                )
            except HTTPException:
                raise
            except Exception as exc:
                raise HTTPException(status_code=400, detail=str(exc))
        else:
            async with _get_platform_client(claims) as client:
                resp = await client.post(
                    "/api/v1/admin/rbac/resources",
                    json=body.dict(),
                )
                if resp.status_code != 201:
                    raise HTTPException(status_code=resp.status_code, detail=resp.text)
                return ResourceRecord(**resp.json())
    
    @router.get("/rbac/resources/{resource_id}", response_model=ResourceRecord)
    async def get_resource(
        resource_id: int,
        claims: dict = Depends(_rbac("/api/auth/rbac/resources/*", "read")),
    ):
        """Get resource by ID."""
        if is_standalone:
            app_id = claims.get("app_id")
            if not app_id:
                raise HTTPException(status_code=401, detail="app_id not found in JWT")
            
            resource = await resource_mgmt.get_resource(int(app_id), resource_id)
            if not resource:
                raise HTTPException(status_code=404, detail=f"Resource {resource_id} not found")
            return resource
        else:
            async with _get_platform_client(claims) as client:
                resp = await client.get(
                    f"/api/v1/admin/rbac/resources/{resource_id}",
                )
                if resp.status_code != 200:
                    raise HTTPException(status_code=resp.status_code, detail=resp.text)
                return ResourceRecord(**resp.json())
    
    @router.get("/rbac/resources", response_model=List[ResourceRecord])
    async def list_resources(
        resource_group_id: Optional[int] = None,
        is_pattern: Optional[bool] = None,
        is_active: Optional[bool] = None,
        claims: dict = Depends(_rbac("/api/auth/rbac/resources", "read")),
    ):
        """List resources."""
        if is_standalone:
            app_id = claims.get("app_id")
            if not app_id:
                raise HTTPException(status_code=401, detail="app_id not found in JWT")
            
            return await resource_mgmt.list_resources(
                app_id=int(app_id),
                resource_group_id=resource_group_id,
                is_pattern=is_pattern,
                is_active=is_active
            )
        else:
            params = {}
            if resource_group_id is not None:
                params["resource_group_id"] = resource_group_id
            if is_pattern is not None:
                params["is_pattern"] = is_pattern
            if is_active is not None:
                params["is_active"] = is_active
            async with _get_platform_client(claims) as client:
                resp = await client.get(
                    "/api/v1/admin/rbac/resources",
                    params=params,
                )
                if resp.status_code != 200:
                    raise HTTPException(status_code=resp.status_code, detail=resp.text)
                return [ResourceRecord(**item) for item in resp.json()]
    
    @router.patch("/rbac/resources/{resource_id}", response_model=ResourceRecord)
    async def update_resource(
        resource_id: int,
        body: ResourceUpdateRequest,
        claims: dict = Depends(_rbac("/api/auth/rbac/resources/*", "update")),
    ):
        """Update resource."""
        if is_standalone:
            app_id = claims.get("app_id")
            user_id = claims.get("sub")
            
            if not app_id:
                raise HTTPException(status_code=401, detail="app_id not found in JWT")
            if not user_id:
                raise HTTPException(status_code=401, detail="User ID not found in JWT")
            
            try:
                return await resource_mgmt.update_resource(
                    app_id=int(app_id),
                    resource_id=resource_id,
                    pattern=body.pattern,
                    display_name=body.display_name,
                    description=body.description,
                    metadata=body.metadata,
                    is_active=body.is_active,
                    updated_by=int(user_id) if isinstance(user_id, str) else user_id,
                )
            except RBACManagementError as exc:
                raise HTTPException(status_code=404, detail=str(exc))
            except Exception as exc:
                raise HTTPException(status_code=400, detail=str(exc))
        else:
            async with _get_platform_client(claims) as client:
                resp = await client.patch(
                    f"/api/v1/admin/rbac/resources/{resource_id}",
                    json=body.dict(exclude_unset=True),
                )
                if resp.status_code != 200:
                    raise HTTPException(status_code=resp.status_code, detail=resp.text)
                return ResourceRecord(**resp.json())
    
    @router.delete("/rbac/resources/{resource_id}", status_code=204)
    async def delete_resource(
        resource_id: int,
        claims: dict = Depends(_rbac("/api/auth/rbac/resources/*", "delete")),
    ):
        """Delete resource (soft delete)."""
        if is_standalone:
            app_id = claims.get("app_id")
            user_id = claims.get("sub")
            if not app_id:
                raise HTTPException(status_code=401, detail="app_id not found in JWT")
            if not user_id:
                raise HTTPException(status_code=401, detail="User ID not found in JWT")
            
            await resource_mgmt.delete_resource(
                int(app_id),
                resource_id,
                updated_by=int(user_id) if isinstance(user_id, str) else user_id,
            )
        else:
            async with _get_platform_client(claims) as client:
                resp = await client.delete(
                    f"/api/v1/admin/rbac/resources/{resource_id}",
                )
                if resp.status_code != 204:
                    raise HTTPException(status_code=resp.status_code, detail=resp.text)
    
    return router
