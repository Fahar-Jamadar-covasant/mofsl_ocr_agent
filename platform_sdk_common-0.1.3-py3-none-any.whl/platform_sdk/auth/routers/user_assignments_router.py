"""
User assignment endpoints for managing user-group and group-role relationships.

Extracted from groups_router.py and roles_router.py to create a dedicated,
clean router focused solely on assignment operations.

Provides operations for:
- Assign/remove users to/from groups
- Assign/remove roles to/from groups

Supports both STANDALONE and PLATFORM modes with proper delegation.
"""

from typing import Optional
import httpx
from fastapi import APIRouter, HTTPException, Depends

from ..user_management import UserManagement, UserNotFoundError, GroupNotFoundError, RoleNotFoundError
from ..authorization import AuthorizationEngine
from ..interfaces import (
    UserGroupAssignRequest,
    GroupRoleAssignRequest,
    OAuthConfig,
    OAuthMode,
)


def create_user_assignments_router(
    config: OAuthConfig,
    user_mgmt: Optional[UserManagement] = None,
    auth_dependency = None,
) -> APIRouter:
    """
    Create user assignments router that works in both STANDALONE and PLATFORM modes.
    
    - STANDALONE mode: Uses user_mgmt to access local database directly
    - PLATFORM mode: Delegates to Platform Service via HTTP with updated endpoints
    """
    router = APIRouter(tags=["user-assignments"])
    
    if config.mode == OAuthMode.STANDALONE and user_mgmt is None:
        raise ValueError("user_mgmt is required for STANDALONE mode")
    
    is_platform_mode = config.mode == OAuthMode.PLATFORM

    def _get_platform_client(claims: dict, timeout: float = 30.0):
        """Create httpx client with Authorization header for platform delegation."""
        return httpx.AsyncClient(
            base_url=config.platform_oauth_url.rstrip("/"),
            headers={"Authorization": f"Bearer {claims.get('_raw_token', '')}"},
            timeout=timeout
        )

    # Create default auth dependency if none provided
    if auth_dependency is None:
        from ..dependencies import require_auth
        auth_dependency = require_auth(config)

    auth_engine = AuthorizationEngine(user_mgmt._db) if not is_platform_mode and user_mgmt else None

    def _rbac(resource_path: str, action: str):
        async def _dep(claims: dict = Depends(auth_dependency)):
            if is_platform_mode:
                return claims

            user_id = claims.get("sub")
            tenant_id = claims.get("tenant_id")
            app_id = claims.get("app_id")
            if not all([user_id, tenant_id, app_id]):
                raise HTTPException(
                    status_code=403,
                    detail="Missing required claims in JWT (user_id, tenant_id, app_id)",
                )

            allowed, reason, policy = await auth_engine.can_user_perform(
                user_id=int(user_id) if isinstance(user_id, str) else user_id,
                tenant_id=int(tenant_id) if isinstance(tenant_id, str) else tenant_id,
                app_id=int(app_id) if isinstance(app_id, str) else app_id,
                resource_path=resource_path,
                action_name=action,
            )
            if not allowed:
                raise HTTPException(status_code=403, detail=f"Permission denied: {reason}")

            claims["_rbac_check"] = {
                "resource": resource_path,
                "action": action,
                "allowed": True,
                "reason": reason,
                "policy_id": policy.get("id") if policy else None,
            }
            return claims

        return _dep
    
    # ──────────────────────────────────────────────
    # USER-GROUP ASSIGNMENT ENDPOINTS
    # ──────────────────────────────────────────────
    
    @router.post("/user-groups", status_code=201)
    async def assign_user_to_group(
        assignment: UserGroupAssignRequest,
        claims: dict = Depends(_rbac("/api/auth/user-groups", "create")),
    ):
        """Assign a user to a group."""
        tenant_id = claims.get("tenant_id")
        actor_id = claims.get("sub")
        if not tenant_id:
            raise HTTPException(status_code=401, detail="tenant_id not found in JWT")
        if not actor_id:
            raise HTTPException(status_code=401, detail="User ID not found in JWT")
        
        if is_platform_mode:
            async with _get_platform_client(claims) as client:
                # Updated delegation URL to match platform service structure
                response = await client.post(
                    f"/api/v1/admin/tenants/{tenant_id}/user-groups",
                    json=assignment.model_dump(),
                )
                if response.status_code == 404:
                    raise HTTPException(status_code=404, detail="User or group not found")
                response.raise_for_status()
                return {"message": "User assigned to group successfully"}
        else:
            try:
                await user_mgmt.assign_user_to_group(
                    tenant_id=int(tenant_id) if isinstance(tenant_id, str) else tenant_id,
                    user_id=assignment.user_id,
                    group_id=assignment.group_id,
                    assigned_by=int(actor_id) if isinstance(actor_id, str) else actor_id,
                )
                return {"message": "User assigned to group successfully"}
            except (UserNotFoundError, GroupNotFoundError) as exc:
                raise HTTPException(status_code=404, detail=str(exc))
            except Exception as exc:
                raise HTTPException(status_code=400, detail=str(exc))
    
    @router.delete("/user-groups/{user_id}/{group_id}", status_code=204)
    async def remove_user_from_group(
        user_id: int,
        group_id: int,
        claims: dict = Depends(_rbac("/api/auth/user-groups/*", "delete")),
    ):
        """Remove a user from a group."""
        tenant_id = claims.get("tenant_id")
        if not tenant_id:
            raise HTTPException(status_code=401, detail="tenant_id not found in JWT")
        
        if is_platform_mode:
            async with _get_platform_client(claims) as client:
                # Updated delegation URL to match platform service structure
                response = await client.delete(
                    f"/api/v1/admin/tenants/{tenant_id}/user-groups/{user_id}/{group_id}",
                )
                if response.status_code == 404:
                    raise HTTPException(status_code=404, detail="User or group not found")
                response.raise_for_status()
        else:
            try:
                actor_id = claims.get("sub")
                await user_mgmt.remove_user_from_group(
                    tenant_id=int(tenant_id) if isinstance(tenant_id, str) else tenant_id,
                    user_id=user_id, 
                    group_id=group_id,
                    removed_by=int(actor_id) if actor_id else None,
                )
            except (UserNotFoundError, GroupNotFoundError) as exc:
                raise HTTPException(status_code=404, detail=str(exc))
    
    # ──────────────────────────────────────────────
    # GROUP-ROLE ASSIGNMENT ENDPOINTS
    # ──────────────────────────────────────────────
    
    @router.post("/group-roles", status_code=201)
    async def assign_role_to_group(
        assignment: GroupRoleAssignRequest,
        claims: dict = Depends(_rbac("/api/auth/group-roles", "create")),
    ):
        """Assign a role to a group."""
        tenant_id = claims.get("tenant_id")
        actor_id = claims.get("sub")
        if not tenant_id:
            raise HTTPException(status_code=401, detail="tenant_id not found in JWT")
        if not actor_id:
            raise HTTPException(status_code=401, detail="User ID not found in JWT")
        
        if is_platform_mode:
            async with _get_platform_client(claims) as client:
                # Updated delegation URL to match platform service structure
                response = await client.post(
                    f"/api/v1/admin/tenants/{tenant_id}/group-roles",
                    json=assignment.model_dump(),
                )
                if response.status_code == 404:
                    raise HTTPException(status_code=404, detail="Group or role not found")
                response.raise_for_status()
                return {"message": "Role assigned to group successfully"}
        else:
            try:
                # Enforce one-role-per-group: check if this group already has a role
                pool = user_mgmt._db._need_pool()
                async with pool.acquire() as conn:
                    existing_role_count = await conn.fetchval(
                        "SELECT COUNT(*) FROM group_roles WHERE group_id = $1",
                        assignment.group_id
                    )
                if existing_role_count >= 1:
                    raise HTTPException(
                        status_code=409,
                        detail="This group already has a role assigned. Remove it first before assigning a new one."
                    )

                await user_mgmt.assign_role_to_group(
                    tenant_id=int(tenant_id) if isinstance(tenant_id, str) else tenant_id,
                    group_id=assignment.group_id,
                    role_id=assignment.role_id,
                    assigned_by=int(actor_id) if isinstance(actor_id, str) else actor_id,
                )
                return {"message": "Role assigned to group successfully"}
            except HTTPException:
                raise
            except (GroupNotFoundError, RoleNotFoundError) as exc:
                raise HTTPException(status_code=404, detail=str(exc))
            except Exception as exc:
                raise HTTPException(status_code=400, detail=str(exc))

    @router.delete("/group-roles/{group_id}/{role_id}", status_code=204)
    async def remove_role_from_group(
        group_id: int,
        role_id: int,
        claims: dict = Depends(_rbac("/api/auth/group-roles/*", "delete")),
    ):
        """Remove a role from a group."""
        tenant_id = claims.get("tenant_id")
        if not tenant_id:
            raise HTTPException(status_code=401, detail="tenant_id not found in JWT")
        
        if is_platform_mode:
            async with _get_platform_client(claims) as client:
                # Updated delegation URL to match platform service structure
                response = await client.delete(
                    f"/api/v1/admin/tenants/{tenant_id}/group-roles/{group_id}/{role_id}",
                )
                if response.status_code == 404:
                    raise HTTPException(status_code=404, detail="Group or role not found")
                response.raise_for_status()
        else:
            try:
                await user_mgmt.remove_role_from_group(
                    int(tenant_id) if isinstance(tenant_id, str) else tenant_id,
                    group_id, 
                    role_id
                )
            except (GroupNotFoundError, RoleNotFoundError) as exc:
                raise HTTPException(status_code=404, detail=str(exc))

    return router
