"""
Role management endpoints.

Provides CRUD operations for roles including:
- Create, read, update roles
- List roles with filtering
"""

from typing import List, Optional
import httpx
from fastapi import APIRouter, HTTPException, Query, Depends

from ..user_management import UserManagement, RoleNotFoundError, GroupNotFoundError
from ..authorization import AuthorizationEngine
from ..interfaces import (
    RoleRecord,
    RoleCreateRequest,
    RoleUpdateRequest,
    OAuthConfig,
    OAuthMode,
)


def create_roles_router(
    config: OAuthConfig,
    user_mgmt: Optional[UserManagement] = None,
    auth_dependency = None,
) -> APIRouter:
    """
    Create roles router that works in both STANDALONE and PLATFORM modes.
    
    - STANDALONE mode: Uses user_mgmt to access local database directly
    - PLATFORM mode: Delegates to Platform Service via HTTP
    
    Args:
        config: OAuthConfig with mode and platform_oauth_url
        user_mgmt: UserManagement instance (required for STANDALONE mode)
        auth_dependency: FastAPI dependency that validates JWT and returns claims
    
    Returns:
        FastAPI router with role endpoints
    """
    router = APIRouter(tags=["roles"])
    
    if config.mode == OAuthMode.STANDALONE and user_mgmt is None:
        raise ValueError("user_mgmt is required for STANDALONE mode")
    
    is_platform_mode = config.mode == OAuthMode.PLATFORM

    def _get_platform_client(claims: dict, timeout: float = 30.0):
        """Create httpx client with Authorization header for platform delegation."""
        return httpx.AsyncClient(
            base_url=config.platform_oauth_url.rstrip("/"),
            headers={"Authorization": f"Bearer {claims.get('_raw_token', '')}"},
            timeout=timeout
        )

    # Create default auth dependency if none provided
    if auth_dependency is None:
        from ..dependencies import require_auth
        auth_dependency = require_auth(config)

    auth_engine = AuthorizationEngine(user_mgmt._db) if not is_platform_mode and user_mgmt else None

    def _rbac(resource_path: str, action: str):
        async def _dep(claims: dict = Depends(auth_dependency)):
            if is_platform_mode:
                return claims

            user_id = claims.get("sub")
            tenant_id = claims.get("tenant_id")
            app_id = claims.get("app_id")
            if not all([user_id, tenant_id, app_id]):
                raise HTTPException(
                    status_code=403,
                    detail="Missing required claims in JWT (user_id, tenant_id, app_id)",
                )

            allowed, reason, policy = await auth_engine.can_user_perform(
                user_id=int(user_id) if isinstance(user_id, str) else user_id,
                tenant_id=int(tenant_id) if isinstance(tenant_id, str) else tenant_id,
                app_id=int(app_id) if isinstance(app_id, str) else app_id,
                resource_path=resource_path,
                action_name=action,
            )
            if not allowed:
                raise HTTPException(status_code=403, detail=f"Permission denied: {reason}")

            claims["_rbac_check"] = {
                "resource": resource_path,
                "action": action,
                "allowed": True,
                "reason": reason,
                "policy_id": policy.get("id") if policy else None,
            }
            return claims

        return _dep
    
    @router.post("/roles", response_model=RoleRecord, status_code=201)
    async def create_role(
        role: RoleCreateRequest,
        claims: dict = Depends(_rbac("/api/auth/roles", "create")),
    ):
        """Create a new role."""
        tenant_id = claims.get("tenant_id")
        actor_id = claims.get("sub")
        if not tenant_id:
            raise HTTPException(status_code=401, detail="tenant_id not found in JWT")
        if not actor_id:
            raise HTTPException(status_code=401, detail="User ID not found in JWT")
        
        if is_platform_mode:
            async with _get_platform_client(claims) as client:
                response = await client.post(
                    f"/api/v1/admin/tenants/{tenant_id}/roles",
                    json=role.model_dump(),
                )
                response.raise_for_status()
                return RoleRecord(**response.json())
        else:
            try:
                # Check for duplicate role name in tenant
                pool = user_mgmt._db._need_pool()
                async with pool.acquire() as conn:
                    existing = await conn.fetchval(
                        "SELECT id FROM roles WHERE tenant_id = $1 AND name = $2 AND is_active = TRUE",
                        int(tenant_id), role.role_name
                    )
                if existing:
                    raise HTTPException(status_code=409, detail=f"A role named '{role.role_name}' already exists")

                return await user_mgmt.create_role(
                    tenant_id=tenant_id,
                    role_name=role.role_name,
                    description=role.description,
                    created_by=int(actor_id) if isinstance(actor_id, str) else actor_id,
                )
            except HTTPException:
                raise
            except Exception as exc:
                raise HTTPException(status_code=400, detail=str(exc))
    
    @router.get("/roles/{role_id}", response_model=RoleRecord)
    async def get_role(
        role_id: int,
        claims: dict = Depends(_rbac("/api/auth/roles/*", "read")),
    ):
        """Get role by ID."""
        tenant_id = claims.get("tenant_id")
        if not tenant_id:
            raise HTTPException(status_code=401, detail="tenant_id not found in JWT")
        
        if is_platform_mode:
            async with _get_platform_client(claims) as client:
                response = await client.get(
                    f"/api/v1/admin/tenants/{tenant_id}/roles/{role_id}",
                                    )
                if response.status_code == 404:
                    raise HTTPException(status_code=404, detail=f"Role {role_id} not found")
                response.raise_for_status()
                return RoleRecord(**response.json())
        else:
            role = await user_mgmt.get_role(tenant_id, role_id)
            if not role:
                raise HTTPException(status_code=404, detail=f"Role {role_id} not found")
            return role
    
    @router.get("/roles", response_model=List[RoleRecord])
    async def list_roles(
        is_active: Optional[bool] = Query(None, description="Filter by active status"),
        claims: dict = Depends(_rbac("/api/auth/roles", "read")),
    ):
        """List roles."""
        tenant_id = claims.get("tenant_id")
        if not tenant_id:
            raise HTTPException(status_code=401, detail="tenant_id not found in JWT")
        
        if is_platform_mode:
            params = {}
            if is_active is not None:
                params["is_active"] = is_active
            async with _get_platform_client(claims) as client:
                response = await client.get(
                    f"/api/v1/admin/tenants/{tenant_id}/roles",
                    params=params,
                                    )
                response.raise_for_status()
                return [RoleRecord(**r) for r in response.json()]
        else:
            return await user_mgmt.list_roles(tenant_id=tenant_id, is_active=is_active)
    
    @router.patch("/roles/{role_id}", response_model=RoleRecord)
    async def update_role(
        role_id: int,
        update: RoleUpdateRequest,
        claims: dict = Depends(_rbac("/api/auth/roles/*", "update")),
    ):
        """Update role."""
        tenant_id = claims.get("tenant_id")
        actor_id = claims.get("sub")
        if not tenant_id:
            raise HTTPException(status_code=401, detail="tenant_id not found in JWT")
        if not actor_id:
            raise HTTPException(status_code=401, detail="User ID not found in JWT")
        
        if is_platform_mode:
            async with _get_platform_client(claims) as client:
                response = await client.patch(
                    f"/api/v1/admin/tenants/{tenant_id}/roles/{role_id}",
                    json=update.model_dump(exclude_none=True),
                                    )
                if response.status_code == 404:
                    raise HTTPException(status_code=404, detail=f"Role {role_id} not found")
                response.raise_for_status()
                return RoleRecord(**response.json())
        else:
            try:
                return await user_mgmt.update_role(
                    tenant_id=tenant_id,
                    role_id=role_id,
                    role_name=update.role_name,
                    description=update.description,
                    is_active=update.is_active,
                    updated_by=int(actor_id) if isinstance(actor_id, str) else actor_id,
                )
            except RoleNotFoundError as exc:
                raise HTTPException(status_code=404, detail=str(exc))
            except Exception as exc:
                raise HTTPException(status_code=400, detail=str(exc))

    @router.delete("/roles/{role_id}")
    async def delete_role(
        role_id: int,
        claims: dict = Depends(_rbac("/api/auth/roles/*", "delete")),
    ):
        """Delete role with detailed warnings about impact."""
        tenant_id = claims.get("tenant_id")
        actor_id = claims.get("sub")
        if not tenant_id:
            raise HTTPException(status_code=401, detail="tenant_id not found in JWT")
        if not actor_id:
            raise HTTPException(status_code=401, detail="User ID not found in JWT")
        
        if is_platform_mode:
            async with _get_platform_client(claims) as client:
                response = await client.delete(
                    f"/api/v1/admin/tenants/{tenant_id}/roles/{role_id}",
                                    )
                if response.status_code == 404:
                    raise HTTPException(status_code=404, detail=f"Role {role_id} not found")
                response.raise_for_status()
                return response.json()
        else:
            try:
                return await user_mgmt.delete_role(
                    tenant_id=tenant_id,
                    role_id=role_id,
                    updated_by=int(actor_id) if isinstance(actor_id, str) else actor_id,
                )
            except RoleNotFoundError as exc:
                raise HTTPException(status_code=404, detail=str(exc))
            except Exception as exc:
                raise HTTPException(status_code=400, detail=str(exc))

    return router
