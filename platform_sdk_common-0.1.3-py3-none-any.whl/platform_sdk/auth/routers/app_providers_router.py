"""
App-provider management endpoints for managing app-provider relationships.

Extracted from auth_router.py to create a dedicated, clean router focused
solely on app-provider operations.

Provides operations for:
- List providers for an app
- List app-provider links for tenant  
- Create/update/delete app-provider relationships

Supports both STANDALONE and PLATFORM modes with proper delegation.
"""

from typing import List, Optional
import httpx
from fastapi import APIRouter, HTTPException, Depends

from ..database import AuthDatabase
from ..interfaces import (
    AppProviderConfig,
    LinkAppProviderRequest,
    LinkAppProviderResponse,
    OAuthConfig,
    OAuthMode,
)


def create_app_providers_router(
    config: OAuthConfig,
    db: Optional[AuthDatabase] = None,
    auth_dependency = None,
) -> APIRouter:
    """
    Create app providers router that works in both STANDALONE and PLATFORM modes.
    
    - STANDALONE mode: Uses database directly for app-provider operations
    - PLATFORM mode: Delegates to Platform Service via HTTP with updated endpoints
    """
    router = APIRouter(tags=["app-providers"])
    
    if config.mode == OAuthMode.STANDALONE and db is None:
        raise ValueError("db (AuthDatabase) is required for STANDALONE mode")
    
    is_platform_mode = config.mode == OAuthMode.PLATFORM

    def _get_platform_client(claims: dict, timeout: float = 30.0):
        """Create httpx client with Authorization header for platform delegation."""
        return httpx.AsyncClient(
            base_url=config.platform_oauth_url.rstrip("/"),
            headers={"Authorization": f"Bearer {claims.get('_raw_token', '')}"},
            timeout=timeout
        )

    # Create default auth dependency if none provided
    if auth_dependency is None:
        from ..dependencies import require_auth
        auth_dependency = require_auth(config)

    def _rbac(resource_path: str, action: str):
        async def _dep(claims: dict = Depends(auth_dependency)):
            if is_platform_mode:
                return claims
            # For standalone mode, basic JWT validation is sufficient for now
            # Full RBAC can be added later if needed
            return claims
        return _dep
    
    # ──────────────────────────────────────────────
    # APP-PROVIDER LISTING ENDPOINTS
    # ──────────────────────────────────────────────
    
    @router.get("/apps/{app_id}/providers")
    async def list_app_providers(
        app_id: int,
        claims: dict = Depends(_rbac("/api/auth/apps/*/providers", "read")),
    ):
        """List all providers linked to an app."""
        tenant_id = claims.get("tenant_id")
        if not tenant_id:
            raise HTTPException(status_code=401, detail="tenant_id not found in JWT")
        
        if is_platform_mode:
            async with _get_platform_client(claims) as client:
                # Updated delegation URL to match platform service structure
                response = await client.get(
                    f"/api/v1/admin/tenants/{tenant_id}/apps/{app_id}/providers",
                )
                response.raise_for_status()
                return response.json()
        else:
            # STANDALONE mode: use local database
            if not db:
                raise HTTPException(
                    status_code=500,
                    detail="Database not configured for standalone mode"
                )
            
            # Validate app belongs to tenant
            app = await db.get_app(app_id)
            if not app or app.tenant_id != int(tenant_id):
                raise HTTPException(status_code=404, detail="App not found or access denied")
            
            app_providers = await db.list_app_providers(app_id)
            return {"providers": app_providers}
    
    @router.get("/app-providers")
    async def list_tenant_app_providers(
        claims: dict = Depends(_rbac("/api/auth/app-providers", "read")),
    ):
        """List all app-provider links for current tenant."""
        tenant_id = claims.get("tenant_id")
        if not tenant_id:
            raise HTTPException(status_code=401, detail="tenant_id not found in JWT")
        
        if is_platform_mode:
            async with _get_platform_client(claims) as client:
                # Updated delegation URL to match platform service structure
                response = await client.get(
                    f"/api/v1/admin/tenants/{tenant_id}/app-providers",
                )
                response.raise_for_status()
                return response.json()
        else:
            # STANDALONE mode: use local database
            if not db:
                raise HTTPException(
                    status_code=500,
                    detail="Database not configured for standalone mode"
                )
            
            # List all providers for tenant (includes app-provider mappings)
            providers = await db.list_providers_for_tenant(int(tenant_id))
            return {"app_providers": providers}
    
    @router.get("/app-providers/{app_id}/{provider_id}")
    async def get_app_provider(
        app_id: int,
        provider_id: int,
        claims: dict = Depends(_rbac("/api/auth/app-providers/*", "read")),
    ):
        """Get app-provider mapping details."""
        tenant_id = claims.get("tenant_id")
        if not tenant_id:
            raise HTTPException(status_code=401, detail="tenant_id not found in JWT")
        
        if is_platform_mode:
            async with _get_platform_client(claims) as client:
                # Updated delegation URL to match platform service structure
                response = await client.get(
                    f"/api/v1/admin/tenants/{tenant_id}/app-providers/{app_id}/{provider_id}",
                )
                if response.status_code == 404:
                    raise HTTPException(status_code=404, detail="App-provider relationship not found")
                response.raise_for_status()
                return response.json()
        else:
            # STANDALONE mode: use local database
            if not db:
                raise HTTPException(
                    status_code=500,
                    detail="Database not configured for standalone mode"
                )
            
            app_provider = await db.get_app_provider(app_id, provider_id)
            if not app_provider or app_provider.tenant_id != int(tenant_id):
                raise HTTPException(status_code=404, detail="App-provider relationship not found")
            
            return {"app_provider": app_provider}
    
    # ──────────────────────────────────────────────
    # APP-PROVIDER CRUD ENDPOINTS
    # ──────────────────────────────────────────────
    
    @router.post("/app-providers", response_model=LinkAppProviderResponse, status_code=201)
    async def link_app_provider(
        body: LinkAppProviderRequest,
        claims: dict = Depends(_rbac("/api/auth/app-providers", "create")),
    ):
        """Link an existing provider to an app."""
        tenant_id = claims.get("tenant_id")
        if not tenant_id:
            raise HTTPException(status_code=401, detail="tenant_id not found in JWT")
        
        if is_platform_mode:
            async with _get_platform_client(claims) as client:
                # Updated delegation URL to match platform service structure
                response = await client.post(
                    f"/api/v1/admin/tenants/{tenant_id}/app-providers",
                    json=body.model_dump()
                )
                response.raise_for_status()
                platform_response = response.json()
                
                # Transform platform service response to match LinkAppProviderResponse schema
                return LinkAppProviderResponse(
                    success=True,
                    app_id=body.app_id,
                    provider_id=body.provider_id,
                    tenant_id=body.tenant_id,
                    message=platform_response.get("message", "App-provider link created successfully"),
                )
        else:
            # STANDALONE mode: use local database
            if not db:
                raise HTTPException(
                    status_code=500,
                    detail="Database not configured for standalone mode"
                )
            
            # Validate app and provider belong to tenant
            app = await db.get_app(body.app_id)
            if not app or app.tenant_id != int(tenant_id):
                raise HTTPException(status_code=404, detail="App not found or belongs to different tenant")
            
            provider = await db.get_provider(body.provider_id)
            if not provider or provider.tenant_id != int(tenant_id):
                raise HTTPException(status_code=404, detail="Provider not found or belongs to different tenant")

            # Check if link already exists
            existing_link = await db.get_app_provider(body.app_id, body.provider_id)
            if existing_link:
                return LinkAppProviderResponse(
                    success=True,
                    app_id=body.app_id,
                    provider_id=body.provider_id,
                    tenant_id=body.tenant_id,
                    message="App-provider link already exists",
                )

            # Create the link
            await db.create_app_provider(
                AppProviderConfig(
                    app_id=body.app_id,
                    tenant_id=body.tenant_id,
                    provider_id=body.provider_id,
                )
            )

            return LinkAppProviderResponse(
                success=True,
                app_id=body.app_id,
                provider_id=body.provider_id,
                tenant_id=body.tenant_id,
                message="App-provider link created successfully",
            )
    
    @router.patch("/app-providers/{app_id}/{provider_id}")
    async def update_app_provider(
        app_id: int,
        provider_id: int,
        update_data: dict,
        claims: dict = Depends(_rbac("/api/auth/app-providers/*", "update")),
    ):
        """Update an app-provider relationship."""
        tenant_id = claims.get("tenant_id")
        if not tenant_id:
            raise HTTPException(status_code=401, detail="tenant_id not found in JWT")
        
        if is_platform_mode:
            async with _get_platform_client(claims) as client:
                # Updated delegation URL to match platform service structure
                response = await client.patch(
                    f"/api/v1/admin/tenants/{tenant_id}/app-providers/{app_id}/{provider_id}",
                    json=update_data,
                )
                if response.status_code == 404:
                    raise HTTPException(status_code=404, detail="App-provider relationship not found")
                response.raise_for_status()
                return response.json()
        else:
            # STANDALONE mode: use local database
            if not db:
                raise HTTPException(
                    status_code=500,
                    detail="Database not configured for standalone mode"
                )
            
            # Validate app and provider belong to tenant
            app = await db.get_app(app_id)
            provider = await db.get_provider(provider_id)
            
            if not app or app.tenant_id != int(tenant_id):
                raise HTTPException(status_code=404, detail="App not found")
            if not provider or provider.tenant_id != int(tenant_id):
                raise HTTPException(status_code=404, detail="Provider not found")
            
            # Use existing update method from database.py
            actor_id = claims.get("sub")
            updated_config = AppProviderConfig(
                app_id=app_id,
                provider_id=provider_id, 
                tenant_id=int(tenant_id),
                **update_data
            )
            result = await db.update_app_provider(
                app_id, provider_id, updated_config, 
                updated_by=int(actor_id) if actor_id else None
            )
            return {"success": True, "app_provider": result}
    
    @router.delete("/app-providers/{app_id}/{provider_id}", status_code=204)
    async def delete_app_provider(
        app_id: int,
        provider_id: int,
        claims: dict = Depends(_rbac("/api/auth/app-providers/*", "delete")),
    ):
        """Delete an app-provider relationship."""
        tenant_id = claims.get("tenant_id")
        if not tenant_id:
            raise HTTPException(status_code=401, detail="tenant_id not found in JWT")
        
        if is_platform_mode:
            async with _get_platform_client(claims) as client:
                # Updated delegation URL to match platform service structure
                response = await client.delete(
                    f"/api/v1/admin/tenants/{tenant_id}/app-providers/{app_id}/{provider_id}",
                )
                if response.status_code == 404:
                    raise HTTPException(status_code=404, detail="App-provider relationship not found")
                response.raise_for_status()
        else:
            # STANDALONE mode: use local database
            if not db:
                raise HTTPException(
                    status_code=500,
                    detail="Database not configured for standalone mode"
                )
            
            # Validate exists and belongs to tenant
            existing = await db.get_app_provider(app_id, provider_id)
            if not existing or existing.tenant_id != int(tenant_id):
                raise HTTPException(status_code=404, detail="App-provider relationship not found")
            
            actor_id = claims.get("sub")
            await db.delete_app_provider(
                app_id, provider_id,
                updated_by=int(actor_id) if actor_id else None
            )

    return router
