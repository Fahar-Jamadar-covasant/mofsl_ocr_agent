"""
RBAC Policies and Actions management endpoints.
"""

from typing import List, Optional
from fastapi import APIRouter, HTTPException, Depends
import httpx

from ..rbac_management import PolicyManagement, RBACManagementError
from ..authorization import AuthorizationEngine
from ..interfaces import (
    PolicyRecord,
    ActionRecord,
    OAuthConfig,
    ActionCreateRequest,
    PolicyCreateRequest,
    PolicyUpdateRequest,
    PolicyBulkCreateRequest,
    UserPolicyResponse,
    AllPoliciesResponse,
)


def create_rbac_policies_router(
    config: OAuthConfig,
    policy_mgmt: Optional[PolicyManagement] = None,
    auth_dependency = None,
) -> APIRouter:
    """
    Create RBAC policies router.
    
    Provides CRUD operations for:
    - Actions (create, read, update, delete, execute)
    - Policies (role + resource + action + allow/deny)
    
    Supports both standalone and platform modes:
    - Standalone: Uses local PolicyManagement
    - Platform: Delegates to platform service via HTTP
    """
    router = APIRouter(tags=["rbac-policies"])
    
    # Determine mode
    is_standalone = policy_mgmt is not None
    # Use unified platform URL format

    def _get_platform_client(claims: dict, timeout: float = 30.0):
        """Create httpx client with Authorization header for platform delegation."""
        return httpx.AsyncClient(
            base_url=config.platform_oauth_url.rstrip("/"),
            headers={"Authorization": f"Bearer {claims.get('_raw_token', '')}"},
            timeout=timeout
        )

    # Create default auth dependency if none provided
    if auth_dependency is None:
        from ..dependencies import require_auth
        auth_dependency = require_auth(config)

    auth_engine = AuthorizationEngine(policy_mgmt._db) if is_standalone and policy_mgmt else None

    def _rbac(resource_path: str, action: str):
        async def _dep(claims: dict = Depends(auth_dependency)):
            if not is_standalone:
                return claims

            user_id = claims.get("sub")
            tenant_id = claims.get("tenant_id")
            app_id = claims.get("app_id")
            if not all([user_id, tenant_id, app_id]):
                raise HTTPException(
                    status_code=403,
                    detail="Missing required claims in JWT (user_id, tenant_id, app_id)",
                )

            allowed, reason, policy = await auth_engine.can_user_perform(
                user_id=int(user_id) if isinstance(user_id, str) else user_id,
                tenant_id=int(tenant_id) if isinstance(tenant_id, str) else tenant_id,
                app_id=int(app_id) if isinstance(app_id, str) else app_id,
                resource_path=resource_path,
                action_name=action,
            )
            if not allowed:
                raise HTTPException(status_code=403, detail=f"Permission denied: {reason}")

            claims["_rbac_check"] = {
                "resource": resource_path,
                "action": action,
                "allowed": True,
                "reason": reason,
                "policy_id": policy.get("id") if policy else None,
            }
            return claims

        return _dep
    
    # ========================================
    # ACTIONS
    # ========================================
    
    @router.post("/rbac/actions", response_model=ActionRecord, status_code=201)
    async def create_action(
        body: ActionCreateRequest,
        claims: dict = Depends(_rbac("/api/auth/rbac/actions", "create")),
    ):
        """Create a new action."""
        if is_standalone:
            try:
                return await policy_mgmt.create_action(
                    name=body.name,
                    description=body.description
                )
            except Exception as exc:
                raise HTTPException(status_code=400, detail=str(exc))
        else:
            async with _get_platform_client(claims) as client:
                resp = await client.post(
                    "/api/v1/admin/rbac/actions",
                    json=body.dict(),
                                    )
                if resp.status_code != 201:
                    raise HTTPException(status_code=resp.status_code, detail=resp.text)
                return ActionRecord(**resp.json())
    
    @router.get("/rbac/actions/{action_id}", response_model=ActionRecord)
    async def get_action(
        action_id: int,
        claims: dict = Depends(_rbac("/api/auth/rbac/actions/*", "read")),
    ):
        """Get action by ID."""
        if is_standalone:
            action = await policy_mgmt.get_action(action_id)
            if not action:
                raise HTTPException(status_code=404, detail=f"Action {action_id} not found")
            return action
        else:
            async with _get_platform_client(claims) as client:
                resp = await client.get(
                    f"/api/v1/admin/rbac/actions/{action_id}",
                                    )
                if resp.status_code != 200:
                    raise HTTPException(status_code=resp.status_code, detail=resp.text)
                return ActionRecord(**resp.json())
    
    @router.get("/rbac/actions/name/{name}", response_model=ActionRecord)
    async def get_action_by_name(
        name: str,
        claims: dict = Depends(_rbac("/api/auth/rbac/actions/*", "read")),
    ):
        """Get action by name."""
        if is_standalone:
            action = await policy_mgmt.get_action_by_name(name)
            if not action:
                raise HTTPException(status_code=404, detail=f"Action '{name}' not found")
            return action
        else:
            async with _get_platform_client(claims) as client:
                resp = await client.get(
                    f"/api/v1/admin/rbac/actions/name/{name}",
                                    )
                if resp.status_code != 200:
                    raise HTTPException(status_code=resp.status_code, detail=resp.text)
                return ActionRecord(**resp.json())
    
    @router.get("/rbac/actions", response_model=List[ActionRecord])
    async def list_actions(
        claims: dict = Depends(_rbac("/api/auth/rbac/actions", "read")),
    ):
        """List all actions."""
        if is_standalone:
            return await policy_mgmt.list_actions()
        else:
            async with _get_platform_client(claims) as client:
                resp = await client.get(
                    "/api/v1/admin/rbac/actions",
                                    )
                if resp.status_code != 200:
                    raise HTTPException(status_code=resp.status_code, detail=resp.text)
                return [ActionRecord(**item) for item in resp.json()]
    
    # ========================================
    # POLICIES
    # ========================================
    
    @router.post("/rbac/policies", response_model=PolicyRecord, status_code=201)
    async def create_policy(
        body: PolicyCreateRequest,
        claims: dict = Depends(_rbac("/api/auth/rbac/policies", "create")),
    ):
        """Create a policy (role + resource + action + allow/deny)."""
        if is_standalone:
            tenant_id = claims.get("tenant_id")
            user_id = claims.get("sub")
            
            if not tenant_id:
                raise HTTPException(status_code=401, detail="tenant_id not found in JWT")
            if not user_id:
                raise HTTPException(status_code=401, detail="User ID not found in JWT")
            
            try:
                return await policy_mgmt.create_policy(
                    tenant_id=int(tenant_id),
                    role_id=body.role_id,
                    action_id=body.action_id,
                    resource_id=body.resource_id,
                    resource_group_id=body.resource_group_id,
                    is_allowed=body.is_allowed,
                    metadata=body.metadata,
                    created_by=int(user_id) if isinstance(user_id, str) else user_id,
                )
            except RBACManagementError as exc:
                raise HTTPException(status_code=400, detail=str(exc))
            except Exception as exc:
                raise HTTPException(status_code=400, detail=str(exc))
        else:
            async with _get_platform_client(claims) as client:
                resp = await client.post(
                    "/api/v1/admin/rbac/policies",
                    json=body.dict(),
                                    )
                if resp.status_code != 201:
                    raise HTTPException(status_code=resp.status_code, detail=resp.text)
                return PolicyRecord(**resp.json())
    
    @router.get("/rbac/policies/{policy_id}", response_model=PolicyRecord)
    async def get_policy(
        policy_id: int,
        claims: dict = Depends(_rbac("/api/auth/rbac/policies/*", "read")),
    ):
        """Get policy by ID."""
        if is_standalone:
            policy = await policy_mgmt.get_policy(policy_id)
            if not policy:
                raise HTTPException(status_code=404, detail=f"Policy {policy_id} not found")
            return policy
        else:
            async with _get_platform_client(claims) as client:
                resp = await client.get(
                    f"/api/v1/admin/rbac/policies/{policy_id}",
                                    )
                if resp.status_code != 200:
                    raise HTTPException(status_code=resp.status_code, detail=resp.text)
                return PolicyRecord(**resp.json())
    
    @router.get("/rbac/policies", response_model=List[PolicyRecord])
    async def list_policies(
        role_id: Optional[int] = None,
        resource_id: Optional[int] = None,
        resource_group_id: Optional[int] = None,
        action_id: Optional[int] = None,
        claims: dict = Depends(_rbac("/api/auth/rbac/policies", "read")),
    ):
        """List policies for the tenant, optionally filtered by role / resource / action."""
        if is_standalone:
            tenant_id = claims.get("tenant_id")
            return await policy_mgmt.list_policies(
                tenant_id=int(tenant_id) if tenant_id else None,
                role_id=role_id,
                resource_id=resource_id,
                resource_group_id=resource_group_id,
                action_id=action_id,
            )
        else:
            params = {}
            if role_id is not None:
                params["role_id"] = role_id
            if resource_id is not None:
                params["resource_id"] = resource_id
            if resource_group_id is not None:
                params["resource_group_id"] = resource_group_id
            if action_id is not None:
                params["action_id"] = action_id
            async with _get_platform_client(claims) as client:
                resp = await client.get("/api/v1/admin/rbac/policies", params=params)
                if resp.status_code != 200:
                    raise HTTPException(status_code=resp.status_code, detail=resp.text)
                return [PolicyRecord(**item) for item in resp.json()]
    
    @router.delete("/rbac/policies/{policy_id}", status_code=204)
    async def delete_policy(
        policy_id: int,
        claims: dict = Depends(_rbac("/api/auth/rbac/policies/*", "delete")),
    ):
        """Delete a policy."""
        if is_standalone:
            user_id = claims.get("sub")
            if not user_id:
                raise HTTPException(status_code=401, detail="User ID not found in JWT")

            await policy_mgmt.delete_policy(policy_id)
        else:
            async with _get_platform_client(claims) as client:
                resp = await client.delete(
                    f"/api/v1/admin/rbac/policies/{policy_id}",
                                    )
                if resp.status_code != 204:
                    raise HTTPException(status_code=resp.status_code, detail=resp.text)

    @router.patch("/rbac/policies/{policy_id}", response_model=PolicyRecord)
    async def update_policy(
        policy_id: int,
        body: PolicyUpdateRequest,
        claims: dict = Depends(_rbac("/api/auth/rbac/policies/*", "update")),
    ):
        """Update an RBAC policy."""
        if is_standalone:
            user_id = claims.get("sub")
            if not user_id:
                raise HTTPException(status_code=401, detail="User ID not found in JWT")

            try:
                return await policy_mgmt.update_policy(
                    policy_id=policy_id,
                    role_id=body.role_id,
                    resource_id=body.resource_id,
                    resource_group_id=body.resource_group_id,
                    action_id=body.action_id,
                    is_allowed=body.is_allowed,
                    metadata=body.metadata,
                )
            except RBACManagementError as exc:
                raise HTTPException(status_code=400, detail=str(exc))
            except Exception as exc:
                raise HTTPException(status_code=400, detail=str(exc))
        else:
            async with _get_platform_client(claims) as client:
                resp = await client.patch(
                    f"/api/v1/admin/rbac/policies/{policy_id}",
                    json=body.dict(exclude_none=True)
                )
                if resp.status_code != 200:
                    raise HTTPException(status_code=resp.status_code, detail=resp.text)
                return PolicyRecord(**resp.json())

    @router.post("/rbac/policies/bulk", response_model=List[PolicyRecord], status_code=201)
    async def bulk_create_policies(
        body: PolicyBulkCreateRequest,
        claims: dict = Depends(_rbac("/api/auth/rbac/policies", "create")),
    ):
        """Bulk-create policies with multiple actions for a role + resource."""
        if is_standalone:
            tenant_id = claims.get("tenant_id")
            user_id = claims.get("sub")

            if not tenant_id:
                raise HTTPException(status_code=401, detail="tenant_id not found in JWT")
            if not user_id:
                raise HTTPException(status_code=401, detail="User ID not found in JWT")

            results = []
            for action_name in body.actions:
                # Get action by name
                action = await policy_mgmt.get_action_by_name(action_name)
                if not action:
                    raise HTTPException(status_code=400, detail=f"Action '{action_name}' not found")

                try:
                    policy = await policy_mgmt.create_policy(
                        tenant_id=int(tenant_id),
                        role_id=body.role_id,
                        action_id=action.id,
                        resource_id=body.resource_id,
                        resource_group_id=body.resource_group_id,
                        is_allowed=body.is_allowed,
                        created_by=int(user_id) if isinstance(user_id, str) else user_id,
                    )
                    results.append(policy)
                except RBACManagementError as exc:
                    # Skip duplicate policies (silently) but fail on other errors
                    if "unique constraint" not in str(exc).lower():
                        raise HTTPException(status_code=400, detail=str(exc))
                except Exception as exc:
                    if "unique constraint" not in str(exc).lower():
                        raise HTTPException(status_code=400, detail=str(exc))

            return results
        else:
            # Platform mode: delegate to platform service
            async with _get_platform_client(claims) as client:
                resp = await client.post(
                    "/api/v1/admin/rbac/policies/bulk",
                    json=body.dict(),
                )
                if resp.status_code != 201:
                    raise HTTPException(status_code=resp.status_code, detail=resp.text)
                return [PolicyRecord(**p) for p in resp.json()]

    # ========================================
    # RBAC TRUTH TABLE ENDPOINTS
    # ========================================
    
    @router.get("/rbac/my-policies", response_model=List[UserPolicyResponse])
    async def get_my_rbac_policies(
        claims: dict = Depends(auth_dependency)
    ):
        """
        Get RBAC policies for current logged-in user.
        Returns the user's truth table: role, resource_group, resource, action, allowed.
        """
        if is_standalone:
            user_id = claims.get("sub")
            tenant_id = claims.get("tenant_id")

            if not all([user_id, tenant_id]):
                raise HTTPException(
                    status_code=400,
                    detail="Missing required claims: user_id (sub), tenant_id"
                )

            try:
                policies = await policy_mgmt.get_user_rbac_policies(
                    user_id=int(user_id) if isinstance(user_id, str) else user_id,
                    tenant_id=int(tenant_id) if isinstance(tenant_id, str) else tenant_id,
                )
                return [UserPolicyResponse(**policy) for policy in policies]
            except Exception as exc:
                raise HTTPException(status_code=500, detail=str(exc))
        else:
            # Platform mode: delegate to platform service
            async with _get_platform_client(claims) as client:
                resp = await client.get(
                    "/api/v1/admin/rbac/my-policies",
                                    )
                if resp.status_code != 200:
                    raise HTTPException(status_code=resp.status_code, detail=resp.text)
                return [UserPolicyResponse(**item) for item in resp.json()]
    
    @router.get("/rbac/all-policies", response_model=List[AllPoliciesResponse])
    async def get_all_rbac_policies(
        claims: dict = Depends(_rbac("/api/auth/rbac/policies", "read"))
    ):
        """
        Get all RBAC policies for all roles in the tenant.
        """
        if is_standalone:
            tenant_id = claims.get("tenant_id")

            if not tenant_id:
                raise HTTPException(
                    status_code=400,
                    detail="Missing required claim: tenant_id"
                )

            try:
                policies = await policy_mgmt.get_all_rbac_policies(
                    tenant_id=int(tenant_id) if isinstance(tenant_id, str) else tenant_id,
                )
                return [AllPoliciesResponse(**policy) for policy in policies]
            except Exception as exc:
                raise HTTPException(status_code=500, detail=str(exc))
        else:
            async with _get_platform_client(claims) as client:
                resp = await client.get("/api/v1/admin/rbac/all-policies")
                if resp.status_code != 200:
                    raise HTTPException(status_code=resp.status_code, detail=resp.text)
                return [AllPoliciesResponse(**item) for item in resp.json()]
    
    return router
