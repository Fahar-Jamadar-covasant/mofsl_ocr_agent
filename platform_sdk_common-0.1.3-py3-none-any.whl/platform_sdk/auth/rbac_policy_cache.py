from platform_sdk.common.cams_constants import RBAC_RESOURCE_PATH_SEPARATOR, RBAC_CACHE_KEY_SEPARATOR, MAX_REDIS_CONNECTIONS
try:
    import redis
    REDIS_AVAILABLE = True
except ImportError:
    REDIS_AVAILABLE = False

tenant_rbac_cache = {}
pool = None

def _get_rbac_key(*args):
    return RBAC_CACHE_KEY_SEPARATOR.join((str(arg) for arg in args))

def _get_rbac_prefix(*args):
    return _get_rbac_key(*args)+':*'

def _rbac_cache_get(key):
    # Try Redis first if available and pool initialized
    if REDIS_AVAILABLE and pool:
        r = redis.Redis(connection_pool=pool)
        try:
            value = r.get(key)
            if value != None:
                value = value.decode('utf-8')
                if value == 'true':
                    return True
                elif value == 'false':
                    return False
        except Exception:
            # Redis error, fallback to in-memory
            pass
        finally:
            r.close()
    
    # Fallback to in-memory cache
    if key in tenant_rbac_cache:
        return tenant_rbac_cache[key]
    return None

def _rbac_cache_put(key,value):
    # Try Redis first if available and pool initialized
    if REDIS_AVAILABLE and pool:
        r = redis.Redis(connection_pool=pool)
        try:
            if isinstance(value, bool):
                value = str(value).lower()
            r.set(key, value)
            # Also update in-memory cache for consistency
            tenant_rbac_cache[key] = value if isinstance(value, bool) else (value == 'true')
            return True
        except Exception:
            # Redis error, fallback to in-memory
            pass
        finally:
            r.close()
    
    # Fallback to in-memory cache
    tenant_rbac_cache[key] = value
    return True

def _rbac_clear_cache_by_prefix(prefix='*'):
    # Try Redis first if available and pool initialized
    if REDIS_AVAILABLE and pool:
        r = redis.Redis(connection_pool=pool)
        try:
            keys = r.keys(prefix)
            if keys:
                r.delete(*keys)
        except Exception:
            # Redis error, continue to in-memory cleanup
            pass
        finally:
            r.close()
    
    # Also clear in-memory cache
    if prefix == '*':
        tenant_rbac_cache.clear()
    else:
        # Remove keys matching prefix from in-memory cache
        prefix_str = prefix.rstrip('*')
        keys_to_delete = [k for k in tenant_rbac_cache.keys() if k.startswith(prefix_str)]
        for k in keys_to_delete:
            del tenant_rbac_cache[k]
    return True

def init_redis_pool(host='localhost', port=6379, db=0):
    """Initialize Redis connection pool. If Redis is not available, silently fallback to in-memory cache."""
    global pool
    if not REDIS_AVAILABLE:
        return False
    try:
        pool = redis.ConnectionPool(max_connections=MAX_REDIS_CONNECTIONS,host=host, port=port,db=db)
        return True
    except Exception:
        # Redis connection failed, use in-memory cache
        pool = None
        return False

def rbac_get_policy_result(tenant_id: int, role_id: int, resource_name: str, action: str):
    key = _get_rbac_key(tenant_id, role_id, resource_name, action)
    return _rbac_cache_get(key)

def rbac_put_policy_result(tenant_id: int, role_id: int, resource_name: str, action: str, result: bool):
    key = _get_rbac_key(tenant_id, role_id, resource_name, action)
    return _rbac_cache_put(key, result)

def clear_tenant_rbac_cache(tenant_id: int):
    return _rbac_clear_cache_by_prefix(prefix=_get_rbac_prefix(tenant_id))
