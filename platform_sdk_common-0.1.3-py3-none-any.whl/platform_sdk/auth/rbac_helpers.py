"""
RBAC helper utilities for automatic action derivation and permission checking.

Supports both STANDALONE and PLATFORM modes:
- STANDALONE: Uses local AuthorizationEngine + database
- PLATFORM: Calls platform service /api/v1/rbac/check-permission for real-time validation
"""

import logging
from typing import Optional
from fastapi import Request

logger = logging.getLogger(__name__)


def get_action_from_method(method: str) -> str:
    """
    Derive RBAC action from HTTP method.
    
    Mapping:
        GET    -> read
        POST   -> create
        PUT    -> update
        PATCH  -> update
        DELETE -> delete
    
    Args:
        method: HTTP method (GET, POST, PUT, PATCH, DELETE)
    
    Returns:
        RBAC action name (read, create, update, delete)
    
    Example:
        >>> get_action_from_method("GET")
        'read'
        >>> get_action_from_method("POST")
        'create'
    """
    method_to_action = {
        "GET": "read",
        "POST": "create",
        "PUT": "update",
        "PATCH": "update",
        "DELETE": "delete",
    }
    
    return method_to_action.get(method.upper(), "read")


def get_resource_path_from_request(request: Request) -> str:
    """
    Extract resource path from FastAPI request.
    
    Removes query parameters and normalizes the path for RBAC matching.
    
    Args:
        request: FastAPI Request object
    
    Returns:
        Normalized resource path (e.g., "/api/auth/users/123")
    
    Example:
        >>> # Request to /api/auth/users/123?include=roles
        >>> get_resource_path_from_request(request)
        '/api/auth/users/123'
    """
    # Get path without query parameters
    path = request.url.path
    
    # Remove trailing slash if present (except for root "/")
    if path != "/" and path.endswith("/"):
        path = path[:-1]
    
    return path


def create_dynamic_permission_dependency(
    config,
    auth_engine=None,
    database=None
):
    """
    Create a FastAPI dependency that automatically derives action from HTTP method.
    
    Supports both STANDALONE and PLATFORM modes:
    - STANDALONE: Uses local AuthorizationEngine for permission checks
    - PLATFORM: Calls platform service API for real-time permission validation
    
    This is a factory function that returns a dependency which:
    1. Validates JWT and session
    2. Extracts the HTTP method from the request
    3. Derives the RBAC action (GET=read, POST=create, etc.)
    4. Extracts the resource path from the request
    5. Checks permission (local DB or platform service API)
    
    Args:
        config: OAuthConfig instance
        auth_engine: AuthorizationEngine instance (required for STANDALONE, optional for PLATFORM)
        database: Optional AuthDatabase instance for session checks
    
    Returns:
        FastAPI dependency function
    
    Example (STANDALONE mode):
        from platform_sdk.auth import OAuthConfig, AuthDatabase, OAuthMode
        from platform_sdk.auth.authorization import AuthorizationEngine
        from platform_sdk.auth.rbac_helpers import create_dynamic_permission_dependency
        
        config = OAuthConfig(mode=OAuthMode.STANDALONE, ...)
        db = AuthDatabase(...)
        auth_engine = AuthorizationEngine(db)
        
        check_permission = create_dynamic_permission_dependency(config, auth_engine, db)
        
        @app.get("/api/users")
        async def list_users(user: dict = Depends(check_permission)):
            return {"users": [...]}
    
    Example (PLATFORM mode):
        from platform_sdk.auth import OAuthConfig, OAuthMode
        from platform_sdk.auth.rbac_helpers import create_dynamic_permission_dependency
        
        config = OAuthConfig(
            mode=OAuthMode.PLATFORM,
            platform_oauth_url="http://localhost:9000/api/v1"
        )
        
        check_permission = create_dynamic_permission_dependency(config)
        
        @app.get("/api/users")
        async def list_users(user: dict = Depends(check_permission)):
            return {"users": [...]}
    """
    from fastapi import Depends, HTTPException, Request
    from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
    from platform_sdk.auth.dependencies import _AuthDependency
    from platform_sdk.auth.interfaces import OAuthMode
    
    bearer_scheme = HTTPBearer()
    auth_dep = _AuthDependency(config, database=database)
    
    async def dynamic_permission_check(
        request: Request,
        credentials: HTTPAuthorizationCredentials = Depends(bearer_scheme),
    ):
        # First, validate JWT and get claims (includes session validation)
        claims = await auth_dep(credentials=credentials)
        
        # Derive action from HTTP method
        action = get_action_from_method(request.method)
        
        # Get resource path from request
        resource_path = get_resource_path_from_request(request)
        
        # PLATFORM mode: Call platform service for real-time RBAC validation
        if config.mode == OAuthMode.PLATFORM:
            import httpx
            
            logger.debug(f"[PLATFORM mode] Checking permission via platform service: resource={resource_path}, action={action}")
            
            try:
                async with httpx.AsyncClient(
                    base_url=config.platform_oauth_url.rstrip("/"),
                    headers={
                        "Authorization": f"Bearer {credentials.credentials}",
                        "Content-Type": "application/json"
                    },
                    timeout=5.0  # Fast timeout for RBAC checks
                ) as client:
                    response = await client.post(
                        "/api/v1/rbac/check-permission",
                        json={
                            "resource_path": resource_path,
                            "action": action
                        }
                    )
                    response.raise_for_status()
                    result = response.json()
                    
                    if not result.get("allowed"):
                        logger.warning(f"[PLATFORM mode] Permission denied: {result.get('reason')}")
                        raise HTTPException(
                            status_code=403,
                            detail=f"Permission denied: {result.get('reason')} (resource={resource_path}, action={action})"
                        )
                    
                    logger.debug(f"[PLATFORM mode] Permission granted: {result.get('reason')}")
                    
                    # Add permission info to claims
                    claims["_rbac_check"] = {
                        "resource": resource_path,
                        "action": action,
                        "allowed": True,
                        "reason": result.get("reason"),
                        "policy_id": result.get("policy_id")
                    }
                    
                    return claims
                    
            except httpx.HTTPStatusError as exc:
                if exc.response.status_code == 403:
                    logger.warning(f"[PLATFORM mode] Permission denied by platform service: {exc.response.text}")
                    raise HTTPException(status_code=403, detail=exc.response.text)
                logger.error(f"[PLATFORM mode] RBAC check failed with status {exc.response.status_code}: {exc.response.text}")
                raise HTTPException(
                    status_code=500,
                    detail=f"RBAC check failed: {exc.response.text}"
                )
            except Exception as exc:
                logger.error(f"[PLATFORM mode] RBAC check error: {exc}")
                raise HTTPException(
                    status_code=500,
                    detail=f"RBAC check failed: {str(exc)}"
                )
        
        # STANDALONE mode: Local database check
        else:
            if not auth_engine:
                logger.error("[STANDALONE mode] Authorization engine not configured")
                raise HTTPException(
                    status_code=500,
                    detail="Authorization engine not configured for STANDALONE mode"
                )
            
            logger.debug(f"[STANDALONE mode] Checking permission locally: resource={resource_path}, action={action}")
            
            # Extract required info from JWT
            user_id = claims.get("sub")
            tenant_id = claims.get("tenant_id")
            app_id = claims.get("app_id")

            if not all([user_id, tenant_id, app_id]):
                logger.error(f"[STANDALONE mode] Missing claims: user_id={user_id}, tenant_id={tenant_id}, app_id={app_id}")
                raise HTTPException(
                    status_code=403,
                    detail="Missing required claims in JWT (user_id, tenant_id, app_id)"
                )

            # Local permission check
            allowed, reason, policy = await auth_engine.can_user_perform(
                user_id=int(user_id) if isinstance(user_id, str) else user_id,
                tenant_id=int(tenant_id) if isinstance(tenant_id, str) else tenant_id,
                app_id=int(app_id) if isinstance(app_id, str) else app_id,
                resource_path=resource_path,
                action_name=action
            )
            
            if not allowed:
                logger.warning(f"[STANDALONE mode] Permission denied: {reason}")
                raise HTTPException(
                    status_code=403,
                    detail=f"Permission denied: {reason} (resource={resource_path}, action={action})"
                )
            
            logger.debug(f"[STANDALONE mode] Permission granted: {reason}")
            
            # Add permission info to claims
            claims["_rbac_check"] = {
                "resource": resource_path,
                "action": action,
                "allowed": True,
                "reason": reason,
                "policy_id": policy.get("id") if policy else None
            }
            
            return claims
    
    return dynamic_permission_check
