"""
Pluggable state store for OAuth CSRF state + PKCE code_verifier.
Ships with InMemoryStateStore for development.
Production: use AuthDatabase (see database.py) which implements StateStore.
"""

import time
from abc import ABC, abstractmethod
from typing import Dict, Optional

from .interfaces import OAuthState


class StateStore(ABC):
    """Abstract state store. Implement for Redis, DB, etc."""

    @abstractmethod
    async def save_state(self, state: OAuthState) -> None:
        """Persist an OAuth state entry."""
        ...

    @abstractmethod
    async def get_state(self, state_value: str) -> Optional[OAuthState]:
        """Retrieve state without deleting. Return None if not found or expired."""
        ...

    @abstractmethod
    async def get_and_delete_state(self, state_value: str) -> Optional[OAuthState]:
        """Retrieve and DELETE state (one-time use). Return None if not found or expired."""
        ...


class InMemoryStateStore(StateStore):
    """
    In-memory store. For development and testing only.
    NOT suitable for production (lost on restart, not multi-process safe).
    """

    def __init__(self) -> None:
        self._store: Dict[str, OAuthState] = {}

    async def save_state(self, state: OAuthState) -> None:
        self._store[state.state] = state

    async def get_state(self, state_value: str) -> Optional[OAuthState]:
        """Retrieve state without deleting."""
        self._cleanup()
        return self._store.get(state_value)

    async def get_and_delete_state(self, state_value: str) -> Optional[OAuthState]:
        self._cleanup()
        return self._store.pop(state_value, None)

    def _cleanup(self) -> None:
        now = time.time()
        expired = [k for k, v in self._store.items() if v.expires_at < now]
        for k in expired:
            del self._store[k]
