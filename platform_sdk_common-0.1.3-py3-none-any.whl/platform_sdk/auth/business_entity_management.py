"""
Generic business entity hierarchy management (N-level).

Provides CRUD operations for scope entities at any hierarchy depth.
Replaces hardcoded systems/organizations/projects with self-referential tree.
"""

import json
import logging
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


class BusinessEntityManagement:
    """Manages CRUD operations for generic scope entities (N-level hierarchy)."""

    def __init__(self, db):
        """Initialize with database connection."""
        self._db = db

    # ──────────────────────────────────────────────
    # LEVEL MANAGEMENT
    # ──────────────────────────────────────────────

    async def list_levels(self, tenant_id: int) -> List[dict]:
        """Get all configured scope entity levels for a tenant."""
        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            rows = await conn.fetch("""
                SELECT id, tenant_id, name, depth, description, is_active, created_at
                FROM scope_entity_levels
                WHERE tenant_id = $1 AND is_active = TRUE
                ORDER BY depth ASC
            """, tenant_id)
        return [dict(row) for row in rows]

    async def get_level_by_name(self, tenant_id: int, name: str) -> Optional[dict]:
        """Get level by name."""
        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow("""
                SELECT id, tenant_id, name, depth, description, is_active
                FROM scope_entity_levels
                WHERE tenant_id = $1 AND name = $2 AND is_active = TRUE
            """, tenant_id, name)
        return dict(row) if row else None

    async def create_level(
        self,
        tenant_id: int,
        name: str,
        depth: int,
        description: Optional[str] = None
    ) -> dict:
        """Create a new scope entity level."""
        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow("""
                INSERT INTO scope_entity_levels (tenant_id, name, depth, description, is_active)
                VALUES ($1, $2, $3, $4, TRUE)
                RETURNING id, tenant_id, name, depth, description, is_active, created_at
            """, tenant_id, name, depth, description)
        logger.info(f"Created level '{name}' at depth {depth} for tenant {tenant_id}")
        return dict(row)

    # ──────────────────────────────────────────────
    # ENTITY CRUD
    # ──────────────────────────────────────────────

    async def create_entity(
        self,
        tenant_id: int,
        name: str,
        level_name: str,
        parent_uuid: Optional[str] = None,
        description: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        created_by: Optional[int] = None
    ) -> dict:
        """Create a new scope entity."""
        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            # Get level_id by name
            level_row = await conn.fetchrow("""
                SELECT id FROM scope_entity_levels
                WHERE tenant_id = $1 AND name = $2 AND is_active = TRUE
            """, tenant_id, level_name)
            if not level_row:
                raise ValueError(f"Level '{level_name}' not found for tenant {tenant_id}")
            level_id = level_row["id"]

            # Get parent_id by UUID if provided
            parent_id = None
            if parent_uuid:
                parent_row = await conn.fetchrow("""
                    SELECT id FROM scope_entities
                    WHERE tenant_id = $1 AND uuid = $2 AND is_active = TRUE
                """, tenant_id, parent_uuid)
                if not parent_row:
                    raise ValueError(f"Parent entity with UUID '{parent_uuid}' not found")
                parent_id = parent_row["id"]

            # Create entity
            metadata_json = json.dumps(metadata) if metadata else None
            row = await conn.fetchrow("""
                INSERT INTO scope_entities
                    (tenant_id, level_id, parent_id, name, description, metadata, created_by, updated_by)
                VALUES ($1, $2, $3, $4, $5, $6::jsonb, $7, $7)
                RETURNING *
            """, tenant_id, level_id, parent_id, name, description, metadata_json, created_by)

            # Enrich with level_name
            result = dict(row)
            result["level_name"] = level_name
            logger.info(f"Created entity '{name}' at level '{level_name}' (id={result['id']})")
            return result

    async def get_entity_by_id(self, entity_id: int) -> Optional[dict]:
        """Get entity by ID with level info."""
        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow("""
                SELECT se.*, sel.name AS level_name
                FROM scope_entities se
                JOIN scope_entity_levels sel ON sel.id = se.level_id
                WHERE se.id = $1 AND se.is_active = TRUE
            """, entity_id)
        return dict(row) if row else None

    async def get_entity_by_uuid(self, entity_uuid: str) -> Optional[dict]:
        """Get entity by UUID with level info."""
        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow("""
                SELECT se.*, sel.name AS level_name
                FROM scope_entities se
                JOIN scope_entity_levels sel ON sel.id = se.level_id
                WHERE se.uuid = $1 AND se.is_active = TRUE
            """, entity_uuid)
        return dict(row) if row else None

    async def list_entities(
        self,
        tenant_id: int,
        level_name: Optional[str] = None,
        parent_id: Optional[int] = None,
        include_inactive: bool = False
    ) -> List[dict]:
        """List entities with optional filters."""
        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            query = """
                SELECT se.*, sel.name AS level_name,
                       parent.name AS parent_name, parent.uuid AS parent_uuid
                FROM scope_entities se
                JOIN scope_entity_levels sel ON sel.id = se.level_id
                LEFT JOIN scope_entities parent ON parent.id = se.parent_id
                WHERE se.tenant_id = $1
            """
            params = [tenant_id]
            param_idx = 2

            if not include_inactive:
                query += f" AND se.is_active = TRUE"

            if level_name:
                query += f" AND sel.name = ${param_idx}"
                params.append(level_name)
                param_idx += 1

            if parent_id is not None:
                query += f" AND se.parent_id = ${param_idx}"
                params.append(parent_id)
                param_idx += 1

            query += " ORDER BY sel.depth ASC, se.name ASC"
            rows = await conn.fetch(query, *params)

        return [dict(row) for row in rows]

    async def list_children(
        self,
        entity_id: int,
        recursive: bool = False
    ) -> List[dict]:
        """List direct children or entire subtree (recursive)."""
        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            if recursive:
                # Recursive CTE to get entire subtree
                rows = await conn.fetch("""
                    WITH RECURSIVE subtree AS (
                        SELECT se.*, sel.name AS level_name, sel.depth
                        FROM scope_entities se
                        JOIN scope_entity_levels sel ON sel.id = se.level_id
                        WHERE se.parent_id = $1 AND se.is_active = TRUE
                      UNION ALL
                        SELECT se.*, sel.name AS level_name, sel.depth
                        FROM scope_entities se
                        JOIN scope_entity_levels sel ON sel.id = se.level_id
                        JOIN subtree st ON se.parent_id = st.id
                        WHERE se.is_active = TRUE
                    )
                    SELECT * FROM subtree
                    ORDER BY depth ASC, name ASC
                """, entity_id)
            else:
                # Direct children only
                rows = await conn.fetch("""
                    SELECT se.*, sel.name AS level_name
                    FROM scope_entities se
                    JOIN scope_entity_levels sel ON sel.id = se.level_id
                    WHERE se.parent_id = $1 AND se.is_active = TRUE
                    ORDER BY sel.depth ASC, se.name ASC
                """, entity_id)

        return [dict(row) for row in rows]

    async def get_parent_chain(self, entity_id: int) -> List[dict]:
        """Get all ancestors from root to immediate parent (ordered by depth)."""
        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            rows = await conn.fetch("""
                WITH RECURSIVE parent_chain AS (
                    SELECT se.id, se.uuid, se.name, se.parent_id, se.tenant_id,
                           se.is_active, se.description, sel.name AS level_name, sel.depth
                    FROM scope_entities se
                    JOIN scope_entity_levels sel ON sel.id = se.level_id
                    WHERE se.id = $1
                  UNION ALL
                    SELECT se.id, se.uuid, se.name, se.parent_id, se.tenant_id,
                           se.is_active, se.description, sel.name AS level_name, sel.depth
                    FROM scope_entities se
                    JOIN scope_entity_levels sel ON sel.id = se.level_id
                    JOIN parent_chain pc ON pc.parent_id = se.id
                )
                SELECT * FROM parent_chain
                WHERE id != $1
                ORDER BY depth ASC
            """, entity_id)

        return [dict(row) for row in rows]

    async def update_entity(
        self,
        entity_id: int,
        name: Optional[str] = None,
        description: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        updated_by: Optional[int] = None
    ) -> Optional[dict]:
        """Update an entity."""
        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            # Get current entity
            entity = await conn.fetchrow("""
                SELECT * FROM scope_entities WHERE id = $1 AND is_active = TRUE
            """, entity_id)
            if not entity:
                return None

            # Merge updates
            new_name = name if name is not None else entity["name"]
            new_desc = description if description is not None else entity["description"]
            new_meta = metadata if metadata is not None else entity["metadata"]
            new_meta_json = json.dumps(new_meta) if new_meta else None

            # Update
            row = await conn.fetchrow("""
                UPDATE scope_entities
                SET name = $1, description = $2, metadata = $3::jsonb, updated_by = $4, updated_at = NOW()
                WHERE id = $5 AND is_active = TRUE
                RETURNING *
            """, new_name, new_desc, new_meta_json, updated_by, entity_id)

            if row:
                # Enrich with level_name
                level_row = await conn.fetchrow("""
                    SELECT name FROM scope_entity_levels WHERE id = $1
                """, row["level_id"])
                result = dict(row)
                result["level_name"] = level_row["name"] if level_row else None
                logger.info(f"Updated entity {entity_id}")
                return result
            return None

    async def delete_entity(self, entity_id: int) -> bool:
        """Soft delete an entity (set is_active = FALSE)."""
        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            result = await conn.execute("""
                UPDATE scope_entities
                SET is_active = FALSE, updated_at = NOW()
                WHERE id = $1
            """, entity_id)
            logger.info(f"Soft deleted entity {entity_id}")
            return result == "UPDATE 1"
