"""
Covasant Platform SDK - Auth Module

OAuth 2.1 authentication with STANDALONE and PLATFORM mode support.
Provides OAuth client, JWT wrapping, OIDC discovery, Postgres-backed
tenant/provider/session storage, FastAPI router, and route protection.
"""

__version__ = "0.1.3"

from .interfaces import (
    OAuthMode,
    JWTAlgorithm,
    OAuthConfig,
    OAuthResult,
    OAuthState,
    ProviderConfig,
    TenantConfig,
    TenantProperty,
    AppProviderConfig,
    AppConfig,
    SessionRecord,
    OAuth2Provider,
    OAuthError,
    OAuthConfigurationError,
    OAuthTokenExpiredError,
    InitializationError,
    InitializeStandaloneRequest,
    InitializeStandaloneResponse,
    # User Management Models
    UserRecord,
    UserCreateRequest,
    UserUpdateRequest,
    UserIdentityRecord,
    GroupRecord,
    GroupCreateRequest,
    GroupUpdateRequest,
    RoleRecord,
    RoleCreateRequest,
    RoleUpdateRequest,
    UserGroupAssignRequest,
    GroupRoleAssignRequest,
    # OAuth Authentication Schemas
    AuthUrlRequest,
    AuthTokenRequest,
    AuthRefreshRequest,
    AuthRevokeRequest,
    IdpTokenResponse,
    # Platform Admin Schemas
    TenantCreateRequest,
    TenantUpdateRequest,
    ProviderCreateRequest,
    ProviderUpdateRequest,
    AppCreateRequest,
    AppUpdateRequest,
    AppProviderCreateRequest,
    AppProviderUpdateRequest,
    TenantKeyCreateRequest,
    TenantPropertyCreateRequest,
    TenantPropertyUpdateRequest,
    # RBAC Models
    ActionRecord,
    ResourceGroupRecord,
    ResourceRecord,
    ScopeRecord,
    GroupScopeAssignment,
    PolicyRecord,
    # RBAC Request Schemas
    ResourceGroupCreateRequest,
    ResourceGroupUpdateRequest,
    ResourceCreateRequest,
    ResourceUpdateRequest,
    GroupScopeAssignRequest,
    PolicyCreateRequest,
)
from .jwt_wrapper import JWTWrapper
from .oauth2_client import OAuth2Client
from .state_store import StateStore, InMemoryStateStore
from .database import AuthDatabase
from .dependencies import require_auth, require_roles, require_tenant, require_permission
from .rbac_helpers import create_dynamic_permission_dependency
from .routers import (
    create_auth_router,
    create_users_router,
    create_groups_router,
    create_roles_router,
    create_user_assignments_router,
    create_app_providers_router,
    create_sessions_router,
    create_entity_router,
    create_rbac_scopes_router,
)
from .user_management import UserManagement
from .authorization import AuthorizationEngine
from .rbac_management import (
    ResourceManagement,
    PolicyManagement,
    ScopeManagement,
    GroupScopeManagement,
)
from .business_entity_management import BusinessEntityManagement
from .routers.rbac_resources_router import create_rbac_resources_router
from .routers.rbac_policies_router import create_rbac_policies_router
from .routers.rbac_analytics_router import create_rbac_analytics_router

__all__ = [
    # Enums
    "OAuthMode",
    "JWTAlgorithm",
    # Config & Models
    "OAuthConfig",
    "OAuthResult",
    "OAuthState",
    "ProviderConfig",
    "TenantConfig",
    "TenantProperty",
    "AppProviderConfig",
    "AppConfig",
    "SessionRecord",
    "InitializeStandaloneRequest",
    "InitializeStandaloneResponse",
    # User Management Models
    "UserRecord",
    "UserCreateRequest",
    "UserUpdateRequest",
    "UserIdentityRecord",
    "GroupRecord",
    "GroupCreateRequest",
    "GroupUpdateRequest",
    "RoleRecord",
    "RoleCreateRequest",
    "RoleUpdateRequest",
    "UserGroupAssignRequest",
    "GroupRoleAssignRequest",
    # OAuth Authentication Schemas
    "AuthUrlRequest",
    "AuthTokenRequest",
    "AuthRefreshRequest",
    "AuthRevokeRequest",
    "IdpTokenResponse",
    # Platform Admin Schemas
    "TenantCreateRequest",
    "TenantUpdateRequest",
    "ProviderCreateRequest",
    "ProviderUpdateRequest",
    "AppCreateRequest",
    "AppUpdateRequest",
    "AppProviderCreateRequest",
    "AppProviderUpdateRequest",
    "TenantKeyCreateRequest",
    "TenantPropertyCreateRequest",
    "TenantPropertyUpdateRequest",
    # RBAC Models
    "ActionRecord",
    "ResourceGroupRecord",
    "ResourceRecord",
    "ScopeRecord",
    "GroupScopeAssignment",
    "PolicyRecord",
    # RBAC Request Schemas
    "ResourceGroupCreateRequest",
    "ResourceGroupUpdateRequest",
    "ResourceCreateRequest",
    "ResourceUpdateRequest",
    "GroupScopeAssignRequest",
    "PolicyCreateRequest",
    # Abstract
    "OAuth2Provider",
    # Core
    "OAuth2Client",
    "JWTWrapper",
    # State & Database
    "StateStore",
    "InMemoryStateStore",
    "AuthDatabase",
    # User Management
    "UserManagement",
    # Authorization
    "AuthorizationEngine",
    # RBAC Management
    "ResourceManagement",
    "PolicyManagement",
    "ScopeManagement",
    "GroupScopeManagement",
    # Business Entity Management
    "BusinessEntityManagement",
    # FastAPI Integration - Routers
    "create_auth_router",
    "create_users_router",
    "create_groups_router",
    "create_roles_router",
    "create_user_assignments_router",
    "create_app_providers_router",
    "create_sessions_router",
    "create_entity_router",
    "create_rbac_resources_router",
    "create_rbac_policies_router",
    "create_rbac_analytics_router",
    "create_rbac_scopes_router",
    # FastAPI Integration - Dependencies
    "require_auth",
    "require_roles",
    "require_tenant",
    "require_permission",
    "create_dynamic_permission_dependency",
    # Exceptions
    "OAuthError",
    "OAuthConfigurationError",
    "OAuthTokenExpiredError",
    "InitializationError",
]
