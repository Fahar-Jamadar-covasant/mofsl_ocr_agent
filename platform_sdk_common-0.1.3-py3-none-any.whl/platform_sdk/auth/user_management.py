"""
User Management CRUD operations.
Handles users, user_identities, groups, roles, and their relationships.
Keeps database.py focused on core auth operations.
"""

import json
import logging
from typing import Any, Dict, List, Optional

from .database import AuthDatabase
from .interfaces import (
    UserRecord,
    UserIdentityRecord,
    GroupRecord,
    RoleRecord,
)

logger = logging.getLogger(__name__)


class UserManagementError(Exception):
    """Base exception for user management operations."""
    pass


class UserNotFoundError(UserManagementError):
    """User not found."""
    pass


class GroupNotFoundError(UserManagementError):
    """Group not found."""
    pass


class RoleNotFoundError(UserManagementError):
    """Role not found."""
    pass


class UserManagement:
    """User and group management operations."""
    
    def __init__(self, db: AuthDatabase):
        self._db = db
    
    # ──────────────────────────────────────────────
    # USER OPERATIONS
    # ──────────────────────────────────────────────
    
    async def upsert_user_on_login(
        self,
        tenant_id: int,
        provider_id: int,
        external_user_id: str,
        email: str,
        first_name: Optional[str] = None,
        last_name: Optional[str] = None,
        display_name: Optional[str] = None,
        idp_attributes: Optional[Dict[str, Any]] = None,
    ) -> int:
        """
        Create or update user on login (Just-In-Time provisioning).
        
        Flow:
        1. Check if user exists by email (one user per email per tenant)
        2. If exists: update user + upsert identity
        3. If not: create user + create identity
        
        Returns user.id
        """
        # Normalize email to lowercase for case-insensitive matching
        email = email.lower() if email else email
        
        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            # Check if user exists by email
            user_row = await conn.fetchrow(
                "SELECT id, is_active FROM users WHERE tenant_id = $1 AND email = $2",
                tenant_id, email
            )
            
            if user_row:
                # User exists - update profile and last_login_at
                if not user_row["is_active"]:
                    raise UserManagementError(f"User {email} is not active")
                user_id = user_row["id"]
                await conn.execute(
                    """
                    UPDATE users 
                    SET first_name = COALESCE($1, first_name),
                        last_name = COALESCE($2, last_name),
                        display_name = COALESCE($3, display_name),
                        last_login_at = NOW(),
                        updated_at = NOW()
                    WHERE id = $4
                    """,
                    first_name, last_name, display_name, user_id
                )
                logger.info(f"Updated user {user_id} on login")
            else:
                # New user - create
                user_row = await conn.fetchrow(
                    """
                    INSERT INTO users (tenant_id, email, first_name, last_name, 
                                       display_name, is_active, last_login_at)
                    VALUES ($1, $2, $3, $4, $5, TRUE, NOW())
                    RETURNING id
                    """,
                    tenant_id, email, first_name, last_name, display_name
                )
                user_id = user_row["id"]
                logger.info(f"Created new user {user_id} for {email}")
                
                # Auto-assign to default group (is_default=TRUE)
                default_group = await conn.fetchrow("""
                    SELECT id, name FROM u_groups 
                    WHERE tenant_id = $1 AND is_default = TRUE AND is_active = TRUE
                    LIMIT 1
                """, tenant_id)
                
                if default_group:
                    await conn.execute("""
                        INSERT INTO user_groups (tenant_id, user_id, group_id)
                        VALUES ($1, $2, $3)
                        ON CONFLICT (user_id, group_id) DO NOTHING
                    """, tenant_id, user_id, default_group['id'])
                    logger.info(f"� User {user_id} auto-assigned to default group '{default_group['name']}'")
                else:
                    logger.warning(f"⚠️  No default group found for tenant {tenant_id}. User {user_id} has no group assignment.")

            # Ensure user has at least one active group membership.
            # Covers returning users who were removed from all groups, or whose
            # default group was changed since they last logged in.
            active_group_count = await conn.fetchval(
                """
                SELECT COUNT(*)
                FROM user_groups ug
                JOIN u_groups g ON g.id = ug.group_id
                WHERE ug.user_id = $1 AND g.tenant_id = $2 AND g.is_active = TRUE
                """,
                user_id, tenant_id
            )
            if active_group_count == 0:
                default_group = await conn.fetchrow(
                    """
                    SELECT id, name FROM u_groups
                    WHERE tenant_id = $1 AND is_default = TRUE AND is_active = TRUE
                    LIMIT 1
                    """,
                    tenant_id
                )
                if default_group:
                    await conn.execute(
                        """
                        INSERT INTO user_groups (tenant_id, user_id, group_id)
                        VALUES ($1, $2, $3)
                        ON CONFLICT (user_id, group_id) DO NOTHING
                        """,
                        tenant_id, user_id, default_group['id']
                    )
                    logger.info(
                        f"User {user_id} re-assigned to default group '{default_group['name']}'"
                        " (no active group memberships found on login)"
                    )
                else:
                    logger.warning(
                        f"No default group found for tenant {tenant_id}."
                        f" User {user_id} logged in with no group assignment."
                    )

            # Upsert identity (link user to this provider)
            await conn.execute(
                """
                INSERT INTO user_identities 
                    (tenant_id, user_id, provider_id, external_user_id, idp_attributes, last_synced_at)
                VALUES ($1, $2, $3, $4, $5::jsonb, NOW())
                ON CONFLICT (tenant_id, provider_id, external_user_id)
                DO UPDATE SET
                    idp_attributes = EXCLUDED.idp_attributes,
                    last_synced_at = NOW(),
                    updated_at = NOW()
                """,
                tenant_id, user_id, provider_id, external_user_id, 
                json.dumps(idp_attributes or {})
            )
            
            return user_id
    
    async def create_user(
        self,
        tenant_id: int,
        email: str,
        first_name: Optional[str] = None,
        last_name: Optional[str] = None,
        display_name: Optional[str] = None,
        is_active: bool = True,
        created_by: Optional[int] = None,
    ) -> UserRecord:
        """Create a new user manually."""
        # Normalize email to lowercase for case-insensitive matching
        email = email.lower() if email else email
        
        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                """
                INSERT INTO users (tenant_id, email, first_name, last_name, 
                                   display_name, is_active, created_by, updated_by)
                VALUES ($1, $2, $3, $4, $5, $6, $7, $7)
                RETURNING *
                """,
                tenant_id, email, first_name, last_name, display_name, is_active, created_by
            )
            logger.info(f"Created user {row['id']} manually")
            return UserRecord(**dict(row))

    async def create_user_with_password(
        self,
        tenant_id: int,
        email: str,
        password_hash: str,
        first_name: Optional[str] = None,
        last_name: Optional[str] = None,
        display_name: Optional[str] = None,
        is_active: bool = True,
        created_by: Optional[int] = None,
    ) -> UserRecord:
        """Create a new user with password hash for password-based authentication."""
        # Normalize email to lowercase for case-insensitive matching
        email = email.lower() if email else email
        
        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                """
                INSERT INTO users (tenant_id, email, password_hash, first_name, last_name, 
                                   display_name, is_active, created_by, updated_by)
                VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $8)
                RETURNING *
                """,
                tenant_id, email, password_hash, first_name, last_name, display_name, is_active, created_by
            )
            logger.info(f"Created user {row['id']} with password authentication")
            return UserRecord(**dict(row))
    
    async def get_user_by_id(self, tenant_id: int, user_id: int) -> Optional[UserRecord]:
        """Get user by ID (with tenant isolation)."""
        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                """
                SELECT * FROM users
                WHERE id = $1 AND tenant_id = $2
                """,
                user_id, tenant_id
            )
            return UserRecord(**dict(row)) if row else None
    
    async def get_user_by_email(self, tenant_id: int, email: str) -> Optional[UserRecord]:
        """Get user by email (case-insensitive)."""
        # Normalize email to lowercase for case-insensitive matching
        email = email.lower() if email else email
        
        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                """
                SELECT * FROM users
                WHERE tenant_id = $1 AND email = $2
                """,
                tenant_id, email
            )
            return UserRecord(**dict(row)) if row else None
    
    async def authenticate_with_password(
        self, 
        tenant_id: int, 
        email: str, 
        password: str
    ) -> Optional[Dict[str, Any]]:
        """
        Authenticate user with email and password.
        
        Shared authentication function used by both STANDALONE and PLATFORM modes.
        Returns user data dict if authentication succeeds, None if it fails.
        
        Args:
            tenant_id: Tenant ID
            email: User email
            password: Plain text password to verify
            
        Returns:
            Dict with user data (id, email, first_name, last_name, display_name, is_active)
            or None if authentication fails
        """
        from .password_utils import verify_password
        
        # Normalize email to lowercase for case-insensitive matching
        email = email.lower() if email else email
        
        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            # Get user with password hash
            user_row = await conn.fetchrow(
                """
                SELECT id, email, first_name, last_name, display_name, is_active, password_hash
                FROM users
                WHERE tenant_id = $1 AND email = $2
                """,
                tenant_id, email
            )
            
            # Check if user exists and has password hash
            if not user_row or not user_row["password_hash"]:
                logger.warning(f"Password authentication failed for {email}: user not found or no password set")
                return None
            
            # Verify password
            if not verify_password(password, user_row["password_hash"]):
                logger.warning(f"Password authentication failed for {email}: invalid password")
                return None
            
            # Check if user is active
            if not user_row["is_active"]:
                logger.warning(f"Password authentication failed for {email}: user is inactive")
                return None
            
            logger.info(f"Password authentication successful for {email} (user_id={user_row['id']})")
            return dict(user_row)
    
    async def list_users(
        self, 
        tenant_id: int, 
        is_active: Optional[bool] = None,
        limit: int = 100,
        offset: int = 0
    ) -> List[UserRecord]:
        """List users for a tenant."""
        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            if is_active is not None:
                rows = await conn.fetch(
                    """
                    SELECT * FROM users
                    WHERE tenant_id = $1 AND is_active = $2
                    ORDER BY created_at DESC
                    LIMIT $3 OFFSET $4
                    """,
                    tenant_id, is_active, limit, offset
                )
            else:
                rows = await conn.fetch(
                    """
                    SELECT * FROM users
                    WHERE tenant_id = $1
                    ORDER BY created_at DESC
                    LIMIT $2 OFFSET $3
                    """,
                    tenant_id, limit, offset
                )
            return [UserRecord(**dict(row)) for row in rows]
    
    async def update_user(
        self,
        tenant_id: int,
        user_id: int,
        first_name: Optional[str] = None,
        last_name: Optional[str] = None,
        display_name: Optional[str] = None,
        is_active: Optional[bool] = None,
        password: Optional[str] = None,
        updated_by: Optional[int] = None,
    ) -> UserRecord:
        """Update user."""
        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            # Build dynamic update
            updates = []
            params = []
            param_idx = 1
            
            if first_name is not None:
                updates.append(f"first_name = ${param_idx}")
                params.append(first_name)
                param_idx += 1
            
            if last_name is not None:
                updates.append(f"last_name = ${param_idx}")
                params.append(last_name)
                param_idx += 1
            
            if display_name is not None:
                updates.append(f"display_name = ${param_idx}")
                params.append(display_name)
                param_idx += 1
            
            if is_active is not None:
                updates.append(f"is_active = ${param_idx}")
                params.append(is_active)
                param_idx += 1
            
            if password is not None:
                from .password_utils import hash_password
                password_hash = hash_password(password)
                updates.append(f"password_hash = ${param_idx}")
                params.append(password_hash)
                param_idx += 1
            
            if updated_by is not None:
                updates.append(f"updated_by = ${param_idx}")
                params.append(updated_by)
                param_idx += 1
            
            updates.append("updated_at = NOW()")
            
            if not updates:
                raise ValueError("No fields to update")
            
            params.extend([user_id, tenant_id])
            
            row = await conn.fetchrow(
                f"""
                UPDATE users
                SET {', '.join(updates)}
                WHERE id = ${param_idx} AND tenant_id = ${param_idx + 1}
                RETURNING *
                """,
                *params
            )
            
            if not row:
                raise UserNotFoundError(f"User {user_id} not found in tenant {tenant_id}")
            
            logger.info(f"Updated user {user_id}")
            return UserRecord(**dict(row))
    
    async def deactivate_user(
        self,
        tenant_id: int,
        user_id: int,
        updated_by: Optional[int] = None,
    ) -> None:
        """Deactivate user and revoke all sessions."""
        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            # Verify user belongs to tenant
            user = await self.get_user_by_id(tenant_id, user_id)
            if not user:
                raise UserNotFoundError(f"User {user_id} not found in tenant {tenant_id}")
            
            # Mark user inactive
            if updated_by is not None:
                await conn.execute(
                    "UPDATE users SET is_active = FALSE, updated_by = $1, updated_at = NOW() WHERE id = $2",
                    updated_by,
                    user_id,
                )
            else:
                await conn.execute(
                    "UPDATE users SET is_active = FALSE, updated_at = NOW() WHERE id = $1",
                    user_id,
                )
            
            # Revoke all sessions (match by email since sessions use external_user_id)
            if updated_by is not None:
                await conn.execute(
                    """
                    UPDATE sessions s
                    SET is_revoked = TRUE, updated_by = $1, updated_at = NOW()
                    FROM users u
                    WHERE u.id = $2
                      AND s.user_attributes->>'email' = u.email
                      AND s.is_revoked = FALSE
                    """,
                    updated_by,
                    user_id,
                )
            else:
                await conn.execute(
                    """
                    UPDATE sessions s
                    SET is_revoked = TRUE, updated_at = NOW()
                    FROM users u
                    WHERE u.id = $1 
                      AND s.user_attributes->>'email' = u.email
                      AND s.is_revoked = FALSE
                    """,
                    user_id,
                )
            logger.info(f"Deactivated user {user_id} and revoked sessions")
    
    async def get_user_identities(self, tenant_id: int, user_id: int) -> List[UserIdentityRecord]:
        """Get all provider identities for a user."""
        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            # Verify user belongs to tenant
            user = await self.get_user_by_id(tenant_id, user_id)
            if not user:
                raise UserNotFoundError(f"User {user_id} not found in tenant {tenant_id}")
            
            rows = await conn.fetch(
                """
                SELECT ui.id, ui.user_id, ui.provider_id, ui.external_user_id,
                       ui.idp_attributes, ui.last_synced_at, ui.created_at, ui.updated_at,
                       p.provider_name
                FROM user_identities ui
                JOIN providers p ON p.id = ui.provider_id
                WHERE ui.user_id = $1
                """,
                user_id
            )
            # Convert JSONB string to dict for idp_attributes
            result = []
            for row in rows:
                row_dict = dict(row)
                if isinstance(row_dict.get('idp_attributes'), str):
                    row_dict['idp_attributes'] = json.loads(row_dict['idp_attributes'])
                result.append(UserIdentityRecord(**row_dict))
            return result
    
    # ──────────────────────────────────────────────
    # GROUP OPERATIONS
    # ──────────────────────────────────────────────
    
    async def create_group(
        self,
        tenant_id: int,
        group_name: str,
        parent_group_id: Optional[int] = None,
        description: Optional[str] = None,
        is_default: bool = False,
        created_by: Optional[int] = None,
    ) -> GroupRecord:
        """Create a new group."""
        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            # Validate only one default group per tenant
            if is_default:
                existing_default = await conn.fetchval(
                    "SELECT COUNT(*) FROM u_groups WHERE tenant_id = $1 AND is_default = TRUE AND is_active = TRUE",
                    tenant_id
                )
                if existing_default > 0:
                    raise ValueError(f"Tenant {tenant_id} already has a default group. Only one default group allowed per tenant.")
            
            # Verify parent group belongs to same tenant if specified
            if parent_group_id:
                parent = await conn.fetchrow(
                    "SELECT id FROM u_groups WHERE id = $1 AND tenant_id = $2",
                    parent_group_id, tenant_id
                )
                if not parent:
                    raise GroupNotFoundError(f"Parent group {parent_group_id} not found in tenant {tenant_id}")
            
            row = await conn.fetchrow(
                """
                INSERT INTO u_groups (tenant_id, name, parent_group_id, description, is_default, created_by, updated_by)
                VALUES ($1, $2, $3, $4, $5, $6, $6)
                RETURNING
                    id,
                    tenant_id,
                    name AS group_name,
                    parent_group_id,
                    description,
                    is_active,
                    is_default,
                    created_at,
                    updated_at,
                    created_by,
                    updated_by
                """,
                tenant_id,
                group_name,
                parent_group_id,
                description,
                is_default,
                created_by,
            )
            logger.info(f"Created group {row['id']}: {group_name} (is_default={is_default})")
            return GroupRecord(**dict(row))
    
    async def get_group(self, tenant_id: int, group_id: int) -> Optional[GroupRecord]:
        """Get group by ID."""
        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                """
                SELECT
                    id,
                    tenant_id,
                    name AS group_name,
                    parent_group_id,
                    description,
                    is_active,
                    is_default,
                    created_at,
                    updated_at,
                    created_by,
                    updated_by
                FROM u_groups
                WHERE id = $1 AND tenant_id = $2
                """,
                group_id, tenant_id
            )
            return GroupRecord(**dict(row)) if row else None
    
    async def list_groups(
        self, 
        tenant_id: int,
        is_active: Optional[bool] = None,
        parent_group_id: Optional[int] = None,
    ) -> List[GroupRecord]:
        """List groups for a tenant."""
        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            if is_active is not None and parent_group_id is not None:
                rows = await conn.fetch(
                    """
                    SELECT
                        id,
                        tenant_id,
                        name AS group_name,
                        parent_group_id,
                        description,
                        is_active,
                        is_default,
                        created_at,
                        updated_at,
                        created_by,
                        updated_by
                    FROM u_groups
                    WHERE tenant_id = $1 AND is_active = $2 AND parent_group_id = $3
                    ORDER BY name
                    """,
                    tenant_id, is_active, parent_group_id
                )
            elif is_active is not None:
                rows = await conn.fetch(
                    """
                    SELECT
                        id,
                        tenant_id,
                        name AS group_name,
                        parent_group_id,
                        description,
                        is_active,
                        is_default,
                        created_at,
                        updated_at,
                        created_by,
                        updated_by
                    FROM u_groups
                    WHERE tenant_id = $1 AND is_active = $2
                    ORDER BY name
                    """,
                    tenant_id, is_active
                )
            elif parent_group_id is not None:
                rows = await conn.fetch(
                    """
                    SELECT
                        id,
                        tenant_id,
                        name AS group_name,
                        parent_group_id,
                        description,
                        is_active,
                        is_default,
                        created_at,
                        updated_at,
                        created_by,
                        updated_by
                    FROM u_groups
                    WHERE tenant_id = $1 AND parent_group_id = $2
                    ORDER BY name
                    """,
                    tenant_id, parent_group_id
                )
            else:
                rows = await conn.fetch(
                    """
                    SELECT
                        id,
                        tenant_id,
                        name AS group_name,
                        parent_group_id,
                        description,
                        is_active,
                        is_default,
                        created_at,
                        updated_at,
                        created_by,
                        updated_by
                    FROM u_groups
                    WHERE tenant_id = $1
                    ORDER BY name
                    """,
                    tenant_id
                )
            return [GroupRecord(**dict(row)) for row in rows]
    
    async def update_group(
        self,
        tenant_id: int,
        group_id: int,
        group_name: Optional[str] = None,
        parent_group_id: Optional[int] = None,
        description: Optional[str] = None,
        is_active: Optional[bool] = None,
        is_default: Optional[bool] = None,
        updated_by: Optional[int] = None,
    ) -> GroupRecord:
        """Update group."""
        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            # Validate only one default group per tenant
            if is_default is True:
                existing_default = await conn.fetchrow(
                    "SELECT id FROM u_groups WHERE tenant_id = $1 AND is_default = TRUE AND is_active = TRUE AND id != $2",
                    tenant_id, group_id
                )
                if existing_default:
                    raise ValueError(f"Tenant {tenant_id} already has a default group (id={existing_default['id']}). Only one default group allowed per tenant.")
            
            # Verify parent group if specified
            if parent_group_id:
                parent = await conn.fetchrow(
                    "SELECT id FROM u_groups WHERE id = $1 AND tenant_id = $2",
                    parent_group_id, tenant_id
                )
                if not parent:
                    raise GroupNotFoundError(f"Parent group {parent_group_id} not found")
            
            updates = []
            params = []
            param_idx = 1
            
            if group_name is not None:
                updates.append(f"name = ${param_idx}")
                params.append(group_name)
                param_idx += 1
            
            if parent_group_id is not None:
                updates.append(f"parent_group_id = ${param_idx}")
                params.append(parent_group_id)
                param_idx += 1
            
            if description is not None:
                updates.append(f"description = ${param_idx}")
                params.append(description)
                param_idx += 1
            
            if is_active is not None:
                updates.append(f"is_active = ${param_idx}")
                params.append(is_active)
                param_idx += 1
            
            if is_default is not None:
                updates.append(f"is_default = ${param_idx}")
                params.append(is_default)
                param_idx += 1
            
            if updated_by is not None:
                updates.append(f"updated_by = ${param_idx}")
                params.append(updated_by)
                param_idx += 1
            
            updates.append("updated_at = NOW()")
            
            if not updates:
                raise ValueError("No fields to update")
            
            params.extend([group_id, tenant_id])
            
            row = await conn.fetchrow(
                f"""
                UPDATE u_groups
                SET {', '.join(updates)}
                WHERE id = ${param_idx} AND tenant_id = ${param_idx + 1}
                RETURNING
                    id,
                    tenant_id,
                    name AS group_name,
                    parent_group_id,
                    description,
                    is_active,
                    is_default,
                    created_at,
                    updated_at,
                    created_by,
                    updated_by
                """,
                *params
            )
            
            if not row:
                raise GroupNotFoundError(f"Group {group_id} not found in tenant {tenant_id}")
            
            logger.info(f"Updated group {group_id}")
            return GroupRecord(**dict(row))
    
    async def get_user_groups(self, tenant_id: int, user_id: int) -> List[GroupRecord]:
        """Get all groups for a user."""
        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            # Verify user belongs to tenant
            user = await self.get_user_by_id(tenant_id, user_id)
            if not user:
                raise UserNotFoundError(f"User {user_id} not found in tenant {tenant_id}")
            
            rows = await conn.fetch(
                """
                SELECT
                    g.id,
                    g.tenant_id,
                    g.name AS group_name,
                    g.parent_group_id,
                    g.description,
                    g.is_active,
                    g.created_at,
                    g.updated_at,
                    g.created_by,
                    g.updated_by
                FROM user_groups ug
                JOIN u_groups g ON g.id = ug.group_id
                WHERE ug.user_id = $1 AND g.is_active = TRUE
                ORDER BY g.name
                """,
                user_id
            )
            return [GroupRecord(**dict(row)) for row in rows]
    
    async def assign_user_to_group(
        self,
        tenant_id: int,
        user_id: int,
        group_id: int,
        assigned_by: Optional[int] = None
    ) -> None:
        """
        Assign user to a group.

        If assigning to a non-default group, auto-remove user from default group
        (default group only serves as fallback when user has no other group).
        """
        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            # Verify user belongs to tenant
            user = await self.get_user_by_id(tenant_id, user_id)
            if not user:
                raise UserNotFoundError(f"User {user_id} not found in tenant {tenant_id}")

            # Verify group belongs to tenant
            group = await self.get_group(tenant_id, group_id)
            if not group:
                raise GroupNotFoundError(f"Group {group_id} not found in tenant {tenant_id}")

            # Assign user to requested group
            await conn.execute(
                """
                INSERT INTO user_groups (tenant_id, user_id, group_id, assigned_by)
                VALUES ($1, $2, $3, $4)
                ON CONFLICT (user_id, group_id) DO NOTHING
                """,
                tenant_id, user_id, group_id, assigned_by
            )
            logger.info(f"Assigned user {user_id} to group {group_id}")

            # If assigning to a non-default group, remove user from default group
            if not group.is_default:
                default_group = await conn.fetchrow(
                    """
                    SELECT g.id FROM u_groups g
                    JOIN user_groups ug ON ug.group_id = g.id
                    WHERE ug.user_id = $1
                      AND g.tenant_id = $2
                      AND g.is_default = TRUE
                      AND g.is_active = TRUE
                    """,
                    user_id, tenant_id
                )

                if default_group:
                    await conn.execute(
                        """
                        DELETE FROM user_groups
                        WHERE user_id = $1 AND group_id = $2
                        """,
                        user_id, default_group['id']
                    )
                    logger.info(f"Auto-removed user {user_id} from default group (assigned to non-default group {group_id})")
    
    async def remove_user_from_group(self, tenant_id: int, user_id: int, group_id: int, removed_by: Optional[int] = None) -> None:
        """Remove user from a group."""
        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            # Verify both belong to tenant
            user = await self.get_user_by_id(tenant_id, user_id)
            if not user:
                raise UserNotFoundError(f"User {user_id} not found in tenant {tenant_id}")
            
            group = await self.get_group(tenant_id, group_id)
            if not group:
                raise GroupNotFoundError(f"Group {group_id} not found in tenant {tenant_id}")
            
            await conn.execute(
                "DELETE FROM user_groups WHERE user_id = $1 AND group_id = $2",
                user_id, group_id
            )
            logger.info(f"Removed user {user_id} from group {group_id}")
    
    # ──────────────────────────────────────────────
    # ROLE OPERATIONS
    # ──────────────────────────────────────────────
    
    async def create_role(
        self,
        tenant_id: int,
        role_name: str,
        description: Optional[str] = None,
        created_by: Optional[int] = None,
    ) -> RoleRecord:
        """Create a new role."""
        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                """
                INSERT INTO roles (tenant_id, name, description, created_by, updated_by)
                VALUES ($1, $2, $3, $4, $4)
                RETURNING
                    id,
                    tenant_id,
                    name AS role_name,
                    description,
                    is_active,
                    created_at,
                    updated_at,
                    created_by,
                    updated_by
                """,
                tenant_id,
                role_name,
                description,
                created_by,
            )
            logger.info(f"Created role {row['id']}: {role_name}")
            return RoleRecord(**dict(row))
    
    async def get_role(self, tenant_id: int, role_id: int) -> Optional[RoleRecord]:
        """Get role by ID."""
        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                """
                SELECT
                    id,
                    tenant_id,
                    name AS role_name,
                    description,
                    is_active,
                    created_at,
                    updated_at,
                    created_by,
                    updated_by
                FROM roles
                WHERE id = $1 AND tenant_id = $2
                """,
                role_id, tenant_id
            )
            return RoleRecord(**dict(row)) if row else None
    
    async def list_roles(
        self, 
        tenant_id: int,
        is_active: Optional[bool] = None,
    ) -> List[RoleRecord]:
        """List roles for a tenant."""
        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            if is_active is not None:
                rows = await conn.fetch(
                    """
                    SELECT
                        id,
                        tenant_id,
                        name AS role_name,
                        description,
                        is_active,
                        created_at,
                        updated_at,
                        created_by,
                        updated_by
                    FROM roles
                    WHERE tenant_id = $1 AND is_active = $2
                    ORDER BY name
                    """,
                    tenant_id, is_active
                )
            else:
                rows = await conn.fetch(
                    """
                    SELECT
                        id,
                        tenant_id,
                        name AS role_name,
                        description,
                        is_active,
                        created_at,
                        updated_at,
                        created_by,
                        updated_by
                    FROM roles
                    WHERE tenant_id = $1
                    ORDER BY name
                    """,
                    tenant_id
                )
            return [RoleRecord(**dict(row)) for row in rows]
    
    async def update_role(
        self,
        tenant_id: int,
        role_id: int,
        role_name: Optional[str] = None,
        description: Optional[str] = None,
        is_active: Optional[bool] = None,
        updated_by: Optional[int] = None,
    ) -> RoleRecord:
        """Update role."""
        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            updates = []
            params = []
            param_idx = 1
            
            if role_name is not None:
                updates.append(f"name = ${param_idx}")
                params.append(role_name)
                param_idx += 1
            
            if description is not None:
                updates.append(f"description = ${param_idx}")
                params.append(description)
                param_idx += 1
            
            if is_active is not None:
                updates.append(f"is_active = ${param_idx}")
                params.append(is_active)
                param_idx += 1
            
            if updated_by is not None:
                updates.append(f"updated_by = ${param_idx}")
                params.append(updated_by)
                param_idx += 1
            
            updates.append("updated_at = NOW()")
            
            if not updates:
                raise ValueError("No fields to update")
            
            params.extend([role_id, tenant_id])
            
            row = await conn.fetchrow(
                f"""
                UPDATE roles
                SET {', '.join(updates)}
                WHERE id = ${param_idx} AND tenant_id = ${param_idx + 1}
                RETURNING
                    id,
                    tenant_id,
                    name AS role_name,
                    description,
                    is_active,
                    created_at,
                    updated_at,
                    created_by,
                    updated_by
                """,
                *params
            )
            
            if not row:
                raise RoleNotFoundError(f"Role {role_id} not found in tenant {tenant_id}")
            
            logger.info(f"Updated role {role_id}")
            return RoleRecord(**dict(row))
    
    async def assign_role_to_group(
        self,
        tenant_id: int,
        group_id: int,
        role_id: int,
        assigned_by: Optional[int] = None
    ) -> None:
        """Assign role to a group."""
        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            # Verify group belongs to tenant
            group = await self.get_group(tenant_id, group_id)
            if not group:
                raise GroupNotFoundError(f"Group {group_id} not found in tenant {tenant_id}")
            
            # Verify role belongs to tenant
            role = await self.get_role(tenant_id, role_id)
            if not role:
                raise RoleNotFoundError(f"Role {role_id} not found in tenant {tenant_id}")
            
            await conn.execute(
                """
                INSERT INTO group_roles (group_id, role_id, assigned_by)
                VALUES ($1, $2, $3)
                ON CONFLICT (group_id, role_id) DO NOTHING
                """,
                group_id, role_id, assigned_by
            )
            logger.info(f"Assigned role {role_id} to group {group_id}")
    
    async def remove_role_from_group(self, tenant_id: int, group_id: int, role_id: int) -> None:
        """Remove role from a group."""
        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            # Verify both belong to tenant
            group = await self.get_group(tenant_id, group_id)
            if not group:
                raise GroupNotFoundError(f"Group {group_id} not found in tenant {tenant_id}")
            
            role = await self.get_role(tenant_id, role_id)
            if not role:
                raise RoleNotFoundError(f"Role {role_id} not found in tenant {tenant_id}")
            
            await conn.execute(
                "DELETE FROM group_roles WHERE group_id = $1 AND role_id = $2",
                group_id, role_id
            )
            logger.info(f"Removed role {role_id} from group {group_id}")

    async def list_group_roles(self, group_id: int) -> List[dict]:
        """Get all roles assigned to a group."""
        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            rows = await conn.fetch("""
                SELECT r.id, r.tenant_id, r.name AS role_name, r.description, r.is_active,
                       r.created_at, r.updated_at, r.created_by, r.updated_by
                FROM roles r
                JOIN group_roles gr ON gr.role_id = r.id
                WHERE gr.group_id = $1
                ORDER BY r.name
            """, group_id)
        return [dict(row) for row in rows]

    async def get_user_roles(self, tenant_id: int, user_id: int) -> List[RoleRecord]:
        """Get all roles for a user (including inherited from parent groups)."""
        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            # Verify user belongs to tenant
            user = await self.get_user_by_id(tenant_id, user_id)
            if not user:
                raise UserNotFoundError(f"User {user_id} not found in tenant {tenant_id}")
            
            rows = await conn.fetch(
                """
                WITH RECURSIVE group_tree AS (
                    -- Direct groups
                    SELECT ug.group_id, 0 AS depth
                    FROM user_groups ug
                    WHERE ug.user_id = $1
                    
                    UNION ALL
                    
                    -- Parent groups
                    SELECT g.parent_group_id, gt.depth + 1
                    FROM group_tree gt
                    JOIN u_groups g ON g.id = gt.group_id
                    WHERE g.parent_group_id IS NOT NULL AND gt.depth < 10
                )
                SELECT DISTINCT
                    r.id,
                    r.tenant_id,
                    r.name AS role_name,
                    r.description,
                    r.is_active,
                    r.created_at,
                    r.updated_at,
                    r.created_by,
                    r.updated_by
                FROM group_tree gt
                JOIN group_roles gr ON gr.group_id = gt.group_id
                JOIN roles r ON r.id = gr.role_id
                WHERE r.is_active = TRUE
                ORDER BY r.name
                """,
                user_id
            )
            return [RoleRecord(**dict(row)) for row in rows]
    
    async def delete_group(
        self,
        tenant_id: int,
        group_id: int,
        updated_by: Optional[int] = None,
    ) -> dict:
        """
        Soft delete group with detailed warnings about impact.
        
        Returns dict with:
            - deleted: bool
            - warnings: List[str] with detailed information about affected resources
        """
        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            # Check if group exists
            group = await conn.fetchrow(
                """
                SELECT id, name, is_default, is_active
                FROM u_groups
                WHERE tenant_id = $1 AND id = $2
                """,
                tenant_id, group_id
            )
            
            if not group:
                raise GroupNotFoundError(f"Group {group_id} not found in tenant {tenant_id}")
            
            if not group["is_active"]:
                raise ValueError(f"Group '{group['name']}' is already deleted")
            
            warnings = []
            
            # Count users in this group
            user_count = await conn.fetchval(
                "SELECT COUNT(*) FROM user_groups WHERE group_id = $1",
                group_id
            )
            if user_count > 0:
                warnings.append(f"{user_count} user(s) will lose access to this group")
            
            # Count roles assigned to this group
            role_count = await conn.fetchval(
                "SELECT COUNT(*) FROM group_roles WHERE group_id = $1",
                group_id
            )
            if role_count > 0:
                # Get role names for detailed warning
                role_rows = await conn.fetch(
                    """
                    SELECT r.name
                    FROM group_roles gr
                    JOIN roles r ON r.id = gr.role_id
                    WHERE gr.group_id = $1
                    """,
                    group_id
                )
                role_names = [row["name"] for row in role_rows]
                warnings.append(f"{role_count} role(s) assigned to this group will no longer apply: {', '.join(role_names)}")
            
            # Count child groups
            child_count = await conn.fetchval(
                "SELECT COUNT(*) FROM u_groups WHERE parent_group_id = $1 AND is_active = TRUE",
                group_id
            )
            if child_count > 0:
                warnings.append(f"{child_count} child group(s) will also be deactivated")
            
            # Default group warning
            if group["is_default"]:
                warnings.append("⚠️ This is the default group - new users will not be automatically assigned to any group")
            
            # Soft delete the group
            if updated_by is not None:
                await conn.execute(
                    "UPDATE u_groups SET is_active = FALSE, updated_by = $1, updated_at = NOW() WHERE id = $2",
                    updated_by,
                    group_id,
                )
            else:
                await conn.execute(
                    "UPDATE u_groups SET is_active = FALSE, updated_at = NOW() WHERE id = $1",
                    group_id,
                )
            
            # Cascade deactivate child groups
            if child_count > 0:
                if updated_by is not None:
                    await conn.execute(
                        """
                        UPDATE u_groups 
                        SET is_active = FALSE, updated_by = $1, updated_at = NOW() 
                        WHERE parent_group_id = $2 AND is_active = TRUE
                        """,
                        updated_by,
                        group_id,
                    )
                else:
                    await conn.execute(
                        """
                        UPDATE u_groups 
                        SET is_active = FALSE, updated_at = NOW() 
                        WHERE parent_group_id = $1 AND is_active = TRUE
                        """,
                        group_id,
                    )
            
            logger.info(f"Soft deleted group {group_id} ('{group['name']}') in tenant {tenant_id}")
            
            return {
                "deleted": True,
                "group_name": group["name"],
                "warnings": warnings
            }
    
    async def delete_role(
        self,
        tenant_id: int,
        role_id: int,
        updated_by: Optional[int] = None,
    ) -> dict:
        """
        Soft delete role with detailed warnings about impact.
        
        Returns dict with:
            - deleted: bool
            - warnings: List[str] with detailed information about affected resources
        """
        pool = self._db._need_pool()
        async with pool.acquire() as conn:
            # Check if role exists
            role = await conn.fetchrow(
                """
                SELECT id, name, is_active
                FROM roles
                WHERE tenant_id = $1 AND id = $2
                """,
                tenant_id, role_id
            )
            
            if not role:
                raise RoleNotFoundError(f"Role {role_id} not found in tenant {tenant_id}")
            
            if not role["is_active"]:
                raise ValueError(f"Role '{role['name']}' is already deleted")
            
            warnings = []
            
            # Count groups with this role assigned
            group_count = await conn.fetchval(
                "SELECT COUNT(*) FROM group_roles WHERE role_id = $1",
                role_id
            )
            if group_count > 0:
                # Get group names for detailed warning
                group_rows = await conn.fetch(
                    """
                    SELECT g.name
                    FROM group_roles gr
                    JOIN u_groups g ON g.id = gr.group_id
                    WHERE gr.role_id = $1
                    """,
                    role_id
                )
                group_names = [row["name"] for row in group_rows]
                warnings.append(f"{group_count} group(s) will lose this role: {', '.join(group_names)}")
            
            # Count affected users (users in groups with this role)
            user_count = await conn.fetchval(
                """
                SELECT COUNT(DISTINCT ug.user_id)
                FROM user_groups ug
                JOIN group_roles gr ON gr.group_id = ug.group_id
                WHERE gr.role_id = $1
                """,
                role_id
            )
            if user_count > 0:
                warnings.append(f"{user_count} user(s) will lose permissions granted by this role")
            
            # Soft delete the role
            if updated_by is not None:
                await conn.execute(
                    "UPDATE roles SET is_active = FALSE, updated_by = $1, updated_at = NOW() WHERE id = $2",
                    updated_by,
                    role_id,
                )
            else:
                await conn.execute(
                    "UPDATE roles SET is_active = FALSE, updated_at = NOW() WHERE id = $1",
                    role_id,
                )
            
            logger.info(f"Soft deleted role {role_id} ('{role['name']}') in tenant {tenant_id}")
            
            return {
                "deleted": True,
                "role_name": role["name"],
                "warnings": warnings
            }
