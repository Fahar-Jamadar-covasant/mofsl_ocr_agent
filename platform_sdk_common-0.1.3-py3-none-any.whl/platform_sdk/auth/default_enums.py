# DEPRECATED: Roles should be dynamic from database, not hardcoded enums
# This file is kept for backward compatibility but should not be used
# All role management should use the database via AuthDatabase methods

from enum import Enum

class CAMS_ACTIONS(str, Enum):
    # Standard actions that can be used as defaults
    READ = "read"
    WRITE = "write"
    UPDATE = "update"
    DELETE = "delete"
    MANAGE = "manage"
    GOVERN_POLICIES = "govern_policies"
    CREATE = "create"
    EXECUTE = "execute"

# NOTE: CAMS_ROLE enum removed - use dynamic roles from database
