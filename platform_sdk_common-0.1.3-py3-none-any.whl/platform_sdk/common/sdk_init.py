from fastapi import FastAPI
from fastapi import Request
from fastapi.responses import JSONResponse
import logging
from platform_sdk.auth.rbac_policy_cache import init_redis_pool

async def _global_fastapi_exception_handler(request: Request, exc: Exception):
    logging.error(f"Unhandled exception: {exc}", exc_info=True)
    return JSONResponse(
        status_code=500,
        content={"detail": "An unexpected error occurred. Please try again later."},
    )

def _register_global_exception_handler(app: FastAPI):
    app.add_exception_handler(Exception, _global_fastapi_exception_handler)


def sdk_init(app: FastAPI, redis_config: dict = None):
    """Initialize the Platform SDK with necessary configurations and global handlers.
    """
    _register_global_exception_handler(app)
    if redis_config:
        init_redis_pool(**redis_config)

