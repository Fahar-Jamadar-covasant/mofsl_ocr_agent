"""
Covasant Platform SDK - Common Module

Shared utilities, base classes, and common interfaces used across all SDK packages.
"""

__version__ = "0.1.0"

from .interfaces import (
    BaseConfig,
    BaseProvider,
    ProviderFactory,
    SDKException,
    ConfigurationError,
    ValidationError,
)

__all__ = [
    "BaseConfig",
    "BaseProvider",
    "ProviderFactory",
    "SDKException",
    "ConfigurationError",
    "ValidationError",
]
