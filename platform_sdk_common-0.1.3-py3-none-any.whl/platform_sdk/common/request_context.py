# from uuid import uuid4

# class RequestContext:
    
#     """Class to hold request context information such as 
#     request_id, tenant_name, scope_name, app_name, userid 
#     and any other relevant information that can be used for logging and tracing.
#     """

#     def __init__(self, request_id:str, tenant_name:str, scope_name:str, app_name:str, userid:str, session_id:str = 'N/A' ,agent_id:str = 'N/A', service_name:str = 'cams'):
#         if request_id is None or request_id == '' or request_id == 'N/A':
#             self.request_id = uuid4().hex.lower()
#         else:
#             self.request_id = request_id
#         self.tenant_name = tenant_name
#         self.scope_name = scope_name
#         self.app_name = app_name
#         self.userid = userid
#         self.session_id = session_id
#         self.service_name = service_name
#         if agent_id is None or agent_id == '' or agent_id == 'N/A':
#             self.agent_id = uuid4().hex.lower()
#         else:
#             self.agent_id = agent_id

#         self.observability_client = None
#         self.extra_logging_attributes = { "request_id": self.request_id, "tenant_name": self.tenant_name, "scope_name": self.scope_name, "app_name": self.app_name, "userid": self.userid, "session_id": self.session_id, "agent_id": self.agent_id}