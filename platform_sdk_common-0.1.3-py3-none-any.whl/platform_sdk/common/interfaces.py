"""
Common interfaces and base classes for Platform SDK.
"""

from abc import ABC, abstractmethod
from typing import Any, Dict, Generic, Optional, TypeVar
from pydantic import BaseModel, ConfigDict


class SDKException(Exception):
    """
    Base exception for all Platform SDK errors.
    
    This is the root exception class for the Platform SDK. All SDK-specific
    exceptions should inherit from this class to enable consistent error handling.
    
    Attributes:
        message (str): Human-readable error message
        details (Dict[str, Any]): Additional error context and details
    
    Example:
        ```python
        raise SDKException(
            "Operation failed",
            details={"operation": "data_sync", "retry_count": 3}
        )
        ```
    """
    
    def __init__(self, message: str, details: Optional[Dict[str, Any]] = None):
        """
        Initialize SDK exception.
        
        Args:
            message: Human-readable error message
            details: Optional dictionary containing additional error context
        """
        super().__init__(message)
        self.message = message
        self.details = details or {}


class ConfigurationError(SDKException):
    """
    Raised when configuration is invalid or missing.
    
    This exception is raised when provider configuration is incomplete,
    invalid, or contains conflicting values.
    
    Example:
        ```python
        if not config.api_key:
            raise ConfigurationError(
                "API key is required",
                details={"config_field": "api_key"}
            )
        ```
    """
    pass


class ValidationError(SDKException):
    """
    Raised when validation fails.
    
    This exception is raised when input validation fails, such as
    invalid parameter types, out-of-range values, or constraint violations.
    
    Example:
        ```python
        if age < 0:
            raise ValidationError(
                "Age must be positive",
                details={"field": "age", "value": age}
            )
        ```
    """
    pass


class BaseConfig(BaseModel):
    """
    Base configuration class using Pydantic for validation.
    
    All SDK configuration classes should inherit from this base class
    to leverage Pydantic's validation capabilities and ensure type safety.
    
    Features:
        - Automatic type validation
        - Field validation on assignment
        - JSON schema generation
        - Serialization/deserialization support
    
    Example:
        ```python
        from pydantic import Field
        
        class MyServiceConfig(BaseConfig):
            api_key: str = Field(..., description="API authentication key")
            timeout: int = Field(default=30, ge=1, description="Request timeout")
            retry_count: int = Field(default=3, ge=0, le=10)
        
        config = MyServiceConfig(api_key="secret", timeout=60)
        ```
    """
    
    model_config = ConfigDict(
        arbitrary_types_allowed=True,
        validate_assignment=True
    )


T = TypeVar('T')


class BaseProvider(ABC, Generic[T]):
    """
    Abstract base class for all SDK providers.
    
    Providers implement specific functionality (IAM, Licensing, Telemetry, etc.)
    and can have multiple implementations for different cloud providers
    (Azure, GCP, AWS, etc.) or deployment modes.
    
    Type Parameters:
        T: The configuration type for this provider
    
    Attributes:
        config (BaseConfig): Provider configuration
        _initialized (bool): Whether the provider has been initialized
    
    Lifecycle:
        1. Create provider instance with configuration
        2. Call `initialize()` to set up resources
        3. Use provider methods
        4. Call `shutdown()` to clean up resources
    
    Example:
        ```python
        class MyProvider(BaseProvider[MyConfig]):
            async def initialize(self) -> None:
                self._client = await create_client(self.config)
                self._initialized = True
            
            async def shutdown(self) -> None:
                if self._client:
                    await self._client.close()
                self._initialized = False
            
            def validate_config(self) -> bool:
                return bool(self.config.api_key)
        
        # Usage
        provider = MyProvider(config)
        await provider.initialize()
        try:
            # Use provider
            pass
        finally:
            await provider.shutdown()
        ```
    """
    
    def __init__(self, config: BaseConfig):
        """
        Initialize the provider with configuration.
        
        Args:
            config: Provider configuration object
        """
        self.config = config
        self._initialized = False
    
    @abstractmethod
    async def initialize(self) -> None:
        """
        Initialize the provider with necessary resources.
        
        This method should set up any connections, clients, or resources
        needed by the provider. It should be called before using the provider.
        
        Raises:
            ConfigurationError: If configuration is invalid
            ConnectionError: If unable to establish required connections
        
        Example:
            ```python
            await provider.initialize()
            ```
        """
        pass
    
    @abstractmethod
    async def shutdown(self) -> None:
        """
        Clean up provider resources.
        
        This method should release all resources, close connections,
        and perform any necessary cleanup. It should be called when
        the provider is no longer needed.
        
        Example:
            ```python
            await provider.shutdown()
            ```
        """
        pass
    
    @abstractmethod
    def validate_config(self) -> bool:
        """
        Validate provider configuration.
        
        This method checks whether the provider's configuration is valid
        and complete. It should verify all required fields and constraints.
        
        Returns:
            True if configuration is valid, False otherwise
        
        Example:
            ```python
            if not provider.validate_config():
                raise ConfigurationError("Invalid provider configuration")
            ```
        """
        pass


class ProviderFactory(ABC, Generic[T]):
    """
    Abstract factory for creating provider instances.
    
    The factory pattern allows for dynamic provider creation based on
    configuration or runtime conditions. This enables support for multiple
    cloud providers and deployment modes without tight coupling.
    
    Type Parameters:
        T: The provider type this factory creates
    
    Example:
        ```python
        class IAMProviderFactory(ProviderFactory[IAMProvider]):
            def create_provider(
                self,
                provider_type: str,
                config: BaseConfig
            ) -> BaseProvider[IAMProvider]:
                if provider_type == "azure":
                    return AzureIAMProvider(config)
                elif provider_type == "gcp":
                    return GCPIAMProvider(config)
                elif provider_type == "aws":
                    return AWSIAMProvider(config)
                else:
                    raise ConfigurationError(
                        f"Unsupported provider type: {provider_type}"
                    )
        
        # Usage
        factory = IAMProviderFactory()
        provider = factory.create_provider("azure", config)
        ```
    """
    
    @abstractmethod
    def create_provider(self, provider_type: str, config: BaseConfig) -> BaseProvider[T]:
        """
        Create a provider instance based on type.
        
        This method instantiates the appropriate provider implementation
        based on the provider_type parameter. It acts as a factory method
        for creating provider instances dynamically.
        
        Args:
            provider_type: Type of provider to create (e.g., 'azure', 'gcp', 'aws')
            config: Configuration object for the provider
            
        Returns:
            Configured provider instance ready for initialization
            
        Raises:
            ConfigurationError: If provider type is not supported or config is invalid
        
        Example:
            ```python
            provider = factory.create_provider("azure", azure_config)
            await provider.initialize()
            ```
        """
        pass
