# import logging
# import os
# import time
# import uuid
# # from opentelemetry import trace, metrics, _logs
# # from opentelemetry.sdk.resources import Resource, logger as otel_logger
# # from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter
# # from opentelemetry.exporter.otlp.proto.grpc.metric_exporter import OTLPMetricExporter
# # from opentelemetry.exporter.otlp.proto.grpc._log_exporter import OTLPLogExporter
# # from opentelemetry.sdk._logs.export import ConsoleLogRecordExporter
# # from opentelemetry.sdk.trace.export import ConsoleSpanExporter
# # from opentelemetry.sdk.metrics.export import ConsoleMetricExporter
# # from opentelemetry.sdk.trace import Tracer, TracerProvider
# # from opentelemetry.sdk.trace.export import BatchSpanProcessor, SimpleSpanProcessor
# # from opentelemetry.sdk.metrics import MeterProvider
# # from opentelemetry.sdk.metrics.export import PeriodicExportingMetricReader
# # from opentelemetry.sdk._logs import LoggerProvider, LoggingHandler
# # from opentelemetry.sdk._logs.export import BatchLogRecordProcessor, SimpleLogRecordProcessor
# # from opentelemetry.metrics import get_meter
# # from opentelemetry.instrumentation.logging import LoggingInstrumentor

# from packages.common.src.platform_sdk.common.request_context_var import get_request_context, get_observability_client
# import platform_sdk.common.cams_constants as cams_constants
# import inspect
# import functools


# def _get_otel_fqn(request_id, tenant_name, scope_name, app_name, userid, name):
#     return cams_constants.OTEL_FQN_FORMAT.format(request_id=request_id, tenant_name=tenant_name, scope_name=scope_name, app_name=app_name, userid=userid, name=name)

# def otel_logger_decorator(func):
#     @functools.wraps(func)
#     def wrapper(obj, message,*args, **kwargs):
#             caller_frame = inspect.stack()[1]
#             module = inspect.getmodule(caller_frame[0])
#             module_name = module.__name__ if module else "unknown"
#             filename = caller_frame.filename
#             lineno = caller_frame.lineno
#             func_name = caller_frame.function
#             asctime = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
#             # levelname = level.upper()
#             final_message = "N/A"
#             request_context = get_request_context()
#             if request_context:
#                 request_id = request_context.request_id
#                 tenant_name = request_context.tenant_name if request_context.tenant_name else "N/A"
#                 scope_name = request_context.scope_name if request_context.scope_name else "N/A"
#                 app_name = request_context.app_name if request_context.app_name else "N/A"
#                 userid = request_context.userid if request_context.userid else "N/A"
#                 session_id = request_context.session_id
#                 agent_id = request_context.agent_id if request_context.agent_id else "N/A"
#                 final_message = f'[TIME={asctime}] - [REQUEST_ID={request_id}] - [TENANT={tenant_name}] - [SCOPE={scope_name}] - [APP={app_name}] - [USER={userid}] - [SESSION_ID={session_id}] - [AGENT_ID={agent_id}] - [MODULE={module_name}] - [FILE={filename}] -[FUNCTION={func_name}] -[LINE_NUMBER={lineno}] - [MESSAGE={message}]'
#             else:
#                 final_message = f'[TIME={asctime}] - [MODULE={module_name}] - [FILE={filename}] -[FUNCTION={func_name}] -[LINE_NUMBER={lineno}] - [MESSAGE={message}]'
#             try:
#                 return func(obj, final_message, *args, **kwargs)
#             except Exception as e:
#                 otel_logger.error(f"Error in otel_logger_decorator: {str(e)}")
#                 return func(obj, message, *args, **kwargs)
#     return wrapper

# def otel_trace(func):
#     parts = func.__qualname__.split('.')
#     #_tracer_name = f"{func.__module__}.{parts[-2]}" if len(parts) >= 2 and '<locals>' not in parts else func.__module__
#     _span_name = func.__qualname__
#     _is_async = inspect.iscoroutinefunction(func)

#     def _apply_span_attributes(span):
#         rc = get_request_context()
#         if rc and rc.extra_logging_attributes:
#             for attr, val in rc.extra_logging_attributes.items():
#                 span.set_attribute(attr, val)
#     if _is_async:
#         @functools.wraps(func)
#         async def async_wrapper(*args, **kwargs):
#                     rc = get_request_context()
#                     oc = get_observability_client()
#                     if rc and oc:
#                         _tracer_name = rc.session_id
#                         with oc._start_span(func_name=_span_name, tracer_name=_tracer_name) as span:
#                             _apply_span_attributes(span)
#                             return await func(*args, **kwargs)
#                     else:
#                         return await func(*args, **kwargs)
#         return async_wrapper
#     else:
#         @functools.wraps(func)
#         def sync_wrapper(*args, **kwargs):
#             rc = get_request_context()
#             oc = get_observability_client()
#             if rc and oc:
#                 _tracer_name = rc.session_id
#                 with oc._start_span(func_name=_span_name, tracer_name=_tracer_name) as span:
#                     _apply_span_attributes(span)
#                     return func(*args, **kwargs)
#             else:
#                 return func(*args, **kwargs)
#         return sync_wrapper

# class Logger_Class():
#     @otel_logger_decorator
#     def info(self, msg, *args, **kwargs):
#         otel_logger.info(msg, *args, **kwargs)
    
#     @otel_logger_decorator
#     def warning(self, msg, *args, **kwargs):
#         otel_logger.warning(msg, *args, **kwargs)
    
#     @otel_logger_decorator
#     def error(self, msg, *args, **kwargs):
#         otel_logger.error(msg, *args, **kwargs)
    
#     @otel_logger_decorator
#     def debug(self, msg, *args, **kwargs):
#         otel_logger.debug(msg, *args, **kwargs)

# Logger = Logger_Class()
        
# class Otel_Client:
#     current_otel_client = None
#     otel_enabled = os.getenv("OTEL_ENABLED")
#     otel_endpoint = None
#     otel_endpoint_is_secure = "false"
#     otel_logging_enabled = "false"
#     otel_console_logging = "false"
#     otel_tracing_enabled = "false"
#     otel_console_tracing = "false"
#     otel_metrics_enabled = "false"
#     otel_console_metrics = "false"
#     otel_metrics_export_interval = 60000,
#     otel_config_uuid = None
#     def __init__(self, otel_config: dict ={'service_name': 'cams', 'environment': 'dev', 'otel_collector_endpoint': cams_constants.DEFAULT_OTEL_COLLECTOR_ENDPOINT, 'otel_export_interval': 60000, 'agent_id': 'N/A'}):
#         self.otel_config = otel_config
#         self.service_name = otel_config['service_name']
#         self.resource = Resource.create({"service.name": otel_config['service_name'], "environment": otel_config['environment'],'agent.id': otel_config.get('agent_id', 'N/A')})
        
#         if not otel_config['otel_enabled']:
#             return 
        
#         self.otel_logging_enabled = otel_config.get('otel_logging_enabled', False)
#         self.otel_console_logging = otel_config.get('otel_console_logging', False)
#         self.otel_console_logging_batched = otel_config.get('otel_console_logging_batched', False)
#         self.otel_remote_logging = otel_config.get('otel_remote_logging', False)
#         self.otel_remote_logging_batched = otel_config.get('otel_remote_logging_batched', False)
#         if self.otel_logging_enabled:
#             LoggingInstrumentor().instrument(set_logging_format=True)
#             self.log_provider = LoggerProvider(resource=self.resource)
#             if self.otel_console_logging:
#                 console_processor = BatchLogRecordProcessor(ConsoleLogRecordExporter()) if self.otel_console_logging_batched else SimpleLogRecordProcessor(ConsoleLogRecordExporter())
#                 self.log_provider.add_log_record_processor(console_processor)
#             if self.otel_remote_logging:
#                 remote_processor = BatchLogRecordProcessor(OTLPLogExporter(endpoint=otel_config['otel_collector_endpoint'], insecure=not otel_config['otel_collector_endpoint_is_secure'])) if self.otel_remote_logging_batched else SimpleLogRecordProcessor(OTLPLogExporter(endpoint=otel_config['otel_collector_endpoint'], insecure=not otel_config['otel_collector_endpoint_is_secure']))  
#                 self.log_provider.add_log_record_processor(remote_processor)
#             _logs.set_logger_provider(self.log_provider)

#             #logging.basicConfig(level=logging.NOTSET, format='%(asctime)s - %(name)s - %(tenant_name)s - %(scope_name)s - %(app_name)s - %(userid)s - %(levelname)s - %(message)s')
#             handler = LoggingHandler(level=otel_config['otel_log_level'], logger_provider=self.log_provider)
#             logging.getLogger().addHandler(handler)


#         self.otel_tracing_enabled = otel_config.get('otel_tracing_enabled', False)
#         self.otel_console_tracing = otel_config.get('otel_console_tracing', False)
#         self.otel_console_tracing_batched = otel_config.get('otel_console_tracing_batched', False)
#         self.otel_remote_tracing = otel_config.get('otel_remote_tracing', False)
#         self.otel_remote_tracing_batched = otel_config.get('otel_remote_tracing_batched', False)
#         if self.otel_tracing_enabled:
#             self.trace_provider = TracerProvider(resource=self.resource)
#             if self.otel_console_tracing:
#                 console_span_processor = BatchSpanProcessor(ConsoleSpanExporter()) if self.otel_console_tracing_batched else SimpleSpanProcessor(ConsoleSpanExporter())
#                 self.trace_provider.add_span_processor(console_span_processor)
#             if self.otel_remote_tracing:
#                 remote_span_processor = BatchSpanProcessor(OTLPSpanExporter(endpoint=otel_config['otel_collector_endpoint'], insecure= not otel_config['otel_collector_endpoint_is_secure']))
#                 self.trace_provider.add_span_processor(remote_span_processor)
#             trace.set_tracer_provider(self.trace_provider)

#         self.otel_metrics_enabled = otel_config.get('otel_metrics_enabled', False)
#         self.otel_console_metrics = otel_config.get('otel_console_metrics', False) 
#         self.otel_console_metrics_batched = otel_config.get('otel_console_metrics_batched', False)
#         self.otel_remote_metrics = otel_config.get('otel_remote_metrics', False)
#         self.otel_remote_metrics_batched = otel_config.get('otel_remote_metrics_batched', False)
#         if self.otel_metrics_enabled:
#             metric_readers = []
#             if self.otel_console_metrics:
#                 console_metric_reader = PeriodicExportingMetricReader(ConsoleMetricExporter(), export_interval_millis=otel_config['otel_metrics_export_interval'])  
#                 metric_readers.append(console_metric_reader)
#             if self.otel_remote_metrics:
#                 remote_metric_reader = PeriodicExportingMetricReader(OTLPMetricExporter(endpoint=otel_config['otel_collector_endpoint'], insecure= not otel_config['otel_collector_endpoint_is_secure']), export_interval_millis=otel_config['otel_metrics_export_interval'])
#                 metric_readers.append(remote_metric_reader)
#             self.meter_provider = MeterProvider(resource=self.resource, metric_readers=metric_readers)
#             metrics.set_meter_provider(self.meter_provider)
        

#     def _get_tracer(self, name="cams_tracer"):
#         return trace.get_tracer(instrumenting_module_name=name)
    
#     def _start_span(self,func_name:str, tracer_name: str = 'cams_tracer'):
#         caller_frame = inspect.stack()[2]
#         calling_func = caller_frame.function
#         tracer = self._get_tracer(name=tracer_name)
#         return tracer.start_as_current_span(name=func_name)
    
#     def create_meter(self, name="cams_meter"):
#         return get_meter(name)

#     def finish_observability_client(self):
#         self.trace_provider.shutdown()
#         self.log_provider.shutdown()
#         self.meter_provider.shutdown()
    
#     @classmethod
#     def get_otel_config(cls,service_name: str, environment: str = "dev",agent_id: str = "N/A"):
#         cls.otel_enabled = os.getenv("OTEL_ENABLED", "false").lower()
#         cls.otel_config_uuid = os.getenv("OTEL_CONFIG_UUID")
#         if cls.otel_config_uuid is None:
#             cls.otel_config_uuid = uuid.uuid4().hex.lower()
#         cls.otel_endpoint = os.getenv("OTEL_ENDPOINT")
#         cls.otel_endpoint_is_secure = os.getenv("OTEL_ENDPOINT_IS_SECURE", "false").lower()
#         cls.otel_logging_enabled = os.getenv("OTEL_LOGGING_ENABLED", "false").lower()
#         cls.otel_log_level = os.getenv("OTEL_LOG_LEVEL", "info").lower()
#         cls.otel_console_logging = os.getenv("OTEL_CONSOLE_LOGGING", "false").lower()
#         cls.otel_console_logging_batched = os.getenv("OTEL_CONSOLE_LOGGING_BATCHED", "false").lower()
#         cls.otel_remote_logging = os.getenv("OTEL_REMOTE_LOGGING", "false").lower()
#         cls.otel_remote_logging_batched = os.getenv("OTEL_REMOTE_LOGGING_BATCHED", "false").lower()
#         cls.otel_tracing_enabled = os.getenv("OTEL_TRACING_ENABLED", "false").lower()
#         cls.otel_console_tracing = os.getenv("OTEL_CONSOLE_TRACING", "false").lower()
#         cls.otel_console_tracing_batched = os.getenv("OTEL_CONSOLE_TRACING_BATCHED", "false").lower()
#         cls.otel_remote_tracing = os.getenv("OTEL_REMOTE_TRACING", "false").lower()
#         cls.otel_remote_tracing_batched = os.getenv("OTEL_REMOTE_TRACING_BATCHED", "false").lower()
#         cls.otel_metrics_enabled = os.getenv("OTEL_METRICS_ENABLED", "false").lower()
#         cls.otel_console_metrics = os.getenv("OTEL_CONSOLE_METRICS", "false").lower()
#         cls.otel_console_metrics_batched = os.getenv("OTEL_CONSOLE_METRICS_BATCHED", "false").lower()
#         cls.otel_remote_metrics = os.getenv("OTEL_REMOTE_METRICS", "false").lower()
#         cls.otel_remote_metrics_batched = os.getenv("OTEL_REMOTE_METRICS_BATCHED", "false").lower()
#         cls.otel_metrics_export_interval = int(os.getenv("OTEL_METRICS_EXPORT_INTERVAL","60000"))
#         loglevel_mapping = logging.getLevelNamesMapping()
#         cls.otel_log_level = loglevel_mapping.get(os.getenv("OTEL_LOG_LEVEL", "info").upper(), logging.INFO)
#         otel_config = {
#             "otel_enabled": cls.otel_enabled=="true",
#             "service_name": service_name,
#             "environment": environment,
#             "agent_id": agent_id,
#             "otel_config_uuid": cls.otel_config_uuid,
#             "otel_logging_enabled": cls.otel_logging_enabled=="true",
#             "otel_log_level": cls.otel_log_level,
#             "otel_console_logging": cls.otel_console_logging=="true",
#             "otel_console_logging_batched": cls.otel_console_logging_batched=="true",
#             "otel_remote_logging": cls.otel_remote_logging=="true",
#             "otel_remote_logging_batched": cls.otel_remote_logging_batched=="true",
#             "otel_tracing_enabled": cls.otel_tracing_enabled == "true",
#             "otel_console_tracing": cls.otel_console_tracing=="true",
#             "otel_console_tracing_batched": cls.otel_console_tracing_batched=="true",
#             "otel_remote_tracing": cls.otel_remote_tracing=="true",
#             "otel_remote_tracing_batched": cls.otel_remote_tracing_batched=="true",
#             "otel_metrics_enabled": cls.otel_metrics_enabled == "true",
#             "otel_console_metrics": cls.otel_console_metrics=="true",
#             "otel_console_metrics_batched": cls.otel_console_metrics_batched=="true",
#             "otel_remote_metrics": cls.otel_remote_metrics=="true",
#             "otel_remote_metrics_batched": cls.otel_remote_metrics_batched=="true",
#             "otel_metrics_export_interval": cls.otel_metrics_export_interval,
#             "otel_collector_endpoint": cls.otel_endpoint,
#             "otel_collector_endpoint_is_secure": cls.otel_endpoint_is_secure=="true",
#         }
#         return otel_config
    
#     @classmethod
#     def get_otel_client(cls,otel_config: dict = None):
#         if otel_config == None:
#             return cls.current_otel_client
#         if cls.current_otel_client is None or cls.current_otel_client.otel_config['otel_config_uuid'] != otel_config['otel_config_uuid']:
#             if cls.current_otel_client:
#                 cls.current_otel_client.finish_observability_client()
#             cls.current_otel_client = Otel_Client(otel_config=otel_config)
#         return cls.current_otel_client

#     @classmethod
#     def initialize_otel_client(cls, service_name: str, environment: str = "dev", agent_id: str = "N/A"):
#         otel_config = cls.get_otel_config(service_name=service_name, environment=environment, agent_id=agent_id)
#         return Otel_Client.get_otel_client(otel_config=otel_config)
    
#     @classmethod
#     def get_current_otel_client(cls):
#         return cls.current_otel_client